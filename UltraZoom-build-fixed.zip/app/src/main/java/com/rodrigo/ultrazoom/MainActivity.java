package com.rodrigo.ultrazoom;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.MeteringRectangle;
import android.media.Image;
import android.graphics.ImageFormat;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Size;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.TextureView;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ = 44;
    private UltraCameraView camera;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        camera = new UltraCameraView(this);
        setContentView(camera);
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ);
        } else camera.start();
    }
    @Override protected void onResume() { super.onResume(); if (camera != null && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) camera.start(); }
    @Override protected void onPause() { if (camera != null) camera.stop(); super.onPause(); }
    @Override protected void onDestroy() { if (camera != null) camera.shutdown(); super.onDestroy(); }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r == REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) camera.start();
        else Toast.makeText(this,"A câmera é necessária para o UltraZoom.",Toast.LENGTH_LONG).show();
    }
}

class UltraCameraView extends ViewGroup {
    private enum Mode { FOTO, AUTO, PRO, ULTRA, MAX, NIGHT, LAB }
    private TextureView preview;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private CameraDevice device;
    private CameraCaptureSession session;
    private CameraCharacteristics chars;
    private String cameraId;
    private Size jpegSize;
    private Rect sensor;
    private float maxHardware = 1f, minHardware = 1f, zoom = 1f;
    private boolean flashAvailable, torch, busy;
    private boolean lowLightBoostSupported=false;
    // 0 = off, 1 = auto, 2 = on for still capture.
    private int flashMode = 0;
    private ImageReader reader;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private HandlerThread workThread;
    private Handler workHandler;
    private final java.util.concurrent.ExecutorService cpu = java.util.concurrent.Executors.newSingleThreadExecutor();
    private ScaleGestureDetector pinch;
    private Mode mode = Mode.AUTO;
    private final List<Bitmap> burstFrames = Collections.synchronizedList(new ArrayList<Bitmap>());
    private int burstTarget, capturesIssued;
    private long burstStarted;
    private String status = "PRONTO";
    private int statusProgress;
    private boolean showLab;
    private int backCameraCount=0;
    private final String[] modeNames = {"FOTO","AUTO","PRO","ULTRA","MAX","NIGHT","LAB"};
    private final ArrayList<String> backIds = new ArrayList<>();
    private String ultraWideId;
    private String mainCameraId;
    private String preferredCameraId;
    private boolean showInfo;
    private boolean showModeMenu;
    private float focusX=-1f, focusY=-1f;
    private long focusUntil=0L;

    UltraCameraView(Context c) {
        super(c);
        setWillNotDraw(false);
        setBackgroundColor(Color.BLACK);
        text.setTypeface(Typeface.create("sans", Typeface.BOLD));
        startThreads();
        preview = new TextureView(c);
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){open();}
            public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){transform();}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture s){close();return true;}
            public void onSurfaceTextureUpdated(SurfaceTexture s){}
        });
        addView(preview);
        pinch = new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            public boolean onScale(ScaleGestureDetector d){setZoom(zoom*d.getScaleFactor());return true;}
        });
    }

    private void startThreads(){
        if(cameraThread==null){cameraThread=new HandlerThread("UltraZoom-Camera");cameraThread.start();cameraHandler=new Handler(cameraThread.getLooper());}
        if(workThread==null){workThread=new HandlerThread("UltraZoom-Work");workThread.start();workHandler=new Handler(workThread.getLooper());}
    }

    @Override protected void onMeasure(int widthMeasureSpec,int heightMeasureSpec){
        int w=MeasureSpec.getSize(widthMeasureSpec);
        int h=MeasureSpec.getSize(heightMeasureSpec);
        if(w<=0)w=1080;
        if(h<=0)h=1920;
        setMeasuredDimension(w,h);
        preview.measure(MeasureSpec.makeMeasureSpec(w,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(h,MeasureSpec.EXACTLY));
    }

    @Override protected void onLayout(boolean c,int l,int t,int r,int b){preview.layout(0,0,getWidth(),getHeight());transform();}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        c.drawColor(Color.BLACK);
    }

    @Override protected void dispatchDraw(Canvas c){
        super.dispatchDraw(c);
        drawOverlay(c);
    }

    private void drawOverlay(Canvas c){
        int w=getWidth(), h=getHeight();
        // Premium camera HUD: minimal, high-contrast, large controls, camera preview stays visible.
        p.setStyle(Paint.Style.FILL); p.setColor(0x99000000);
        c.drawRect(0,0,w,92,p);
        c.drawRect(0,h-205,w,h,p);

        text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setColor(Color.WHITE);
        text.setTextSize(20); c.drawText("ULTRAZOOM",20,31,text);
        text.setTypeface(Typeface.DEFAULT); text.setTextSize(11); text.setColor(0xDFFFFFFF);
        c.drawText(modeNames[mode.ordinal()]+"  ▾",20,52,text);
        String z=zoom<10?String.format(Locale.US,"%.1f×",zoom):String.format(Locale.US,"%.0f×",zoom);
        text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(38); text.setColor(Color.WHITE);
        c.drawText(z,w-22-text.measureText(z),38,text);
        text.setTypeface(Typeface.DEFAULT); text.setTextSize(10); text.setColor(0xDFFFFFFF);
        String cam=cameraIdEqualsWide()?"ULTRAWIDE":"PRINCIPAL";
        String hw=cameraIdEqualsWide() && zoom<0.9f?"0,5× • lente física":String.format(Locale.US,"hardware %.1f× • digital %.1f×",Math.min(Math.max(zoom,minHardware),maxHardware),Math.max(1f,zoom/Math.max(1f,maxHardware)));
        c.drawText(cam+" • "+hw,w-22-text.measureText(cam+" • "+hw),58,text);
        String statusLine=status + (burstTarget>0 && busy ? "  "+statusProgress+"/"+burstTarget : "");
        c.drawText(statusLine,w-22-text.measureText(statusLine),76,text);

        // Lens selector: large, simple, touch friendly.
        String[] cams={"0,5×","1×","2×","6×"}; float y=105; float gap=8; float bw=(w-2*18-3*gap)/4f;
        for(int i=0;i<4;i++){
            boolean active=(i==0&&cameraIdEqualsWide()&&zoom<0.9f)||(i==1&&!cameraIdEqualsWide()&&Math.abs(zoom-1f)<0.08f)||(i==2&&!cameraIdEqualsWide()&&Math.abs(zoom-2f)<0.12f)||(i==3&&!cameraIdEqualsWide()&&Math.abs(zoom-6f)<0.18f);
            p.setColor(active?0xFFFFFFFF:0x72000000); c.drawRoundRect(18+i*(bw+gap),y,18+i*(bw+gap)+bw,y+42,18,18,p);
            text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(15); text.setColor(active?Color.BLACK:Color.WHITE);
            String label=cams[i]; c.drawText(label,18+i*(bw+gap)+(bw-text.measureText(label))/2,y+27,text);
        }

        // Zoom rail, readable even on a small phone.
        text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(13); text.setColor(Color.WHITE);
        c.drawText("ZOOM",20,h-178,text);
        String[] presets={"0,5","1","2","4","6","10","20","50","100"};
        float py=h-151; float pg=(w-40)/8f;
        for(int i=0;i<presets.length;i++){
            float pv=Float.parseFloat(presets[i].replace(',','.')); String label=presets[i]+"×";
            boolean active=Math.abs(zoom-pv)<(pv<2?0.08f:0.18f)||(pv==100&&zoom>=99);
            text.setTypeface(active?Typeface.create("sans",Typeface.BOLD):Typeface.DEFAULT); text.setTextSize(active?16:13); text.setColor(active?Color.WHITE:0xCFFFFFFF);
            c.drawText(label,20+i*pg,py,text);
        }
        p.setColor(0x55FFFFFF); c.drawRoundRect(20,h-139,w-20,h-136,2,2,p);
        float ratio=(float)((Math.log(Math.max(0.5,zoom))-Math.log(0.5))/(Math.log(100)-Math.log(0.5)));
        p.setColor(Color.WHITE); c.drawCircle(20+ratio*(w-40),h-137,5,p);

        // One clean mode chip. The full mode picker opens as a premium sheet, avoiding tiny labels.
        float my=h-112; float chipW=Math.min(180,w-36);
        p.setColor(0xE6FFFFFF); c.drawRoundRect(18,my,18+chipW,my+40,20,20,p);
        text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(13); text.setColor(Color.BLACK);
        String modeLabel=modeNames[mode.ordinal()]; c.drawText(modeLabel+"  ▾",18+(chipW-text.measureText(modeLabel+"  ▾"))/2,my+26,text);

        // Bottom control bar.
        float cy=h-50;
        drawIconButton(c,52,cy,flashMode==0?"⚡":"⚡",flashMode>0,"FLASH");
        drawShutter(c,w/2f,cy,busy);
        drawIconButton(c,w-52,cy,"ⓘ",showInfo,"INFO");
        text.setTypeface(Typeface.DEFAULT); text.setTextSize(10); text.setColor(0xEFFFFFFF);
        c.drawText("OFF / AUTO / ON",18,h-10,text);
        c.drawText("TOQUE PARA FOCAR",w-112,h-10,text);

        if(focusUntil>System.currentTimeMillis() && focusX>=0){
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f); p.setColor(0xE6FFFFFF); c.drawRect(focusX-34,focusY-34,focusX+34,focusY+34,p); p.setStyle(Paint.Style.FILL);
        }
        if(showModeMenu) drawModeMenu(c);
        if(showInfo || showLab) drawInfoPanel(c,showLab);
    }

    private void drawModeMenu(Canvas c){
        int w=getWidth(),h=getHeight();
        p.setColor(0xF20A0A0A); c.drawRoundRect(16,110,w-16,h-110,26,26,p);
        text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(22); text.setColor(Color.WHITE); c.drawText("MODO DE CAPTURA",36,150,text);
        text.setTypeface(Typeface.DEFAULT); text.setTextSize(11); text.setColor(0xCCFFFFFF); c.drawText("Escolha o equilíbrio entre velocidade e processamento.",36,171,text);
        String[] desc={"Captura rápida, sem processamento pesado.","Escolha automática conforme cena e hardware.","Fusão computacional moderada.","Mais frames e reconstrução.","Máxima potência disponível.","Baixa luz • multi-frame + boost quando suportado.","Laboratório • compare resultados e telemetria."};
        float y=198;
        for(int i=0;i<modeNames.length;i++){
            boolean active=mode.ordinal()==i; p.setColor(active?0xFFFFFFFF:0x661F1F1F); c.drawRoundRect(30,y,w-30,y+52,18,18,p);
            text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(14); text.setColor(active?Color.BLACK:Color.WHITE); c.drawText(modeNames[i],48,y+22,text);
            text.setTypeface(Typeface.DEFAULT); text.setTextSize(9); text.setColor(active?0xFF333333:0xBFFFFFFF); c.drawText(desc[i],48,y+39,text);
            y+=58;
        }
        text.setTextSize(10); text.setColor(0xAAFFFFFF); c.drawText("Toque fora para fechar",36,h-128,text);
    }

    private void drawIconButton(Canvas c,float x,float y,String icon,boolean active,String caption){
        p.setColor(active?0xFFFFFFFF:0x88000000); c.drawCircle(x,y,25,p);
        text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(17); text.setColor(active?Color.BLACK:Color.WHITE);
        c.drawText(icon,x-text.measureText(icon)/2,y+6,text);
        text.setTypeface(Typeface.DEFAULT); text.setTextSize(8); text.setColor(Color.WHITE); c.drawText(caption,x-text.measureText(caption)/2,y+39,text);
    }

    private void drawShutter(Canvas c,float x,float y,boolean busy){
        p.setColor(0xDDFFFFFF); c.drawCircle(x,y,31,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(0xFF111111); c.drawCircle(x,y,25,p); p.setStyle(Paint.Style.FILL);
        if(busy){p.setColor(0xFF111111);c.drawRoundRect(x-8,y-8,x+8,y+8,3,3,p);}
    }

    private boolean cameraIdEqualsWide(){ return cameraId!=null && cameraId.equals(ultraWideId); }

    private void drawInfoPanel(Canvas c, boolean lab){
        int w=getWidth(), h=getHeight();
        p.setColor(0xF20B0B0B); c.drawRoundRect(18,205,w-18,h-325,20,20,p);
        text.setColor(Color.WHITE); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(18);
        c.drawText(lab?"LABORATÓRIO":"INFORMAÇÕES",38,238,text);
        text.setTypeface(Typeface.DEFAULT); text.setTextSize(12);
        if(lab){
            c.drawText("Teste do motor computacional",38,262,text);
            c.drawText("Melhor frame • fusão • refinamento",38,280,text);
        }
        String z=zoom<10?String.format(Locale.US,"%.1fx",zoom):String.format(Locale.US,"%.0fx",zoom);
        c.drawText("Zoom solicitado: "+z,38,308,text);
        c.drawText("Câmera ativa: "+(cameraIdEqualsWide()?"ULTRAWIDE":"PRINCIPAL"),38,328,text);
        c.drawText(String.format(Locale.US,"Faixa Camera2: %.1fx–%.1fx",minHardware,maxHardware),38,348,text);
        c.drawText("Frames do modo: "+framesForMode(),38,368,text);
        c.drawText("Frames recebidos: "+(statusProgress>0?statusProgress:"—"),38,388,text);
        c.drawText("JPEG: "+(jpegSize!=null?jpegSize.getWidth()+"×"+jpegSize.getHeight():"—"),38,408,text);
        c.drawText("Câmeras traseiras: "+backCameraCount,38,428,text);
        c.drawText("Flash: "+(flashAvailable?"disponível":"indisponível"),38,448,text);
        text.setTextSize(10); text.setColor(0xCFFFFFFF);
        c.drawText("Toque em ⓘ para fechar",38,474,text);
    }

    private void drawButton(Canvas c,float x,float y,String s,boolean active){
        p.setColor(active?0xFFFFFFFF:0x66000000); c.drawCircle(x,y,29,p);
        text.setColor(active?Color.BLACK:Color.WHITE); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(s.equals("●")?28:15);
        float tw=text.measureText(s); c.drawText(s,x-tw/2,y+6,text);
    }

    private void selectModeAt(float x){
        float bw=(getWidth()-20)/6f; int idx=(int)((x-10)/bw); if(idx<0)idx=0;if(idx>5)idx=5;
        mode=Mode.values()[idx]; showLab=mode==Mode.LAB; status=mode==Mode.AUTO?"AUTO • ADAPTATIVO":modeNames[idx]+" • "+framesForMode()+" FRAMES"; invalidate();
    }

    private void open(){
        try{
            CameraManager m=(CameraManager)getContext().getSystemService(Context.CAMERA_SERVICE);
            String best=null;
            backIds.clear(); backCameraCount=0; ultraWideId=null; mainCameraId=null;
            float widestFov=0f; long largestSensor=-1L;
            for(String id:m.getCameraIdList()){
                CameraCharacteristics cc=m.getCameraCharacteristics(id); Integer facing=cc.get(CameraCharacteristics.LENS_FACING);
                if(facing!=null&&facing==CameraCharacteristics.LENS_FACING_BACK){
                    backCameraCount++; backIds.add(id);
                    float f=99f; float[] fs=cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS); if(fs!=null&&fs.length>0)f=fs[0];
                    float fov=horizontalFov(cc);
                    if(fov>widestFov){widestFov=fov;ultraWideId=id;}
                    android.util.Size pa=cc.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
                    long area=pa!=null?(long)pa.getWidth()*pa.getHeight():0L;
                    if(area>largestSensor){largestSensor=area;mainCameraId=id;}
                    FloatRange rr=zoomRange(cc);
                    if(best==null && rr.min<=0.5f)best=id;
                }
            }
            if(best==null)best=mainCameraId;
            if(best==null)return;
            if(preferredCameraId!=null && backIds.contains(preferredCameraId))best=preferredCameraId;
            cameraId=best; chars=m.getCameraCharacteristics(cameraId);
            sensor=chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            FloatRange rr=zoomRange(chars); minHardware=rr.min; maxHardware=rr.max;
            if(minHardware>0.5f && ultraWideId!=null && ultraWideId.equals(cameraId)) minHardware=1f;
            if(zoom<minHardware)zoom=minHardware;
            android.hardware.camera2.params.StreamConfigurationMap map=chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if(map!=null){Size[] ss=map.getOutputSizes(ImageFormat.JPEG); if(ss!=null&&ss.length>0){jpegSize=ss[0];for(Size s:ss)if((long)s.getWidth()*s.getHeight()>(long)jpegSize.getWidth()*jpegSize.getHeight())jpegSize=s;}}
            flashAvailable=Boolean.TRUE.equals(chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE));
            if(Build.VERSION.SDK_INT>=35){ int[] aeModes=chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES); lowLightBoostSupported=false; if(aeModes!=null){ for(int v:aeModes) if(v==CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY){ lowLightBoostSupported=true; break; } } }
            if(reader!=null)reader.close();
            reader=ImageReader.newInstance(jpegSize!=null?jpegSize.getWidth():1920,jpegSize!=null?jpegSize.getHeight():1080,ImageFormat.JPEG,8);
            reader.setOnImageAvailableListener(r->{Image im=null;try{im=r.acquireNextImage();if(im==null)return;ByteBuffer bb=im.getPlanes()[0].getBuffer();byte[] data=new byte[bb.remaining()];bb.get(data);if(busy){Bitmap b=BitmapFactory.decodeByteArray(data,0,data.length);if(b!=null)burstFrames.add(b);}}catch(Exception ignored){}finally{if(im!=null)im.close();}},workHandler);
            if(getContext().checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED){
                m.openCamera(cameraId,new CameraDevice.StateCallback(){public void onOpened(CameraDevice d){device=d;createSession();}public void onDisconnected(CameraDevice d){d.close();device=null;}public void onError(CameraDevice d,int e){d.close();device=null;}},cameraHandler);
            }
        }catch(Exception e){post(()->Toast.makeText(getContext(),"Câmera indisponível: "+e.getMessage(),Toast.LENGTH_LONG).show());}
    }


    private float horizontalFov(CameraCharacteristics cc){
        try{
            float[] fs=cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            Size sensorSize=cc.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            if(fs!=null&&fs.length>0&&sensorSize!=null&&fs[0]>0){
                return (float)(2.0*Math.atan(sensorSize.getWidth()/(2.0*fs[0])));
            }
        }catch(Exception ignored){}
        return 0f;
    }
    private static class FloatRange { final float min,max; FloatRange(float a,float b){min=a;max=b;} }
    private FloatRange zoomRange(CameraCharacteristics cc){
        if(Build.VERSION.SDK_INT>=30){android.util.Range<Float> r=cc.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE); if(r!=null)return new FloatRange(r.getLower(),r.getUpper());}
        Float hz=cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM); return new FloatRange(1f,hz!=null?Math.max(1f,hz):1f);
    }

    private void createSession(){
        try{
            SurfaceTexture st=preview.getSurfaceTexture();if(st==null)return;st.setDefaultBufferSize(1920,1080);Surface ps=new Surface(st);
            device.createCaptureSession(Arrays.asList(ps,reader.getSurface()),new CameraCaptureSession.StateCallback(){public void onConfigured(CameraCaptureSession s){session=s;applyPreview();}public void onConfigureFailed(CameraCaptureSession s){status="FALHA NA SESSÃO";postInvalidate();}},cameraHandler);
        }catch(Exception ignored){}
    }

    private CaptureRequest.Builder baseRequest(int template)throws Exception{
        CaptureRequest.Builder b=device.createCaptureRequest(template);
        b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        b.set(CaptureRequest.CONTROL_AE_MODE,(mode==Mode.NIGHT && lowLightBoostSupported && template==CameraDevice.TEMPLATE_PREVIEW)?CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY:CaptureRequest.CONTROL_AE_MODE_ON);
        try{
            int[] stab=chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION);
            if(stab!=null) for(int v:stab) if(v==CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON){ b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,v); break; }
        }catch(Exception ignored){}
        if(flashAvailable){
            b.set(CaptureRequest.FLASH_MODE, torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            if(template==CameraDevice.TEMPLATE_STILL_CAPTURE && !torch){
                if(flashMode==1) b.set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH);
                else if(flashMode==2) b.set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH);
            }
        }
        if(Build.VERSION.SDK_INT>=30)b.set(CaptureRequest.CONTROL_ZOOM_RATIO,Math.max(minHardware,Math.min(zoom,maxHardware)));else b.set(CaptureRequest.SCALER_CROP_REGION,cropRect(Math.max(minHardware,Math.min(zoom,maxHardware))));
        return b;
    }

    private void applyPreview(){
        try{if(session==null||device==null)return;CaptureRequest.Builder b=baseRequest(CameraDevice.TEMPLATE_PREVIEW);b.addTarget(new Surface(preview.getSurfaceTexture()));session.setRepeatingRequest(b.build(),null,cameraHandler);transform();}
        catch(Exception ignored){}
    }

    private Rect cropRect(float z){if(sensor==null)return null;int w=Math.max(1,(int)(sensor.width()/z)),h=Math.max(1,(int)(sensor.height()/z));int l=sensor.centerX()-w/2,t=sensor.centerY()-h/2;return new Rect(l,t,l+w,t+h);}

    private void setZoom(float v){zoom=Math.max(minHardware,Math.min(100f,v));applyPreview();invalidate();}

    private void transform(){
        if(preview==null)return;float extra=Math.max(1f,zoom/Math.max(1f,maxHardware));Matrix m=new Matrix();float cx=getWidth()/2f,cy=getHeight()/2f;m.setScale(extra,extra,cx,cy);preview.setTransform(m);
    }

    private void focus(float x,float y){
        if(session==null||device==null||sensor==null||busy)return;
        focusX=x; focusY=y; focusUntil=System.currentTimeMillis()+900; invalidate();
        try{float vx=Math.max(0,Math.min(1,x/getWidth())),vy=Math.max(0,Math.min(1,y/getHeight()));float z=Math.max(minHardware,Math.min(zoom,maxHardware));int w=(int)(sensor.width()/z),h=(int)(sensor.height()/z);int l=sensor.centerX()-w/2,t=sensor.centerY()-h/2;int fx=(int)(l+vx*w),fy=(int)(t+vy*h);int sw=Math.max(100,w/8),sh=Math.max(100,h/8);Rect r=new Rect(Math.max(sensor.left,fx-sw/2),Math.max(sensor.top,fy-sh/2),Math.min(sensor.right,fx+sw/2),Math.min(sensor.bottom,fy+sh/2));CaptureRequest.Builder b=baseRequest(CameraDevice.TEMPLATE_PREVIEW);b.addTarget(new Surface(preview.getSurfaceTexture()));b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_AUTO);b.set(CaptureRequest.CONTROL_AF_TRIGGER,CaptureRequest.CONTROL_AF_TRIGGER_START);b.set(CaptureRequest.CONTROL_AF_REGIONS,new MeteringRectangle[]{new MeteringRectangle(r,MeteringRectangle.METERING_WEIGHT_MAX-1)});session.capture(b.build(),null,cameraHandler);applyPreview();}
        catch(Exception ignored){}
    }

    private int rotation(){int r=getContext().getSystemService(WindowManager.class).getDefaultDisplay().getRotation();if(r==Surface.ROTATION_0)return 90;if(r==Surface.ROTATION_90)return 0;if(r==Surface.ROTATION_180)return 270;return 180;}

    private int framesForMode(){
        switch(mode){case FOTO:return 1;case PRO:return 4;case ULTRA:return 8;case MAX:return Math.max(6,Math.min(12,autoFrames()+4));case NIGHT:return Math.max(8,Math.min(16,autoFrames()+6));case LAB:return 10;default:return autoFrames();}
    }
    private int autoFrames(){
        ActivityManager am=(ActivityManager)getContext().getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); if(am!=null)am.getMemoryInfo(mi);
        long free=mi.availMem/(1024L*1024L);
        int cap=free>3500?8:free>2200?6:free>1400?4:2;
        if(zoom<3)return Math.min(2,cap); if(zoom<8)return Math.min(4,cap); if(zoom<20)return Math.min(6,cap); return cap;
    }

    private void capture(){
        if(busy||session==null||device==null)return;
        busy=true;burstFrames.clear();burstTarget=framesForMode();capturesIssued=0;burstStarted=System.currentTimeMillis();status=(mode==Mode.FOTO?"CAPTURANDO": mode==Mode.NIGHT?"CAPTURA NOTURNA":"CAPTURA COMPUTACIONAL");invalidate();issueStill(0);
    }

    private void issueStill(int index){
        if(!busy)return;
        try{
            CaptureRequest.Builder b=baseRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);b.addTarget(reader.getSurface());b.set(CaptureRequest.JPEG_ORIENTATION,rotation());
            session.capture(b.build(),new CameraCaptureSession.CaptureCallback(){
                @Override public void onCaptureCompleted(CameraCaptureSession s,CaptureRequest r,TotalCaptureResult result){
                    capturesIssued++;statusProgress=capturesIssued;postInvalidate();
                    if(capturesIssued<burstTarget){workHandler.postDelayed(()->issueStill(capturesIssued), mode==Mode.MAX||mode==Mode.LAB?80:45);}
                    else workHandler.postDelayed(()->finishBurst(),600);
                }
            },cameraHandler);
        }catch(Exception e){busy=false;status="ERRO DE CAPTURA";invalidate();}
    }

    private void finishBurst(){
        final ArrayList<Bitmap> frames;
        synchronized(burstFrames){frames=new ArrayList<>(burstFrames);}
        if(frames.isEmpty()){busy=false;status="NENHUM FRAME";invalidate();return;}
        status="ANALISANDO";invalidate();
        cpu.execute(()->processFrames(frames));
    }

    private void processFrames(ArrayList<Bitmap> frames){
        try{
            List<FrameScore> scored=new ArrayList<>();
            for(Bitmap b:frames)scored.add(new FrameScore(b,sharpness(b)));
            Collections.sort(scored,Comparator.comparingDouble((FrameScore f)->f.score).reversed());
            Bitmap best=scored.get(0).bitmap;
            if(mode==Mode.FOTO){saveBitmap(cropAndScale(best,softwareZoom()),"FOTO");complete("FOTO • salva");return;}
            status="ALINHANDO";postInvalidate();
            int limit=Math.min(frames.size(),mode==Mode.PRO?4:mode==Mode.ULTRA?8:mode==Mode.NIGHT?12:mode==Mode.LAB?10:12);
            ArrayList<Bitmap> selected=new ArrayList<>();for(int i=0;i<limit;i++)selected.add(scored.get(i).bitmap);
            Bitmap fused=fuseAligned(selected,softwareZoom());
            status="REFINANDO";postInvalidate();
            Bitmap enhanced=enhance(fused);
            if(mode==Mode.LAB){
                saveBitmap(cropAndScale(best,softwareZoom()),"LAB_BEST");
                saveBitmap(fused,"LAB_FUSAO");
                saveBitmap(enhanced,"LAB_MAX");
                if(!fused.isRecycled())fused.recycle();
                recycleExcept(frames,best,enhanced);
                complete("LAB • "+selected.size()+" frames • 3 resultados");return;
            }
            saveBitmap(enhanced,mode==Mode.MAX?"MAX":mode==Mode.NIGHT?"NIGHT":modeNames[mode.ordinal()]);
            if(!fused.isRecycled())fused.recycle();
            recycleExcept(frames,enhanced);
            complete(modeNames[mode.ordinal()]+" • "+selected.size()+" frames");
        }catch(Exception e){complete("FALHA NO PROCESSAMENTO");}
    }

    private void recycleExcept(List<Bitmap> all,Bitmap... keep){
        for(Bitmap b:all){boolean k=false;for(Bitmap x:keep)if(b==x)k=true;if(!k&&!b.isRecycled())b.recycle();}
    }

    private static class FrameScore{Bitmap bitmap;double score;FrameScore(Bitmap b,double s){bitmap=b;score=s;}}

    private double sharpness(Bitmap b){
        int w=Math.min(160,b.getWidth()),h=Math.min(120,b.getHeight());Bitmap s=Bitmap.createScaledBitmap(b,w,h,true);int[] px=new int[w*h];s.getPixels(px,0,w,0,0,w,h);double sum=0,sum2=0;int n=0;
        for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int c=luma(px[y*w+x]);int l=luma(px[y*w+x-1]),r=luma(px[y*w+x+1]),u=luma(px[(y-1)*w+x]),d=luma(px[(y+1)*w+x]);double v=(4*c-l-r-u-d);sum+=v;sum2+=v*v;n++;}
        if(!s.isRecycled())s.recycle();double mean=sum/n;return Math.max(0,sum2/n-mean*mean);
    }

    private int luma(int c){return (77*Color.red(c)+150*Color.green(c)+29*Color.blue(c))>>8;}

    private Bitmap fuseAligned(ArrayList<Bitmap> frames,float z){
        Bitmap ref=cropAndScale(frames.get(0),z,1280);int w=ref.getWidth(),h=ref.getHeight();
        long[] acc=new long[w*h*3];float[] weight=new float[w*h];
        addAligned(ref,ref,acc,weight,1f);
        for(int i=1;i<frames.size();i++){Bitmap b=cropAndScale(frames.get(i),z,1280);int[] shift=findShift(ref,b);Bitmap aligned=translate(b,shift[0],shift[1]);addAligned(aligned,ref,acc,weight,0.75f);if(!aligned.isRecycled())aligned.recycle();if(!b.isRecycled())b.recycle();}
        int[] out=new int[w*h];for(int i=0;i<out.length;i++){float q=Math.max(1,weight[i]);int rr=(int)Math.min(255,acc[i*3]/q),gg=(int)Math.min(255,acc[i*3+1]/q),bb=(int)Math.min(255,acc[i*3+2]/q);out[i]=Color.rgb(rr,gg,bb);}Bitmap result=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);result.setPixels(out,0,w,0,0,w,h);ref.recycle();return result;
    }

    private void addAligned(Bitmap b,Bitmap ref,long[] acc,float[] weight,float wt){
        int w=ref.getWidth(),h=ref.getHeight(),bw=b.getWidth(),bh=b.getHeight();Bitmap s=b;if(bw!=w||bh!=h)s=Bitmap.createScaledBitmap(b,w,h,true);int[] px=new int[w*h];s.getPixels(px,0,w,0,0,w,h);for(int i=0;i<px.length;i++){int c=px[i];acc[i*3]+=Color.red(c)*wt;acc[i*3+1]+=Color.green(c)*wt;acc[i*3+2]+=Color.blue(c)*wt;weight[i]+=wt;}if(s!=b&&!s.isRecycled())s.recycle();
    }

    private int[] findShift(Bitmap a,Bitmap b){
        int size=96;Bitmap aa=Bitmap.createScaledBitmap(a,size,size,true),bb=Bitmap.createScaledBitmap(b,size,size,true);int[] ap=new int[size*size],bp=new int[size*size];aa.getPixels(ap,0,size,0,0,size,size);bb.getPixels(bp,0,size,0,0,size,size);double best=Double.MAX_VALUE;int bx=0,by=0;
        for(int dy=-4;dy<=4;dy++)for(int dx=-4;dx<=4;dx++){double err=0;int n=0;for(int y=10;y<size-10;y+=3)for(int x=10;x<size-10;x+=3){int xx=x+dx,yy=y+dy;if(xx<0||xx>=size||yy<0||yy>=size)continue;err+=Math.abs(luma(ap[y*size+x])-luma(bp[yy*size+xx]));n++;}err/=Math.max(1,n);if(err<best){best=err;bx=dx;by=dy;}}
        aa.recycle();bb.recycle();return new int[]{bx*(a.getWidth()/size),by*(a.getHeight()/size)};
    }

    private Bitmap translate(Bitmap b,int dx,int dy){Matrix m=new Matrix();m.setTranslate(dx,dy);Bitmap out=Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);return out;}

    private Bitmap enhance(Bitmap b){
        Bitmap out=Bitmap.createBitmap(b.getWidth(),b.getHeight(),Bitmap.Config.ARGB_8888);int w=b.getWidth(),h=b.getHeight();int[] in=new int[w*h],px=new int[w*h];b.getPixels(in,0,w,0,0,w,h);
        for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int i=y*w+x,c=in[i];int l=in[i-1],r=in[i+1],u=in[i-w],d=in[i+w];int rr=Color.red(c)+clamp((Color.red(c)*4-Color.red(l)-Color.red(r)-Color.red(u)-Color.red(d))/12);int gg=Color.green(c)+clamp((Color.green(c)*4-Color.green(l)-Color.green(r)-Color.green(u)-Color.green(d))/12);int bb=Color.blue(c)+clamp((Color.blue(c)*4-Color.blue(l)-Color.blue(r)-Color.blue(u)-Color.blue(d))/12);px[i]=Color.rgb(clamp(rr),clamp(gg),clamp(bb));}
        out.setPixels(px,0,w,0,0,w,h);if(!b.isRecycled())b.recycle();return out;
    }
    private int clamp(int v){return Math.max(-30,Math.min(30,v));}

    private float softwareZoom(){ return Math.max(1f, zoom/Math.max(1f,maxHardware)); }

    private Bitmap cropAndScale(Bitmap src,float z){return cropAndScale(src,z,4096);}
    private Bitmap cropAndScale(Bitmap src,float z,int maxDim){
        int cw=Math.max(1,(int)(src.getWidth()/Math.min(z,100f))),ch=Math.max(1,(int)(src.getHeight()/Math.min(z,100f)));int l=Math.max(0,(src.getWidth()-cw)/2),t=Math.max(0,(src.getHeight()-ch)/2);Bitmap crop=Bitmap.createBitmap(src,l,t,Math.min(cw,src.getWidth()-l),Math.min(ch,src.getHeight()-t));int ow=Math.min(maxDim,Math.max(1080,crop.getWidth()));int oh=Math.min(maxDim,Math.max(1080,(int)((long)crop.getHeight()*ow/(double)crop.getWidth())));Bitmap out=Bitmap.createScaledBitmap(crop,ow,oh,true);if(crop!=src&&!crop.isRecycled())crop.recycle();return out;
    }

    private void saveBitmap(Bitmap b,String tag){
        try{ContentValues cv=new ContentValues();cv.put(MediaStore.Images.Media.DISPLAY_NAME,"UltraZoom_"+tag+"_"+System.currentTimeMillis()+".jpg");cv.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");cv.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/UltraZoom");Uri u=getContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);if(u!=null){OutputStream os=getContext().getContentResolver().openOutputStream(u);b.compress(Bitmap.CompressFormat.JPEG,97,os);os.close();}}
        catch(Exception ignored){}finally{if(b!=null&&!b.isRecycled())b.recycle();}
    }

    private void complete(String s){busy=false;burstTarget=0;status=s;postInvalidate();postDelayed(()->{if(!busy){status=mode==Mode.AUTO?"AUTO • ADAPTATIVO":modeNames[mode.ordinal()]+" • PRONTO";invalidate();}},2200);}

    private void close(){
        try{if(session!=null){session.close();session=null;}if(device!=null){device.close();device=null;}if(reader!=null){reader.close();reader=null;}busy=false;}catch(Exception ignored){}
    }
    void shutdown(){
        close();
        try{ if(cpu!=null) cpu.shutdownNow(); }catch(Exception ignored){}
        try{ if(cameraThread!=null) cameraThread.quitSafely(); }catch(Exception ignored){}
        try{ if(workThread!=null) workThread.quitSafely(); }catch(Exception ignored){}
    }
    void start(){startThreads();if(preview.isAvailable()&&device==null)open();}
    void stop(){
        close();
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent e){
        return true; // Keep the HUD controls above the TextureView and route gestures here.
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        pinch.onTouchEvent(e);
        if(e.getAction()==MotionEvent.ACTION_UP){
            float y=e.getY(),x=e.getX(); int h=getHeight(),w=getWidth();
            // Bottom controls.
            if(y>h-90 && x<105){
                if(!flashAvailable){status="FLASH INDISPONÍVEL";invalidate();return true;}
                flashMode=(flashMode+1)%3; torch=false; applyPreview(); status=flashMode==0?"FLASH • OFF":flashMode==1?"FLASH • AUTO":"FLASH • ON"; invalidate(); return true;
            }
            if(y>h-95 && Math.abs(x-w/2f)<85){capture();return true;}
            if(y>h-90 && x>w-105){showInfo=!showInfo;showLab=showInfo&&mode==Mode.LAB;invalidate();return true;}
            // Lens buttons.
            if(y>=100&&y<=155){float gap=8,bw=(w-36-3*gap)/4f;int idx=(int)((x-18)/(bw+gap));if(idx>=0&&idx<4){if(idx==0)selectWide();else selectMain(new float[]{1f,2f,6f}[idx-1]);return true;}}
            // Zoom presets.
            if(y>h-190&&y<h-125){String[] ps={"0.5","1","2","4","6","10","20","50","100"};float pg=(w-40)/8f;int idx=Math.round((x-20)/pg);if(idx>=0&&idx<ps.length){float v=Float.parseFloat(ps[idx]);if(v<1)selectWide();else selectMain(v);return true;}}
            // Mode chip and full mode picker.
            if(!showModeMenu && y>h-130&&y<h-65&&x<220){showModeMenu=true;invalidate();return true;}
            if(showModeMenu){
                if(x>=30&&x<=w-30&&y>=188&&y<=198+modeNames.length*58){int idx=(int)((y-198)/58);if(idx>=0&&idx<modeNames.length){mode=Mode.values()[idx];showLab=mode==Mode.LAB;showModeMenu=false;status=mode==Mode.FOTO?"FOTO • PRONTO":mode==Mode.NIGHT?"NIGHT • "+framesForMode()+" FRAMES":mode==Mode.AUTO?"AUTO • ADAPTATIVO":modeNames[idx]+" • "+framesForMode()+" FRAMES";invalidate();return true;}}
                if(y<110||y>h-110){showModeMenu=false;invalidate();return true;}
                return true;
            }
            if((showInfo||showLab)&&y<100){showInfo=false;showLab=false;invalidate();return true;}
            if(e.getPointerCount()==1&&!showInfo&&!showLab){focus(x,y);return true;}
        }
        return true;
    }

    private void selectMain(float desiredZoom){
        try{
            if(mainCameraId==null){status="CÂMERA PRINCIPAL NÃO ENCONTRADA";invalidate();return;}
            preferredCameraId=mainCameraId;
            zoom=Math.max(1f,Math.min(100f,desiredZoom));
            if(mainCameraId.equals(cameraId)){applyPreview();invalidate();return;}
            status="ABRINDO CÂMERA PRINCIPAL"; invalidate(); close(); open();
        }catch(Exception ex){status="CÂMERA PRINCIPAL INDISPONÍVEL";invalidate();}
    }

    private void selectWide(){
        try{
            if(ultraWideId==null){
                if(minHardware<=0.5f){ zoom=0.5f; setZoom(0.5f); status="0,5× • ZOOM DA CÂMERA"; invalidate(); return; }
                status="0,5× NÃO DISPONÍVEL NO CAMERA2";invalidate();return;
            }
            if(ultraWideId.equals(cameraId)){
                FloatRange rr=zoomRange(chars);
                if(rr.min<=0.5f){setZoom(0.5f);status="ULTRAWIDE • 0,5× • HARDWARE";invalidate();}
                else {status="0,5× NÃO DISPONÍVEL NESTA CÂMERA";invalidate();}
                return;
            }
            preferredCameraId=ultraWideId;
            zoom=0.5f;
            status="ABRINDO ULTRAWIDE • 0,5×"; invalidate(); close(); open();
        }catch(Exception ex){status="0,5× INDISPONÍVEL";invalidate();}
    }

}
