package com.rodrigo.ultrazoom;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.hardware.camera2.*;
import android.hardware.camera2.params.MeteringRectangle;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Size;
import android.util.SizeF;
import android.view.*;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ = 44;
    private UltraCameraView camera;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        camera = new UltraCameraView(this);
        setContentView(camera);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ);
        else camera.start();
    }
    @Override protected void onResume(){ super.onResume(); if(camera!=null && checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) camera.start(); }
    @Override protected void onPause(){ if(camera!=null) camera.stop(); super.onPause(); }
    @Override protected void onDestroy(){ if(camera!=null) camera.shutdown(); super.onDestroy(); }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==REQ && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) camera.start(); else Toast.makeText(this,"A câmera é necessária para o UltraZoom.",Toast.LENGTH_LONG).show(); }
}

class UltraCameraView extends ViewGroup {
    private enum Mode { FOTO, AUTO, PRO, ULTRA, MAX, NIGHT, LAB }
    private static final String BUILD_ID = "UZ-081-PREMIUM";
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextureView preview;
    private CameraDevice device; private CameraCaptureSession session; private CameraCharacteristics chars; private String cameraId;
    private String mainCameraId, physicalWideId; private float mainFov, wideFov;
    private Size jpegSize; private Rect sensor; private float maxHardware=1f,minHardware=1f,zoom=1f;
    private boolean flashAvailable,lowLightBoostSupported,busy,showInfo,showModeMenu,wideSupported;
    private int flashMode=0;
    private ImageReader reader; private HandlerThread cameraThread,workThread; private Handler cameraHandler,workHandler;
    private Mode mode=Mode.AUTO;
    private final List<Bitmap> frames=Collections.synchronizedList(new ArrayList<Bitmap>());
    private int target,progress; private String status="PRONTO";
    private float focusX=-1,focusY=-1; private long focusUntil;
    private float pinchStart=1f,pinchDistance=0f;
    private static final String[] MODES={"FOTO","AUTO","PRO","ULTRA","MAX","NIGHT","LAB"};
    private static final String[] DESCS={"Captura rápida","Controle inteligente","Mais detalhes","Multi-frame","Máxima potência","Noite / pouca luz","Diagnóstico"};

    UltraCameraView(Context c){
        super(c); setWillNotDraw(false); setBackgroundColor(Color.BLACK); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); startThreads();
        preview=new TextureView(c); preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
            public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){open();}
            public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){transform();}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture s){close();return true;}
            public void onSurfaceTextureUpdated(SurfaceTexture s){}
        }); addView(preview);
    }
    private void startThreads(){
        if(cameraThread==null){cameraThread=new HandlerThread("UZ-Camera");cameraThread.start();cameraHandler=new Handler(cameraThread.getLooper());}
        if(workThread==null){workThread=new HandlerThread("UZ-Work");workThread.start();workHandler=new Handler(workThread.getLooper());}
    }
    @Override protected void onMeasure(int ws,int hs){int w=Math.max(1,MeasureSpec.getSize(ws)),h=Math.max(1,MeasureSpec.getSize(hs));setMeasuredDimension(w,h);preview.measure(MeasureSpec.makeMeasureSpec(w,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(h,MeasureSpec.EXACTLY));}
    @Override protected void onLayout(boolean ch,int l,int t,int r,int b){preview.layout(0,0,getWidth(),getHeight());transform();}
    @Override protected void dispatchDraw(Canvas c){super.dispatchDraw(c);drawHud(c);}

    private void rounded(Canvas c,float l,float t,float r,float b,float rad,int color){paint.setStyle(Paint.Style.FILL);paint.setColor(color);c.drawRoundRect(l,t,r,b,rad,rad,paint);}
    private void label(Canvas c,String s,float x,float y,float size,int color,boolean bold){text.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));text.setTextSize(size);text.setColor(color);c.drawText(s,x,y,text);}
    private void centered(Canvas c,String s,float cx,float y,float size,int color,boolean bold){text.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));text.setTextSize(size);text.setColor(color);c.drawText(s,cx-text.measureText(s)/2f,y,text);}

    private void drawHud(Canvas c){
        int w=getWidth(),h=getHeight();
        // Dark glass panels preserve the camera preview while keeping controls readable.
        rounded(c,0,0,w,122,0,0xA9000000);
        rounded(c,0,h-292,w,h,0,0xD9000000);

        label(c,"ULTRAZOOM",24,30,22,Color.WHITE,true);
        label(c,MODES[mode.ordinal()],24,55,15,0xFFFFFFFF,true);
        label(c,status,24,79,13,0xD9FFFFFF,false);
        String zoomText=zoom<10?String.format(Locale.US,"%.1f×",zoom):String.format(Locale.US,"%.0f×",zoom);
        centered(c,zoomText,w-82,39,38,Color.WHITE,true);
        String kind=zoom<1?"ULTRAWIDE":"ZOOM DIGITAL / OPTICO";
        centered(c,kind,w-92,62,10,0xCCFFFFFF,false);
        String detail=busy?"CAPTURANDO  "+progress+"/"+target:"TOQUE NO OBTURADOR PARA FOTOGRAFAR";
        centered(c,detail,w-118,84,9,0xBFFFFFFF,false);

        // Lens selector: large, high-contrast and always visible.
        float top=104,gap=10,bw=(w-48-3*gap)/4f;
        String[] lens={"0,5×","1×","2×","6×"};
        for(int i=0;i<4;i++){
            float x=24+i*(bw+gap); boolean active=(i==0&&zoom<0.75f)||(i==1&&zoom>=0.75f&&zoom<1.5f)||(i==2&&zoom>=1.5f&&zoom<4)||(i==3&&zoom>=4&&zoom<8);
            rounded(c,x,top,x+bw,top+58,29,active?0xFFFFFFFF:0x66000000);
            centered(c,lens[i],x+bw/2,top+37,18,active?Color.BLACK:Color.WHITE,true);
        }

        // Zoom control.
        label(c,"ZOOM",24,h-260,15,Color.WHITE,true);
        String[] presets={"0,5","1","2","4","6","10","20","50","100"};
        float step=(w-48)/8f;
        for(int i=0;i<presets.length;i++){
            float v=Float.parseFloat(presets[i].replace(',','.')); boolean active=Math.abs(zoom-v)<(v<2?.08f:.35f);
            centered(c,presets[i]+"×",24+i*step,h-232,active?17:13,active?Color.WHITE:0xBFFFFFFF,active);
        }
        paint.setColor(0x99FFFFFF);c.drawRoundRect(24,h-207,w-24,h-202,3,3,paint);
        double lo=Math.log(.5),hi=Math.log(100),ratio=(Math.log(Math.max(.5,Math.min(100,zoom)))-lo)/(hi-lo);
        paint.setColor(Color.WHITE);c.drawCircle(24+(float)ratio*(w-48),h-204,8,paint);
        label(c,zoom<=maxHardware?"ZOOM NATIVO / HARDWARE":"ZOOM DIGITAL • PROCESSAMENTO",24,h-178,11,0xD9FFFFFF,true);
        label(c,"MAX 100×",w-92,h-178,11,0xD9FFFFFF,true);

        // Bottom toolbar: unmistakable controls.
        float cy=h-92;
        drawFlash(c,74,cy);
        drawShutter(c,w/2f,cy,busy);
        drawModeButton(c,w-74,cy);
        centered(c,"FLASH",74,cy+57,12,0xFFFFFFFF,true);
        centered(c,"FOTO",w/2f,cy+57,12,0xFFFFFFFF,true);
        centered(c,"MODO",w-74,cy+57,12,0xFFFFFFFF,true);
        label(c,"Toque na imagem para focar  •  Deslize o zoom ou use dois dedos",24,h-24,11,0xD9FFFFFF,false);
        label(c,"ⓘ",w-38,h-24,20,Color.WHITE,true);

        if(focusUntil>System.currentTimeMillis()){
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2.5f);paint.setColor(Color.WHITE);c.drawRoundRect(focusX-36,focusY-36,focusX+36,focusY+36,5,5,paint);paint.setStyle(Paint.Style.FILL);postInvalidateDelayed(80);
        }
        if(showModeMenu)drawModeSheet(c); if(showInfo)drawInfo(c);
    }
    private void drawFlash(Canvas c,float x,float y){
        rounded(c,x-43,y-43,x+43,y+43,22,flashMode==0?0x77000000:0xFFFFFFFF);
        label(c,"⚡",x-10,y+9,25,flashMode==0?Color.WHITE:Color.BLACK,true);
        label(c,flashMode==0?"OFF":flashMode==1?"AUTO":"ON",x-15,y+29,9,flashMode==0?0xD9FFFFFF:Color.BLACK,true);
    }
    private void drawShutter(Canvas c,float x,float y,boolean b){
        paint.setStyle(Paint.Style.FILL);paint.setColor(0xFFFFFFFF);c.drawCircle(x,y,48,paint);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(4);paint.setColor(0xFF111111);c.drawCircle(x,y,39,paint);paint.setStyle(Paint.Style.FILL);
        if(b){paint.setColor(0xFF111111);c.drawRoundRect(x-11,y-11,x+11,y+11,4,4,paint);}
    }
    private void drawModeButton(Canvas c,float x,float y){
        rounded(c,x-43,y-43,x+43,y+43,22,0x77000000);
        label(c,"MODE",x-20,y+5,12,Color.WHITE,true);
        label(c,MODES[mode.ordinal()],x-21,y+27,9,Color.WHITE,true);
    }
    private void drawModeSheet(Canvas c){
        int w=getWidth(),h=getHeight(); rounded(c,12,116,w-12,h-72,30,0xF20A0A0A);
        label(c,"MODO DE CAPTURA",34,157,25,Color.WHITE,true);
        float y=180;
        for(int i=0;i<MODES.length;i++){
            boolean a=i==mode.ordinal(); rounded(c,26,y,w-26,y+62,20,a?0xFFFFFFFF:0x331FFFFFFF);
            label(c,MODES[i],48,y+27,18,a?Color.BLACK:Color.WHITE,true);
            label(c,DESCS[i],48,y+48,11,a?0xFF333333:0xBFFFFFFF,false); y+=69;
        }
        label(c,"Toque fora para fechar",34,h-91,11,0xBFFFFFFF,false);
    }
    private void drawInfo(Canvas c){
        int w=getWidth(),h=getHeight(); rounded(c,16,115,w-16,h-80,28,0xF50A0A0A);
        label(c,"INFORMAÇÕES",38,155,25,Color.WHITE,true);
        float y=192; int gap=28;
        label(c,"Zoom atual",38,y,12,0x99FFFFFF,false);label(c,String.format(Locale.US,"%.1f×",zoom),210,y,15,Color.WHITE,true);y+=gap;
        label(c,"Modo",38,y,12,0x99FFFFFF,false);label(c,MODES[mode.ordinal()],210,y,15,Color.WHITE,true);y+=gap;
        label(c,"Lente",38,y,12,0x99FFFFFF,false);label(c,zoom<1?"ULTRAWIDE":"PRINCIPAL",210,y,15,Color.WHITE,true);y+=gap;
        label(c,"Hardware máx.",38,y,12,0x99FFFFFF,false);label(c,String.format(Locale.US,"%.1f×",maxHardware),210,y,15,Color.WHITE,true);y+=gap;
        label(c,"Flash",38,y,12,0x99FFFFFF,false);label(c,flashAvailable?"Disponível":"Indisponível",210,y,15,Color.WHITE,true);y+=gap;
        label(c,"Night Boost",38,y,12,0x99FFFFFF,false);label(c,lowLightBoostSupported?"Disponível":"Não disponível",210,y,15,Color.WHITE,true);y+=gap;
        label(c,"Frames",38,y,12,0x99FFFFFF,false);label(c,String.valueOf(framesForMode()),210,y,15,Color.WHITE,true);y+=gap;
        label(c,"Build",38,y,12,0x99FFFFFF,false);label(c,BUILD_ID,210,y,15,Color.WHITE,true);
        label(c,"Toque no topo para fechar",38,h-110,12,0xBFFFFFFF,false);
    }

    private boolean isWide(){return zoom<0.75f;}
    private void open(){
        try{
            CameraManager m=(CameraManager)getContext().getSystemService(Context.CAMERA_SERVICE);
            mainCameraId=null;physicalWideId=null;mainFov=0;wideFov=0;wideSupported=false;
            String fallback=null; long largest=-1;
            for(String id:m.getCameraIdList()){
                CameraCharacteristics cc=m.getCameraCharacteristics(id); Integer facing=cc.get(CameraCharacteristics.LENS_FACING);
                if(facing==null||facing!=CameraCharacteristics.LENS_FACING_BACK)continue;
                if(fallback==null)fallback=id;
                float fov=horizontalFov(cc); Size pa=cc.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
                long area=pa==null?0:(long)pa.getWidth()*pa.getHeight();
                if(area>largest){largest=area;mainCameraId=id;mainFov=fov;}
            }
            if(mainCameraId==null)mainCameraId=fallback; if(mainCameraId==null)return;
            CameraCharacteristics main=m.getCameraCharacteristics(mainCameraId);
            RangeZ mr=range(main); minHardware=mr.min;maxHardware=mr.max;
            // Prefer the logical camera's native 0.5x range. This is the correct path on many modern multi-camera phones.
            if(minHardware<=0.6f){wideSupported=true;physicalWideId=mainCameraId;}
            else{
                for(String id:m.getCameraIdList()){
                    CameraCharacteristics cc=m.getCameraCharacteristics(id);Integer facing=cc.get(CameraCharacteristics.LENS_FACING);if(facing==null||facing!=CameraCharacteristics.LENS_FACING_BACK||id.equals(mainCameraId))continue;
                    float fov=horizontalFov(cc);if(fov>wideFov){wideFov=fov;physicalWideId=id;}
                }
                if(physicalWideId!=null&&wideFov>mainFov*1.15f)wideSupported=true; else physicalWideId=null;
            }
            if(cameraId==null||(!cameraId.equals(mainCameraId)&&!cameraId.equals(physicalWideId)))cameraId=mainCameraId;
            chars=m.getCameraCharacteristics(cameraId);sensor=chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);RangeZ rr=range(chars);minHardware=rr.min;maxHardware=rr.max;
            prepareReader(chars);
            flashAvailable=Boolean.TRUE.equals(chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)); lowLightBoostSupported=false;
            if(Build.VERSION.SDK_INT>=35){int[] ae=chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES);if(ae!=null)for(int v:ae)if(v==CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY)lowLightBoostSupported=true;}
            if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)m.openCamera(cameraId,new CameraDevice.StateCallback(){public void onOpened(CameraDevice d){device=d;createSession();}public void onDisconnected(CameraDevice d){d.close();device=null;}public void onError(CameraDevice d,int e){d.close();device=null;status="ERRO NA CÂMERA";postInvalidate();}},cameraHandler);
        }catch(Exception e){status="CÂMERA INDISPONÍVEL";postInvalidate();}
    }
    private void prepareReader(CameraCharacteristics cc){
        if(reader!=null){reader.close();reader=null;}
        android.hardware.camera2.params.StreamConfigurationMap map=cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        jpegSize=new Size(1920,1080);
        if(map!=null){Size[] ss=map.getOutputSizes(android.graphics.ImageFormat.JPEG);if(ss!=null&&ss.length>0){Size best=ss[0];for(Size s:ss)if((long)s.getWidth()*s.getHeight()>(long)best.getWidth()*best.getHeight())best=s;jpegSize=best;}}
        reader=ImageReader.newInstance(jpegSize.getWidth(),jpegSize.getHeight(),android.graphics.ImageFormat.JPEG,12);
        reader.setOnImageAvailableListener(rdr->{Image im=null;try{im=rdr.acquireNextImage();if(im!=null&&busy){ByteBuffer b=im.getPlanes()[0].getBuffer();byte[] d=new byte[b.remaining()];b.get(d);BitmapFactory.Options opt=new BitmapFactory.Options();opt.inPreferredConfig=Bitmap.Config.ARGB_8888;int samples=target>1&&jpegSize.getWidth()>3000?4:(target>1&&jpegSize.getWidth()>1600?2:1);opt.inSampleSize=samples;Bitmap bm=BitmapFactory.decodeByteArray(d,0,d.length,opt);if(bm!=null)frames.add(bm);}}catch(Exception ignored){}finally{if(im!=null)im.close();}},workHandler);
    }
    private float horizontalFov(CameraCharacteristics cc){try{float[] fs=cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);SizeF s=cc.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);if(fs!=null&&fs.length>0&&s!=null&&fs[0]>0)return(float)(2*Math.atan(s.getWidth()/(2*fs[0])));}catch(Exception ignored){}return 0;}
    private static class RangeZ{final float min,max;RangeZ(float a,float b){min=a;max=b;}}
    private RangeZ range(CameraCharacteristics cc){if(Build.VERSION.SDK_INT>=30){Range<Float> r=cc.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);if(r!=null)return new RangeZ(r.getLower(),r.getUpper());}Float z=cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);return new RangeZ(1,Math.max(1,z==null?1:z));}
    private void createSession(){try{SurfaceTexture st=preview.getSurfaceTexture();if(st==null||device==null)return;st.setDefaultBufferSize(1920,1080);Surface ps=new Surface(st);device.createCaptureSession(Arrays.asList(ps,reader.getSurface()),new CameraCaptureSession.StateCallback(){public void onConfigured(CameraCaptureSession s){session=s;applyPreview();}public void onConfigureFailed(CameraCaptureSession s){status="FALHA NA CÂMERA";postInvalidate();}},cameraHandler);}catch(Exception ignored){}}

    private CaptureRequest.Builder request(int template)throws Exception{
        CaptureRequest.Builder b=device.createCaptureRequest(template);
        b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        int ae=CaptureRequest.CONTROL_AE_MODE_ON;
        if(mode==Mode.NIGHT&&lowLightBoostSupported)ae=CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY;
        if(template==CameraDevice.TEMPLATE_STILL_CAPTURE&&flashAvailable){if(flashMode==1)ae=CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH;else if(flashMode==2)ae=CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH;}
        b.set(CaptureRequest.CONTROL_AE_MODE,ae);
        if(mode==Mode.NIGHT){Range<Integer> ar=chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);if(ar!=null)b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION,Math.min(ar.getUpper(),Math.max(ar.getLower(),2)));}
        if(flashAvailable)b.set(CaptureRequest.FLASH_MODE,flashMode==2?CaptureRequest.FLASH_MODE_SINGLE:CaptureRequest.FLASH_MODE_OFF);
        if(Build.VERSION.SDK_INT>=30&&!isWide()&&zoom<=maxHardware)b.set(CaptureRequest.CONTROL_ZOOM_RATIO,Math.max(1,Math.min(maxHardware,zoom)));
        else if(Build.VERSION.SDK_INT>=30&&isWide()&&cameraId.equals(mainCameraId))b.set(CaptureRequest.CONTROL_ZOOM_RATIO,Math.max(minHardware,Math.min(maxHardware,.5f)));
        else b.set(CaptureRequest.SCALER_CROP_REGION,crop(isWide()?1:Math.max(1,zoom)));
        // Digital extension beyond the camera's native range: crop the sensor instead of merely changing the label.
        if(Build.VERSION.SDK_INT>=30&&!isWide()&&zoom>maxHardware)b.set(CaptureRequest.SCALER_CROP_REGION,crop(zoom));
        return b;
    }
    private Rect crop(float z){if(sensor==null)return null;z=Math.max(1,z);int cw=Math.max(2,(int)(sensor.width()/z)),ch=Math.max(2,(int)(sensor.height()/z));return new Rect(sensor.centerX()-cw/2,sensor.centerY()-ch/2,sensor.centerX()+cw/2,sensor.centerY()+ch/2);}
    private void applyPreview(){try{if(session==null)return;CaptureRequest.Builder b=request(CameraDevice.TEMPLATE_PREVIEW);b.addTarget(new Surface(preview.getSurfaceTexture()));session.setRepeatingRequest(b.build(),null,cameraHandler);transform();}catch(Exception ignored){}}
    private void transform(){if(preview!=null)preview.setTransform(new Matrix());}

    private void selectWide(){
        if(!wideSupported){status="0,5× NÃO DISPONÍVEL NESTE APARELHO";invalidate();return;}
        zoom=.5f;
        if(!cameraId.equals(physicalWideId)){cameraId=physicalWideId;close();open();}
        else {status="0,5× • ULTRAWIDE";applyPreview();invalidate();}
    }
    private void selectMain(float z){
        if(mainCameraId==null){status="CÂMERA PRINCIPAL INDISPONÍVEL";invalidate();return;}
        zoom=Math.max(1,Math.min(100,z));
        if(!cameraId.equals(mainCameraId)){cameraId=mainCameraId;close();open();}
        else {status=zoom>maxHardware?"ZOOM DIGITAL • "+String.format(Locale.US,"%.0f×",zoom):"ZOOM • "+String.format(Locale.US,"%.1f×",zoom);applyPreview();invalidate();}
    }
    private int framesForMode(){switch(mode){case FOTO:return 1;case PRO:return 3;case ULTRA:return 5;case MAX:return 7;case NIGHT:return 8;case LAB:return 6;default:return autoFrames();}}
    private int autoFrames(){ActivityManager am=(ActivityManager)getContext().getSystemService(Context.ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();if(am!=null)am.getMemoryInfo(mi);long mb=mi.availMem/1048576;return zoom<3?1:(mb>3500?5:mb>2000?3:2);}
    private void capture(){if(busy||session==null||device==null)return;busy=true;frames.clear();target=framesForMode();progress=0;status=mode==Mode.NIGHT?"NIGHT • PREPARANDO":"CAPTURANDO";issue();invalidate();}
    private void issue(){if(!busy)return;try{CaptureRequest.Builder b=request(CameraDevice.TEMPLATE_STILL_CAPTURE);b.addTarget(reader.getSurface());b.set(CaptureRequest.JPEG_ORIENTATION,rotation());session.capture(b.build(),new CameraCaptureSession.CaptureCallback(){@Override public void onCaptureCompleted(CameraCaptureSession s,CaptureRequest r,TotalCaptureResult result){progress++;if(progress<target)workHandler.postDelayed(()->issue(),mode==Mode.NIGHT?140:65);else workHandler.post(()->finishBurst());}},cameraHandler);}catch(Exception e){busy=false;status="FALHA AO FOTOGRAFAR";invalidate();}}
    private void finishBurst(){long end=System.currentTimeMillis()+5000;while(frames.size()<target&&System.currentTimeMillis()<end){try{Thread.sleep(20);}catch(Exception ignored){}}
        Bitmap best=null; synchronized(frames){if(!frames.isEmpty()){List<Bitmap> copy=new ArrayList<>(frames);if(mode==Mode.NIGHT&&copy.size()>1)best=nightMerge(copy);else best=bestFrame(copy);}}
        if(best!=null)save(best,mode==Mode.NIGHT?"NIGHT":MODES[mode.ordinal()]);complete(frames.size()+" frame(s) • FOTO SALVA");
    }
    private Bitmap bestFrame(List<Bitmap> list){Bitmap best=list.get(0);double score=-1;for(Bitmap b:list){double s=sharpnessScore(b);if(s>score){score=s;best=b;}}return best;}
    private double sharpnessScore(Bitmap b){int w=Math.min(320,b.getWidth()),h=Math.min(240,b.getHeight());Bitmap s=Bitmap.createScaledBitmap(b,w,h,true);int[] px=new int[w*h];s.getPixels(px,0,w,0,0,w,h);double sum=0,sum2=0;int n=0;for(int y=1;y<h-1;y+=2)for(int x=1;x<w-1;x+=2){int i=y*w+x,c=Color.red(px[i])+Color.green(px[i])+Color.blue(px[i]),l=Color.red(px[i-1])+Color.green(px[i-1])+Color.blue(px[i-1]),r=Color.red(px[i+1])+Color.green(px[i+1])+Color.blue(px[i+1]),u=Color.red(px[i-w])+Color.green(px[i-w])+Color.blue(px[i-w]),d=Color.red(px[i+w])+Color.green(px[i+w])+Color.blue(px[i+w]);double q=c*4-l-r-u-d;sum+=q;sum2+=q*q;n++;}if(s!=b)s.recycle();double mean=sum/Math.max(1,n);return sum2/Math.max(1,n)-mean*mean;}

    // Lightweight multi-frame alignment and fusion for Night mode. It estimates a small translation on a thumbnail,
    // applies that translation to the full-resolution frame, averages aligned pixels, then applies a gentle lift/gamma.
    private Bitmap nightMerge(List<Bitmap> list){
        Bitmap ref=list.get(0);int w=ref.getWidth(),h=ref.getHeight();Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);int[] acc=new int[w*h*3];int[] px=new int[w*h];int count=0;
        for(Bitmap b:list){if(b==null)continue;int[] shift=estimateShift(ref,b);b.getPixels(px,0,w,0,0,w,h);int dx=shift[0],dy=shift[1];for(int y=0;y<h;y++){int sy=y-dy;if(sy<0||sy>=h)continue;for(int x=0;x<w;x++){int sx=x-dx;if(sx<0||sx>=w)continue;int src=sy*w+sx,dst=y*w+x,j=dst*3;acc[j]+=Color.red(px[src]);acc[j+1]+=Color.green(px[src]);acc[j+2]+=Color.blue(px[src]);}}count++;}
        if(count==0)return ref;int[] outPx=new int[w*h];for(int i=0,j=0;i<outPx.length;i++,j+=3){int r=acc[j]/count,g=acc[j+1]/count,b=acc[j+2]/count;outPx[i]=Color.rgb(nightTone(r),nightTone(g),nightTone(b));}out.setPixels(outPx,0,w,0,0,w,h);return out;
    }
    private int nightTone(int v){double n=v/255.0;double lifted=Math.pow(Math.min(1,n*1.22),0.78);return Math.max(0,Math.min(255,(int)(lifted*255)));}
    private int[] estimateShift(Bitmap ref,Bitmap b){if(ref==b)return new int[]{0,0};int sw=96,sh=64;Bitmap a=Bitmap.createScaledBitmap(ref,sw,sh,true),q=Bitmap.createScaledBitmap(b,sw,sh,true);int[] ap=new int[sw*sh],bp=new int[sw*sh];a.getPixels(ap,0,sw,0,0,sw,sh);q.getPixels(bp,0,sw,0,0,sw,sh);double best=Double.MAX_VALUE;int bx=0,by=0;for(int dy=-4;dy<=4;dy++)for(int dx=-4;dx<=4;dx++){double e=0;int n=0;for(int y=6;y<sh-6;y+=3){int yy=y+dy;if(yy<0||yy>=sh)continue;for(int x=6;x<sw-6;x+=3){int xx=x+dx;if(xx<0||xx>=sw)continue;int ca=ap[y*sw+x],cb=bp[yy*sw+xx];int va=(Color.red(ca)+Color.green(ca)+Color.blue(ca))/3,vb=(Color.red(cb)+Color.green(cb)+Color.blue(cb))/3;e+=Math.abs(va-vb);n++;}}if(n>0&&e/n<best){best=e/n;bx=dx;by=dy;}}a.recycle();q.recycle();int fx=Math.round(bx*(float)ref.getWidth()/sw),fy=Math.round(by*(float)ref.getHeight()/sh);return new int[]{Math.max(-24,Math.min(24,fx)),Math.max(-24,Math.min(24,fy))};}

    private int rotation(){int r=getContext().getDisplay().getRotation();return r==Surface.ROTATION_0?90:r==Surface.ROTATION_90?0:r==Surface.ROTATION_180?270:180;}
    private void save(Bitmap b,String tag){try{ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,"UltraZoom_"+tag+"_"+System.currentTimeMillis()+".jpg");v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/UltraZoom");Uri u=getContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u!=null){OutputStream o=getContext().getContentResolver().openOutputStream(u);b.compress(Bitmap.CompressFormat.JPEG,97,o);if(o!=null)o.close();}}catch(Exception ignored){}}
    private void complete(String s){busy=false;target=0;status=s;postInvalidate();postDelayed(()->{if(!busy){status=MODES[mode.ordinal()]+" • PRONTO";invalidate();}},1800);}
    private void focus(float x,float y){if(session==null||device==null||sensor==null)return;focusX=x;focusY=y;focusUntil=System.currentTimeMillis()+1200;try{float vx=Math.max(0,Math.min(1,x/getWidth())),vy=Math.max(0,Math.min(1,y/getHeight()));int fx=(int)(sensor.left+vx*sensor.width()),fy=(int)(sensor.top+vy*sensor.height());int sz=Math.max(100,sensor.width()/8);Rect r=new Rect(Math.max(sensor.left,fx-sz/2),Math.max(sensor.top,fy-sz/2),Math.min(sensor.right,fx+sz/2),Math.min(sensor.bottom,fy+sz/2));CaptureRequest.Builder b=request(CameraDevice.TEMPLATE_PREVIEW);b.addTarget(new Surface(preview.getSurfaceTexture()));b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_AUTO);b.set(CaptureRequest.CONTROL_AF_TRIGGER,CaptureRequest.CONTROL_AF_TRIGGER_START);b.set(CaptureRequest.CONTROL_AF_REGIONS,new MeteringRectangle[]{new MeteringRectangle(r,MeteringRectangle.METERING_WEIGHT_MAX-1)});session.capture(b.build(),null,cameraHandler);applyPreview();}catch(Exception ignored){}invalidate();}

    @Override public boolean onInterceptTouchEvent(MotionEvent e){return true;}
    @Override public boolean onTouchEvent(MotionEvent e){
        int w=getWidth(),h=getHeight();float x=e.getX(),y=e.getY();
        if(e.getPointerCount()==2){if(e.getActionMasked()==MotionEvent.ACTION_POINTER_DOWN||e.getActionMasked()==MotionEvent.ACTION_DOWN){pinchDistance=distance(e);pinchStart=zoom;}else if(e.getActionMasked()==MotionEvent.ACTION_MOVE&&pinchDistance>0){float d=distance(e);float factor=d/pinchDistance;float nz=Math.max(.5f,Math.min(100,pinchStart*factor));if(nz<1)selectWide();else selectMain(nz);}else if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL)pinchDistance=0;return true;}
        if(e.getActionMasked()==MotionEvent.ACTION_DOWN)return true;
        if(e.getActionMasked()==MotionEvent.ACTION_MOVE){if(y>h-220&&y<h-145){float ratio=Math.max(0,Math.min(1,(x-24)/(float)(w-48)));float nz=(float)Math.exp(Math.log(.5)+ratio*(Math.log(100)-Math.log(.5)));if(nz<.75)selectWide();else selectMain(nz);}return true;}
        if(e.getActionMasked()!=MotionEvent.ACTION_UP)return true;
        if(showInfo){if(y<180){showInfo=false;invalidate();}return true;}
        if(showModeMenu){if(y>=175&&y<=175+MODES.length*69){int i=(int)((y-175)/69);if(i>=0&&i<MODES.length){mode=Mode.values()[i];showModeMenu=false;status=MODES[i]+" • PRONTO";applyPreview();invalidate();}}else{showModeMenu=false;invalidate();}return true;}
        if(y>h-155&&x<w*.28f){if(!flashAvailable){status="FLASH INDISPONÍVEL";}else{flashMode=(flashMode+1)%3;status=flashMode==0?"FLASH • OFF":flashMode==1?"FLASH • AUTO":"FLASH • ON";}invalidate();return true;}
        if(y>h-155&&x>w*.72f){showModeMenu=true;invalidate();return true;}
        if(y>h-155&&Math.abs(x-w/2f)<100){capture();return true;}
        if(y>=100&&y<=172){float gap=10,bw=(w-48-3*gap)/4f;int i=(int)((x-24)/(bw+gap));if(i==0)selectWide();else if(i==1)selectMain(1);else if(i==2)selectMain(2);else if(i==3)selectMain(6);return true;}
        if(y>h-285&&y<h-150){float ratio=Math.max(0,Math.min(1,(x-24)/(float)(w-48)));float nz=(float)Math.exp(Math.log(.5)+ratio*(Math.log(100)-Math.log(.5)));if(nz<.75)selectWide();else selectMain(nz);return true;}
        if((y<105&&x>w-150)||(y>h-58&&x>w-90)){showInfo=true;invalidate();return true;}
        focus(x,y);return true;
    }
    private float distance(MotionEvent e){float dx=e.getX(1)-e.getX(0),dy=e.getY(1)-e.getY(0);return(float)Math.sqrt(dx*dx+dy*dy);}
    void start(){startThreads();if(preview.isAvailable()&&device==null)open();}
    void stop(){close();}
    private void close(){try{if(session!=null){session.close();session=null;}if(device!=null){device.close();device=null;}}catch(Exception ignored){}}
    void shutdown(){close();try{if(reader!=null)reader.close();}catch(Exception ignored){}try{if(cameraThread!=null)cameraThread.quitSafely();}catch(Exception ignored){}try{if(workThread!=null)workThread.quitSafely();}catch(Exception ignored){}}
}
