package com.rodrigo.ultrazoom;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.*;
import android.hardware.camera2.params.MeteringRectangle;
import android.media.Image;
import android.media.ImageReader;
import android.graphics.ImageFormat;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.Size;
import android.util.SizeF;
import android.view.*;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ = 44;
    private UltraCameraView camera;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); camera=new UltraCameraView(this); setContentView(camera); if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.CAMERA},REQ); else camera.start(); }
    @Override protected void onResume(){super.onResume(); if(camera!=null&&checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) camera.start();}
    @Override protected void onPause(){if(camera!=null)camera.stop();super.onPause();}
    @Override protected void onDestroy(){if(camera!=null)camera.shutdown();super.onDestroy();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)camera.start();else Toast.makeText(this,"A câmera é necessária para o UltraZoom.",Toast.LENGTH_LONG).show();}
}

class UltraCameraView extends ViewGroup {
    private enum Mode { FOTO,AUTO,PRO,ULTRA,MAX,NIGHT,LAB }
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG), text=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextureView preview;
    private CameraDevice device; private CameraCaptureSession session; private CameraCharacteristics chars; private String cameraId;
    private String mainCameraId,ultraWideId; private final ArrayList<String> backIds=new ArrayList<>();
    private Size jpegSize; private Rect sensor; private float maxHardware=1f,minHardware=1f,zoom=1f;
    private boolean flashAvailable,lowLightBoostSupported,busy,showInfo,showModeMenu; private int flashMode=0;
    private ImageReader reader; private HandlerThread cameraThread,workThread; private Handler cameraHandler,workHandler;
    private Mode mode=Mode.AUTO; private final List<Bitmap> frames=Collections.synchronizedList(new ArrayList<Bitmap>()); private int target,issued; private int progress; private String status="PRONTO";
    private float focusX=-1,focusY=-1; private long focusUntil;
    private static final String[] MODES={"FOTO","AUTO","PRO","ULTRA","MAX","NIGHT","LAB"};

    UltraCameraView(Context c){super(c);setWillNotDraw(false);setBackgroundColor(Color.BLACK);text.setTypeface(Typeface.create("sans",Typeface.BOLD));startThreads();
        preview=new TextureView(c); preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){open();}public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){transform();}public boolean onSurfaceTextureDestroyed(SurfaceTexture s){close();return true;}public void onSurfaceTextureUpdated(SurfaceTexture s){}});addView(preview);
    }
    private void startThreads(){if(cameraThread==null){cameraThread=new HandlerThread("UZ-Camera");cameraThread.start();cameraHandler=new Handler(cameraThread.getLooper());}if(workThread==null){workThread=new HandlerThread("UZ-Work");workThread.start();workHandler=new Handler(workThread.getLooper());}}
    @Override protected void onMeasure(int ws,int hs){int w=Math.max(1,MeasureSpec.getSize(ws)),h=Math.max(1,MeasureSpec.getSize(hs));setMeasuredDimension(w,h);preview.measure(MeasureSpec.makeMeasureSpec(w,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(h,MeasureSpec.EXACTLY));}
    @Override protected void onLayout(boolean ch,int l,int t,int r,int b){preview.layout(0,0,getWidth(),getHeight());transform();}
    @Override protected void dispatchDraw(Canvas c){super.dispatchDraw(c);drawHud(c);}

    private void drawHud(Canvas c){int w=getWidth(),h=getHeight();
        // Premium visual hierarchy: compact top status, large lens rail, large shutter and bottom toolbar.
        paint.setStyle(Paint.Style.FILL);paint.setColor(0xB0000000);c.drawRect(0,0,w,92,paint);c.drawRect(0,h-250,w,h,paint);
        text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setColor(Color.WHITE);text.setTextSize(18);c.drawText("ULTRAZOOM",24,30,text);
        text.setTextSize(13);text.setColor(0xE6FFFFFF);c.drawText(MODES[mode.ordinal()],24,54,text);
        String z=zoom<10?String.format(Locale.US,"%.1f×",zoom):String.format(Locale.US,"%.0f×",zoom);text.setTextSize(42);text.setColor(Color.WHITE);float zw=text.measureText(z);c.drawText(z,w-24-zw,42,text);
        text.setTypeface(Typeface.DEFAULT);text.setTextSize(11);String cam=isWide()?"ULTRAWIDE • LENTE FÍSICA":"PRINCIPAL • CÂMERA PRINCIPAL";c.drawText(cam,24,76,text);String s=status+(busy?"  "+progress+"/"+target:"");float sw=text.measureText(s);c.drawText(s,w-24-sw,76,text);

        // Lens rail
        float railY=112,gap=10,bw=(w-48-3*gap)/4f;String[] lens={"0,5×","1×","2×","6×"};
        for(int i=0;i<4;i++){float x=24+i*(bw+gap);boolean active=(i==0&&isWide())||(i==1&&!isWide()&&Math.abs(zoom-1)<.12)||(i==2&&!isWide()&&Math.abs(zoom-2)<.16)||(i==3&&!isWide()&&Math.abs(zoom-6)<.35);paint.setColor(active?0xFFFFFFFF:0x66000000);c.drawRoundRect(x,railY,x+bw,railY+50,25,25,paint);text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setTextSize(17);text.setColor(active?Color.BLACK:Color.WHITE);float tw=text.measureText(lens[i]);c.drawText(lens[i],x+(bw-tw)/2,railY+32,text);}

        // Zoom scale
        text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setTextSize(14);text.setColor(Color.WHITE);c.drawText("ZOOM",24,h-215,text);String[] presets={"0,5","1","2","4","6","10","20","50","100"};float px=24,step=(w-48)/8f;for(int i=0;i<presets.length;i++){float val=Float.parseFloat(presets[i].replace(',','.'));boolean active=Math.abs(zoom-val)<(val<2?.08f:.25f);text.setTextSize(active?18:14);text.setColor(active?Color.WHITE:0xBFFFFFFF);text.setTypeface(active?Typeface.create("sans",Typeface.BOLD):Typeface.DEFAULT);c.drawText(presets[i]+"×",px+i*step,h-185,text);}paint.setColor(0x66FFFFFF);c.drawRoundRect(24,h-166,w-24,h-162,3,3,paint);float ratio=(float)((Math.log(Math.max(.5,zoom))-Math.log(.5))/(Math.log(100)-Math.log(.5)));paint.setColor(Color.WHITE);c.drawCircle(24+Math.max(0,Math.min(1,ratio))*(w-48),h-164,6,paint);

        // Bottom premium controls
        float cy=h-83;drawRoundControl(c,68,cy,"⚡",flashMode==0?"FLASH":"FLASH "+(flashMode==1?"AUTO":"ON"),flashMode!=0);drawShutter(c,w/2f,cy,busy);drawRoundControl(c,w-68,cy,"☰",MODES[mode.ordinal()],showModeMenu);
        text.setTypeface(Typeface.DEFAULT);text.setTextSize(11);text.setColor(0xDDFFFFFF);c.drawText("Toque para focar",24,h-20,text);String info="ⓘ INFO";float iw=text.measureText(info);c.drawText(info,w-24-iw,h-20,text);
        if(focusUntil>System.currentTimeMillis()){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2);paint.setColor(Color.WHITE);c.drawRect(focusX-34,focusY-34,focusX+34,focusY+34,paint);paint.setStyle(Paint.Style.FILL);postInvalidateDelayed(80);}
        if(showModeMenu)drawModeSheet(c);if(showInfo)drawInfo(c);
    }
    private void drawRoundControl(Canvas c,float x,float y,String icon,String label,boolean active){paint.setColor(active?0xEEFFFFFF:0x88000000);c.drawRoundRect(x-54,y-28,x+54,y+28,28,28,paint);text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setTextSize(17);text.setColor(active?Color.BLACK:Color.WHITE);c.drawText(icon,x-text.measureText(icon)/2,y+6,text);text.setTextSize(10);c.drawText(label,x-text.measureText(label)/2,y+43,text);}
    private void drawShutter(Canvas c,float x,float y,boolean b){paint.setColor(0xF5FFFFFF);c.drawCircle(x,y,37,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3);paint.setColor(Color.BLACK);c.drawCircle(x,y,30,paint);paint.setStyle(Paint.Style.FILL);if(b){paint.setColor(Color.BLACK);c.drawRoundRect(x-9,y-9,x+9,y+9,3,3,paint);}}
    private void drawModeSheet(Canvas c){int w=getWidth(),h=getHeight();paint.setColor(0xF5080808);c.drawRoundRect(14,150,w-14,h-95,28,28,paint);text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setTextSize(25);text.setColor(Color.WHITE);c.drawText("MODO",34,190,text);String[] desc={"Foto simples e rápida","Escolha inteligente","Processamento moderado","Fusão de vários frames","Máxima potência","Baixa luz / noite","Ferramentas de teste"};float y=220;for(int i=0;i<MODES.length;i++){boolean a=i==mode.ordinal();paint.setColor(a?0xFFFFFFFF:0x33FFFFFF);c.drawRoundRect(28,y,w-28,y+54,18,18,paint);text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setTextSize(17);text.setColor(a?Color.BLACK:Color.WHITE);c.drawText(MODES[i],48,y+23,text);text.setTypeface(Typeface.DEFAULT);text.setTextSize(10);text.setColor(a?0xFF333333:0xBFFFFFFF);c.drawText(desc[i],48,y+41,text);y+=60;}}
    private void drawInfo(Canvas c){int w=getWidth(),h=getHeight();paint.setColor(0xF20A0A0A);c.drawRoundRect(18,115,w-18,h-115,26,26,paint);text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setTextSize(24);text.setColor(Color.WHITE);c.drawText("INFORMAÇÕES",38,155,text);text.setTypeface(Typeface.DEFAULT);text.setTextSize(13);float y=190;c.drawText("Zoom: "+String.format(Locale.US,"%.1f×",zoom),38,y,text);y+=25;c.drawText("Câmera: "+(isWide()?"ULTRAWIDE":"PRINCIPAL"),38,y,text);y+=25;c.drawText("Hardware: "+String.format(Locale.US,"%.1f×",maxHardware),38,y,text);y+=25;c.drawText("Flash: "+(flashAvailable?"disponível":"não disponível"),38,y,text);y+=25;c.drawText("Night Boost: "+(lowLightBoostSupported?"disponível":"não disponível"),38,y,text);y+=25;c.drawText("Modo: "+MODES[mode.ordinal()],38,y,text);y+=25;c.drawText("Frames: "+framesForMode(),38,y,text);y+=40;text.setTypeface(Typeface.create("sans",Typeface.BOLD));c.drawText("LAB / DIAGNÓSTICO",38,y,text);}

    private boolean isWide(){return cameraId!=null&&cameraId.equals(ultraWideId);}
    private void open(){try{CameraManager m=(CameraManager)getContext().getSystemService(Context.CAMERA_SERVICE);String best=null;float widest=0;long largest=-1;for(String id:m.getCameraIdList()){CameraCharacteristics cc=m.getCameraCharacteristics(id);Integer f=cc.get(CameraCharacteristics.LENS_FACING);if(f==null||f!=CameraCharacteristics.LENS_FACING_BACK)continue;backIds.add(id);float fov=horizontalFov(cc);if(fov>widest){widest=fov;ultraWideId=id;}Size pa=cc.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);long area=pa==null?0:(long)pa.getWidth()*pa.getHeight();if(area>largest){largest=area;mainCameraId=id;}if(best==null)best=id;}if(mainCameraId==null)mainCameraId=best;if(cameraId!=null&&backIds.contains(cameraId))best=cameraId;else if(mainCameraId!=null)best=mainCameraId;cameraId=best;if(cameraId==null)return;chars=m.getCameraCharacteristics(cameraId);sensor=chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);RangeZ r=range(chars);minHardware=r.min;maxHardware=r.max;if(reader!=null)reader.close();android.hardware.camera2.params.StreamConfigurationMap map=chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);jpegSize=new Size(1920,1080);if(map!=null){Size[] ss=map.getOutputSizes(ImageFormat.JPEG);if(ss!=null&&ss.length>0){jpegSize=ss[0];for(Size s:ss)if((long)s.getWidth()*s.getHeight()>(long)jpegSize.getWidth()*jpegSize.getHeight())jpegSize=s;}}flashAvailable=Boolean.TRUE.equals(chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE));lowLightBoostSupported=false;if(Build.VERSION.SDK_INT>=35){int[] ae=chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES);if(ae!=null)for(int v:ae)if(v==CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY)lowLightBoostSupported=true;}reader=ImageReader.newInstance(jpegSize.getWidth(),jpegSize.getHeight(),ImageFormat.JPEG,24);reader.setOnImageAvailableListener(rdr->{Image im=null;try{im=rdr.acquireNextImage();if(im!=null&&busy){ByteBuffer b=im.getPlanes()[0].getBuffer();byte[] d=new byte[b.remaining()];b.get(d);BitmapFactory.Options opt=new BitmapFactory.Options(); opt.inPreferredConfig=Bitmap.Config.ARGB_8888; opt.inSampleSize=(mode==Mode.NIGHT&&jpegSize.getWidth()>3000)?2:1; Bitmap bm=BitmapFactory.decodeByteArray(d,0,d.length,opt); if(bm!=null)frames.add(bm);}}catch(Exception ignored){}finally{if(im!=null)im.close();}},workHandler);if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)m.openCamera(cameraId,new CameraDevice.StateCallback(){public void onOpened(CameraDevice d){device=d;createSession();}public void onDisconnected(CameraDevice d){d.close();device=null;}public void onError(CameraDevice d,int e){d.close();device=null;}},cameraHandler);}catch(Exception e){status="CÂMERA INDISPONÍVEL";postInvalidate();}}
    private float horizontalFov(CameraCharacteristics cc){try{float[] fs=cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);SizeF s=cc.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);if(fs!=null&&fs.length>0&&s!=null&&fs[0]>0)return(float)(2*Math.atan(s.getWidth()/(2*fs[0])));}catch(Exception ignored){}return 0;}
    private static class RangeZ{final float min,max;RangeZ(float a,float b){min=a;max=b;}}
    private RangeZ range(CameraCharacteristics cc){if(Build.VERSION.SDK_INT>=30){android.util.Range<Float> r=cc.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);if(r!=null)return new RangeZ(r.getLower(),r.getUpper());}Float z=cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);return new RangeZ(1,Math.max(1,z==null?1:z));}
    private void createSession(){try{SurfaceTexture st=preview.getSurfaceTexture();if(st==null)return;st.setDefaultBufferSize(1920,1080);Surface ps=new Surface(st);device.createCaptureSession(Arrays.asList(ps,reader.getSurface()),new CameraCaptureSession.StateCallback(){public void onConfigured(CameraCaptureSession s){session=s;applyPreview();}public void onConfigureFailed(CameraCaptureSession s){status="FALHA NA CÂMERA";postInvalidate();}},cameraHandler);}catch(Exception ignored){}}
    private float cameraZoom(){if(isWide())return Math.max(1,zoom<1?1:zoom);return Math.max(1,zoom);}
    private CaptureRequest.Builder request(int template)throws Exception{CaptureRequest.Builder b=device.createCaptureRequest(template);b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);int ae=CaptureRequest.CONTROL_AE_MODE_ON;if(mode==Mode.NIGHT&&lowLightBoostSupported&&template==CameraDevice.TEMPLATE_PREVIEW)ae=CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY;if(template==CameraDevice.TEMPLATE_STILL_CAPTURE&&flashAvailable){if(flashMode==1)ae=CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH;else if(flashMode==2)ae=CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH;}b.set(CaptureRequest.CONTROL_AE_MODE,ae); if(template==CameraDevice.TEMPLATE_STILL_CAPTURE&&mode==Mode.NIGHT){Integer lo=chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)==null?null:chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE).getLower(); Integer hi=chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)==null?null:chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE).getUpper(); if(lo!=null&&hi!=null)b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION,Math.min(hi,Math.max(lo,2)));}if(flashAvailable)b.set(CaptureRequest.FLASH_MODE,torchMode()?CaptureRequest.FLASH_MODE_TORCH:CaptureRequest.FLASH_MODE_OFF);float cz=cameraZoom();if(Build.VERSION.SDK_INT>=30)b.set(CaptureRequest.CONTROL_ZOOM_RATIO,Math.min(cz,maxHardware));else b.set(CaptureRequest.SCALER_CROP_REGION,crop(cz));return b;}
    private boolean torchMode(){return false;}
    private Rect crop(float z){if(sensor==null)return null;int w=Math.max(1,(int)(sensor.width()/z)),h=Math.max(1,(int)(sensor.height()/z));return new Rect(sensor.centerX()-w/2,sensor.centerY()-h/2,sensor.centerX()+w/2,sensor.centerY()+h/2);}
    private void applyPreview(){try{if(session==null)return;CaptureRequest.Builder b=request(CameraDevice.TEMPLATE_PREVIEW);b.addTarget(new Surface(preview.getSurfaceTexture()));session.setRepeatingRequest(b.build(),null,cameraHandler);transform();}catch(Exception ignored){}}
    private void transform(){if(preview==null)return;preview.setTransform(new Matrix());}

    private void selectWide(){if(ultraWideId==null){status="0,5× NÃO DISPONÍVEL";invalidate();return;}if(!ultraWideId.equals(cameraId)){cameraId=ultraWideId;zoom=.5f;status="ULTRAWIDE • 0,5×";close();open();}else{zoom=.5f;status="0,5× • LENTE FÍSICA";applyPreview();invalidate();}}
    private void selectMain(float z){if(mainCameraId==null){status="CÂMERA PRINCIPAL INDISPONÍVEL";invalidate();return;}zoom=Math.max(1,Math.min(100,z));if(!mainCameraId.equals(cameraId)){cameraId=mainCameraId;close();open();}else applyPreview();invalidate();}
    private int framesForMode(){switch(mode){case FOTO:return 1;case PRO:return 4;case ULTRA:return 8;case MAX:return 10;case NIGHT:return 8;case LAB:return 10;default:return autoFrames();}}
    private int autoFrames(){ActivityManager am=(ActivityManager)getContext().getSystemService(Context.ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();if(am!=null)am.getMemoryInfo(mi);long mb=mi.availMem/1048576;return zoom<3?1:(mb>3000?8:mb>1800?6:4);}
    private void capture(){if(busy||session==null||device==null)return;busy=true;frames.clear();target=framesForMode();issued=0;progress=0;status=mode==Mode.NIGHT?"NIGHT • CAPTURANDO":"CAPTURANDO";issue(0);invalidate();}
    private void issue(int i){if(!busy)return;try{CaptureRequest.Builder b=request(CameraDevice.TEMPLATE_STILL_CAPTURE);b.addTarget(reader.getSurface());b.set(CaptureRequest.JPEG_ORIENTATION,rotation());session.capture(b.build(),new CameraCaptureSession.CaptureCallback(){@Override public void onCaptureCompleted(CameraCaptureSession s,CaptureRequest r,TotalCaptureResult result){progress++;if(progress<target){workHandler.postDelayed(()->issue(progress),mode==Mode.NIGHT?110:45);}else workHandler.post(()->finishBurst());}},cameraHandler);}catch(Exception e){busy=false;status="ERRO NA CAPTURA";invalidate();}}
    private void finishBurst(){try{long end=System.currentTimeMillis()+2500;while(frames.size()<Math.max(1,Math.min(target,frames.size()+1))&&System.currentTimeMillis()<end)Thread.sleep(15);}catch(Exception ignored){}Bitmap best=null; synchronized(frames){ if(!frames.isEmpty()){ if(mode==Mode.NIGHT && frames.size()>1) best=nightMerge(new ArrayList<>(frames)); else best=bestFrame(new ArrayList<>(frames)); } } if(best!=null){ save(best,mode==Mode.NIGHT?"NIGHT":MODES[mode.ordinal()]); } complete("FOTO SALVA");}
    private Bitmap bestFrame(List<Bitmap> list){
        Bitmap best=list.get(list.size()-1); double bestScore=-1;
        for(Bitmap b:list){ double score=sharpnessScore(b); if(score>bestScore){bestScore=score;best=b;} }
        return best;
    }
    private double sharpnessScore(Bitmap b){
        int w=Math.min(320,b.getWidth()), h=Math.min(320,b.getHeight());
        Bitmap s=Bitmap.createScaledBitmap(b,w,h,true); int[] px=new int[w*h]; s.getPixels(px,0,w,0,0,w,h); double sum=0,sum2=0; int n=0;
        for(int y=1;y<h-1;y+=2) for(int x=1;x<w-1;x+=2){int i=y*w+x; int c=Color.red(px[i])+Color.green(px[i])+Color.blue(px[i]); int l=Color.red(px[i-1])+Color.green(px[i-1])+Color.blue(px[i-1]); int r=Color.red(px[i+1])+Color.green(px[i+1])+Color.blue(px[i+1]); int u=Color.red(px[i-w])+Color.green(px[i-w])+Color.blue(px[i-w]); int d=Color.red(px[i+w])+Color.green(px[i+w])+Color.blue(px[i+w]); double lap=c*4-l-r-u-d; sum+=lap;sum2+=lap*lap;n++; }
        if(s!=b&&!s.isRecycled())s.recycle(); double mean=sum/Math.max(1,n); return sum2/Math.max(1,n)-mean*mean;
    }
    private Bitmap nightMerge(List<Bitmap> list){
        Bitmap ref=list.get(0); int w=ref.getWidth(),h=ref.getHeight(); Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); int[] acc=new int[w*h*3]; int[] px=new int[w*h]; int count=0;
        for(Bitmap b:list){ if(b.getWidth()!=w||b.getHeight()!=h) continue; b.getPixels(px,0,w,0,0,w,h); for(int i=0,j=0;i<px.length;i++,j+=3){acc[j]+=Color.red(px[i]);acc[j+1]+=Color.green(px[i]);acc[j+2]+=Color.blue(px[i]);} count++; }
        int[] outPx=new int[w*h]; if(count==0)return ref; for(int i=0,j=0;i<outPx.length;i++,j+=3){outPx[i]=Color.rgb(Math.min(255,acc[j]/count),Math.min(255,acc[j+1]/count),Math.min(255,acc[j+2]/count));} out.setPixels(outPx,0,w,0,0,w,h); return out;
    }
    private int rotation(){int r=getContext().getSystemService(WindowManager.class).getDefaultDisplay().getRotation();return r==Surface.ROTATION_0?90:r==Surface.ROTATION_90?0:r==Surface.ROTATION_180?270:180;}
    private void save(Bitmap b,String tag){try{ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,"UltraZoom_"+tag+"_"+System.currentTimeMillis()+".jpg");v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/UltraZoom");Uri u=getContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u!=null){OutputStream o=getContext().getContentResolver().openOutputStream(u);b.compress(Bitmap.CompressFormat.JPEG,97,o);if(o!=null)o.close();}}catch(Exception ignored){}}
    private void complete(String s){busy=false;target=0;status=s;postInvalidate();postDelayed(()->{status=MODES[mode.ordinal()]+" • PRONTO";invalidate();},1800);}
    private void focus(float x,float y){if(session==null||device==null||sensor==null)return;focusX=x;focusY=y;focusUntil=System.currentTimeMillis()+1000;try{float vx=Math.max(0,Math.min(1,x/getWidth())),vy=Math.max(0,Math.min(1,y/getHeight()));int fx=(int)(sensor.left+vx*sensor.width()),fy=(int)(sensor.top+vy*sensor.height());int sz=Math.max(100,sensor.width()/8);Rect r=new Rect(Math.max(sensor.left,fx-sz/2),Math.max(sensor.top,fy-sz/2),Math.min(sensor.right,fx+sz/2),Math.min(sensor.bottom,fy+sz/2));CaptureRequest.Builder b=request(CameraDevice.TEMPLATE_PREVIEW);b.addTarget(new Surface(preview.getSurfaceTexture()));b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_AUTO);b.set(CaptureRequest.CONTROL_AF_TRIGGER,CaptureRequest.CONTROL_AF_TRIGGER_START);b.set(CaptureRequest.CONTROL_AF_REGIONS,new MeteringRectangle[]{new MeteringRectangle(r,MeteringRectangle.METERING_WEIGHT_MAX-1)});session.capture(b.build(),null,cameraHandler);applyPreview();}catch(Exception ignored){}invalidate();}

    @Override public boolean onInterceptTouchEvent(MotionEvent e){return true;}
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();int w=getWidth(),h=getHeight();
        if(showInfo){if(y<110){showInfo=false;invalidate();}return true;}
        if(showModeMenu){if(y>=205&&y<=205+MODES.length*60){int i=(int)((y-205)/60);if(i>=0&&i<MODES.length){mode=Mode.values()[i];showModeMenu=false;status=MODES[i]+" • PRONTO";invalidate();}}else if(y<145||y>h-80){showModeMenu=false;invalidate();}return true;}
        if(y>h-125&&x<w/3f){if(!flashAvailable){status="FLASH INDISPONÍVEL";}else{flashMode=(flashMode+1)%3;status=flashMode==0?"FLASH • OFF":flashMode==1?"FLASH • AUTO":"FLASH • ON";}invalidate();return true;}
        if(y>h-140&&Math.abs(x-w/2f)<95){capture();return true;}
        if(y>h-125&&x>w*2/3f){showModeMenu=true;invalidate();return true;}
        if(y>h-55&&x>w-120){showInfo=true;invalidate();return true;}
        if(y>=105&&y<=175){float gap=10,bw=(w-48-3*gap)/4f;int i=(int)((x-24)/(bw+gap));if(i==0)selectWide();else if(i==1)selectMain(1);else if(i==2)selectMain(2);else if(i==3)selectMain(6);return true;}
        if(y>h-225&&y<h-135){String[] p={".5","1","2","4","6","10","20","50","100"};float step=(w-48)/8f;int i=Math.round((x-24)/step);if(i>=0&&i<p.length){float v=Float.parseFloat(p[i]);if(v<1)selectWide();else selectMain(v);return true;}}
        if(y<100&&x>w-180){showInfo=true;invalidate();return true;}
        focus(x,y);return true;
    }
    void start(){startThreads();if(preview.isAvailable()&&device==null)open();}
    void stop(){close();}
    private void close(){try{if(session!=null){session.close();session=null;}if(device!=null){device.close();device=null;}}catch(Exception ignored){}}
    void shutdown(){close();try{if(cameraThread!=null)cameraThread.quitSafely();}catch(Exception ignored){}try{if(workThread!=null)workThread.quitSafely();}catch(Exception ignored){}}
}
