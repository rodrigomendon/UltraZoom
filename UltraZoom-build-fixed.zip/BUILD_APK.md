# UltraZoom 4.1.0 — build

This project is intended to be built by GitHub Actions. The workflow extracts the project into an isolated temporary directory so repository files never collide with the ZIP contents.

APK artifact: `UltraZoom-debug-apk`.
