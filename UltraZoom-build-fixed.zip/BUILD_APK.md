# UltraZoom — build automático do APK

O repositório pode ser atualizado enviando `UltraZoom-build-fixed.zip` para a raiz.
O workflow extrai o conteúdo do ZIP na raiz do repositório e depois compila o APK.

## Resultado

O artefato gerado é `UltraZoom-debug-apk`, contendo `app-debug.apk`.

## Execução

1. Envie `UltraZoom-build-fixed.zip` para a raiz do repositório.
2. Faça o commit.
3. Abra **Actions** e aguarde **Build UltraZoom APK**.
4. Quando ficar verde, abra a execução e baixe `UltraZoom-debug-apk`.
