# UltraZoom 8.0 Premium

Build ID: UZ-080-PREMIUM

A computational camera prototype focused on large touch controls, physical ultrawide selection (0.5x when exposed), multi-frame capture, adaptive modes, flash controls and a Night pipeline.

The app never claims 0.5x when the device exposes fewer than two rear cameras.
