# UltraZoom 5.0

Premium computational camera prototype for Android.

Highlights:
- Large, readable premium camera HUD
- 0.5x / 1x / 2x / 6x lens controls
- 0.5x physical ultrawide detection
- Large shutter button
- Flash OFF / AUTO / ON
- FOTO / AUTO / PRO / ULTRA / MAX / NIGHT / LAB modes
- Multi-frame capture and fusion
- Night mode with Android Low Light Boost when the device exposes it
- LAB telemetry and capture pipeline information
