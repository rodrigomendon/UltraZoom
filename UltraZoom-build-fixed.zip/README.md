# UltraZoom 3.0.2

Câmera computacional experimental para Android.

## V3 — interface observável
- Zoom sempre visível e presets de 0,5× a 100×.
- Seleção rápida de 0,5× (ultrawide), 1×, 2× e 6×.
- Mostra câmera ativa, zoom solicitado, zoom de hardware e ampliação digital adicional.
- Modos AUTO, RÁPIDO, PRO, ULTRA, MAX e LAB.
- Botão de fotografia dedicado.
- Painel de informações técnicas.
- LAB para comparar melhor frame, fusão e refinamento.
- Multi-frame nos modos computacionais.
- Seleção por nitidez, alinhamento e fusão.

## Importante
A super-resolução neural ainda não é declarada como implementada. O motor atual usa técnicas computacionais de captura/fusão e refinamento.

## Build
O workflow do GitHub Actions compila com Android API 36, Java 17 e Gradle 9.4.1.


## UltraZoom 4.0.0
HUD visível sobre a prévia, seletor 0,5×/1×/2×/6×, zoom explícito, modos, obturador, flash OFF/AUTO/ON, foco visual e painel técnico/LAB.
