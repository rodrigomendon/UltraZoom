# UltraZoom 7.0

Premium computational camera prototype for Android.

## Main features
- Large, readable premium camera HUD
- Physical ultrawide selection when exposed by the device (0.5x)
- Main camera presets 1x / 2x / 6x
- Pinch zoom up to the camera's supported range and computational crop up to 100x
- Large photo shutter
- Flash OFF / AUTO / ON
- FOTO / AUTO / PRO / ULTRA / MAX / NIGHT / LAB modes
- Night multi-frame capture with exposure compensation when supported
- Low Light Boost preview when supported by Android 15+
- Tap-to-focus
- Technical diagnostics panel
- Saves photos to Pictures/UltraZoom


Build ID: UZ-071-FIX2
Version: 7.1
