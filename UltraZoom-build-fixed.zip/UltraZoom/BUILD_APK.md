# UltraZoom — build automático do APK

Este projeto inclui um workflow do GitHub Actions que compila o APK automaticamente em um runner Linux.

## Resultado

O artefato gerado é:

`app/build/outputs/apk/debug/app-debug.apk`

O workflow também publica o APK como artefato chamado `UltraZoom-debug-apk`.

## Execução

1. Coloque este projeto em um repositório GitHub.
2. Abra **Actions**.
3. Execute **Build UltraZoom APK** manualmente (`Run workflow`) ou faça push para `main`/`master`.
4. Ao terminar, abra a execução e baixe o artefato `UltraZoom-debug-apk`.
5. Extraia o ZIP do artefato e instale `app-debug.apk` no Android.
