# UltraZoom

Camera app experiment focused on extreme zoom using the phone's real camera capabilities plus computational crop/scaling.

## Current architecture
- Native Android / Java, no third-party runtime dependencies.
- Camera2 API, rear camera, continuous autofocus.
- Reads the device's advertised maximum digital zoom and uses `CONTROL_ZOOM_RATIO` on Android 11+.
- Smooth pinch zoom from 1x to 100x. Above the hardware limit, the preview uses an additional software crop/scale.
- Tap-to-focus.
- Torch control.
- High-resolution JPEG capture and center crop according to the selected zoom.
- Saves to Pictures/UltraZoom.
- Premium dark camera UI.

## Important optical limitation
100x is an enlargement factor, not 100x optical detail. Above the sensor/lens capability, the app is magnifying pixels and cannot recover information that the sensor did not capture.

## Next computational pipeline
1. Multi-frame burst capture.
2. Motion estimation / frame alignment.
3. Temporal denoise.
4. Detail-preserving super-resolution.
5. Edge-aware sharpening.
6. Device-specific tuning for Motorola Edge 60 Fusion.
7. Quality score that warns when extreme zoom is only producing invented/unstable detail.

## Build
Requires Android Studio/Android SDK and Gradle. The project targets compileSdk 37 and AGP 9.2.0.

## Build automático

O projeto inclui `.github/workflows/build-apk.yml` para gerar `app-debug.apk` via GitHub Actions.
