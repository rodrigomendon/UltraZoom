package com.rodrigo.ultrazoom;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Size;
import android.view.*;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ = 44;
    private UltraCameraView camera;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        immersive();
        camera = new UltraCameraView(this);
        setContentView(camera);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ);
        } else camera.start();
    }

    private void immersive() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override protected void onResume() { super.onResume(); immersive(); if (camera != null && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) camera.start(); }
    @Override protected void onPause() { if (camera != null) camera.stop(); super.onPause(); }
    @Override protected void onDestroy() { if (camera != null) camera.shutdown(); super.onDestroy(); }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) camera.start();
        else Toast.makeText(this, "A câmera é necessária para o UltraZoom.", Toast.LENGTH_LONG).show();
    }
}

class UltraCameraView extends ViewGroup {
    private enum Mode { AUTO, PRO, ULTRA, MAX, NIGHT }
    private static final String BUILD_ID = "UZ-090-TRIPLE-A";

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextureView preview;
    private CameraDevice device;
    private CameraCaptureSession session;
    private CameraCharacteristics chars;
    private String cameraId;
    private String mainCameraId;
    private String wideCameraId;
    private Size jpegSize;
    private Rect sensor;
    private float maxHardware = 1f;
    private float minHardware = 1f;
    private float zoom = 1f;
    private boolean flashAvailable;
    private boolean lowLightBoostSupported;
    private boolean wideSupported;
    private boolean busy;
    private boolean showInfo;
    private boolean showModeMenu;
    private int flashMode = 0; // 0 off, 1 auto, 2 on
    private ImageReader reader;
    private HandlerThread cameraThread, workThread;
    private Handler cameraHandler, workHandler;
    private Mode mode = Mode.AUTO;
    private String status = "PRONTO";
    private float focusX = -1, focusY = -1;
    private long focusUntil;
    private float pinchStart = 1f, pinchDistance;
    private int target, progress;
    private final List<Bitmap> burstFrames = Collections.synchronizedList(new ArrayList<Bitmap>());
    private boolean finalizeScheduled;
    private static final String[] MODES = {"AUTO", "PRO", "ULTRA", "MAX", "NIGHT"};
    private static final String[] DESCS = {"Equilíbrio automático", "Mais controle", "Multi-frame", "Potência máxima", "Pouca luz"};

    UltraCameraView(Context c) {
        super(c);
        setWillNotDraw(false);
        setBackgroundColor(Color.BLACK);
        t.setTypeface(Typeface.create("sans", Typeface.BOLD));
        startThreads();
        preview = new TextureView(c);
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) { open(); }
            public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) { transform(); }
            public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { close(); return true; }
            public void onSurfaceTextureUpdated(SurfaceTexture s) { }
        });
        addView(preview);
    }

    private void startThreads() {
        if (cameraThread == null) { cameraThread = new HandlerThread("UZ-Camera"); cameraThread.start(); cameraHandler = new Handler(cameraThread.getLooper()); }
        if (workThread == null) { workThread = new HandlerThread("UZ-Work"); workThread.start(); workHandler = new Handler(workThread.getLooper()); }
    }

    @Override protected void onMeasure(int ws, int hs) {
        int w = Math.max(1, MeasureSpec.getSize(ws)), h = Math.max(1, MeasureSpec.getSize(hs));
        setMeasuredDimension(w, h);
        preview.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
    }
    @Override protected void onLayout(boolean ch, int l, int top, int r, int b) { preview.layout(0, 0, getWidth(), getHeight()); transform(); }
    @Override protected void dispatchDraw(Canvas c) { super.dispatchDraw(c); drawHud(c); }

    private void rounded(Canvas c, float l, float top, float r, float b, float rad, int color) {
        p.setStyle(Paint.Style.FILL); p.setColor(color); c.drawRoundRect(l, top, r, b, rad, rad, p);
    }
    private void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        t.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL)); t.setTextSize(size); t.setColor(color); c.drawText(s, x, y, t);
    }
    private void center(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        t.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL)); t.setTextSize(size); t.setColor(color); c.drawText(s, x - t.measureText(s) / 2f, y, t);
    }

    private void drawHud(Canvas c) {
        final int w = getWidth(), h = getHeight();
        // Premium restrained glass UI: large controls, high contrast, minimal labels.
        rounded(c, 0, 0, w, 112, 0, 0x99000000);
        rounded(c, 0, h - 285, w, h, 0, 0xCC050505);

        txt(c, "ULTRAZOOM", 24, 34, 22, Color.WHITE, true);
        txt(c, "AUTO • PROCESSAMENTO INTELIGENTE", 24, 57, 11, 0xCCFFFFFF, false);
        center(c, zoomString(), w - 78, 42, 38, Color.WHITE, true);
        center(c, MODES[mode.ordinal()], w - 78, 67, 12, 0xE6FFFFFF, true);
        center(c, zoom <= maxHardware ? "ÓPTICO / HARDWARE" : "DIGITAL • CROP REAL", w - 86, 88, 10, 0xBFFFFFFF, false);

        drawLensPills(c, w);
        drawZoomBar(c, w, h);
        drawBottom(c, w, h);

        if (focusUntil > System.currentTimeMillis()) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.WHITE);
            c.drawRoundRect(focusX - 35, focusY - 35, focusX + 35, focusY + 35, 6, 6, p); p.setStyle(Paint.Style.FILL);
            postInvalidateDelayed(80);
        }
        if (showModeMenu) drawModeSheet(c);
        if (showInfo) drawInfo(c);
    }

    private String zoomString() { return zoom < 10 ? String.format(Locale.US, "%.1f×", zoom) : String.format(Locale.US, "%.0f×", zoom); }

    private void drawLensPills(Canvas c, int w) {
        float y = 118, gap = 10, bw = (w - 48 - 3 * gap) / 4f;
        String[] lens = {"0,5×", "1×", "2×", "6×"};
        for (int i = 0; i < 4; i++) {
            float x = 24 + i * (bw + gap);
            boolean active = (i == 0 && zoom < .75f) || (i == 1 && zoom >= .75f && zoom < 1.5f) || (i == 2 && zoom >= 1.5f && zoom < 4f) || (i == 3 && zoom >= 4f && zoom < 8f);
            rounded(c, x, y, x + bw, y + 58, 29, active ? 0xFFF5F5F5 : 0x77000000);
            center(c, lens[i], x + bw / 2, y + 38, 19, active ? Color.BLACK : Color.WHITE, true);
        }
    }

    private void drawZoomBar(Canvas c, int w, int h) {
        float y = h - 257;
        txt(c, "ZOOM", 24, y, 15, Color.WHITE, true);
        String[] vals = {"0,5", "1", "2", "4", "6", "10", "20", "50", "100"};
        float step = (w - 48) / 8f;
        for (int i = 0; i < vals.length; i++) {
            float v = Float.parseFloat(vals[i].replace(',', '.'));
            boolean active = Math.abs(zoom - v) < (v < 2 ? .09f : .35f);
            center(c, vals[i] + "×", 24 + i * step, y + 28, active ? 16 : 13, active ? Color.WHITE : 0xBFFFFFFF, active);
        }
        p.setColor(0xAAFFFFFF); c.drawRoundRect(24, y + 48, w - 24, y + 53, 3, 3, p);
        double lo = Math.log(.5), hi = Math.log(100);
        double q = (Math.log(Math.max(.5, Math.min(100, zoom))) - lo) / (hi - lo);
        p.setColor(Color.WHITE); c.drawCircle(24 + (float) q * (w - 48), y + 50.5f, 8, p);
        txt(c, zoom <= maxHardware ? "ZOOM NATIVO" : "ZOOM DIGITAL • CROP REAL", 24, y + 83, 12, 0xE6FFFFFF, true);
        txt(c, "MÁX. 100×", w - 91, y + 83, 12, 0xE6FFFFFF, true);
    }

    private void drawBottom(Canvas c, int w, int h) {
        float cy = h - 95;
        // Left: flash. Center: shutter. Right: mode. Info remains small but accessible.
        drawFlash(c, 78, cy);
        drawShutter(c, w / 2f, cy);
        drawMode(c, w - 78, cy);
        center(c, flashMode == 0 ? "FLASH OFF" : flashMode == 1 ? "FLASH AUTO" : "FLASH ON", 78, cy + 58, 12, Color.WHITE, true);
        center(c, "FOTOGRAFAR", w / 2f, cy + 58, 12, Color.WHITE, true);
        center(c, "MODO", w - 78, cy + 58, 12, Color.WHITE, true);
        txt(c, status, 24, h - 22, 11, 0xD9FFFFFF, false);
        txt(c, "ⓘ", w - 42, h - 19, 22, Color.WHITE, true);
    }

    private void drawFlash(Canvas c, float x, float y) {
        rounded(c, x - 48, y - 45, x + 48, y + 45, 24, flashMode == 0 ? 0x88000000 : 0xFFF5F5F5);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(flashMode == 0 ? Color.WHITE : Color.BLACK);
        Path q = new Path(); q.moveTo(x + 7, y - 30); q.lineTo(x - 12, y + 3); q.lineTo(x + 2, y + 3); q.lineTo(x - 7, y + 30); q.lineTo(x + 18, y - 6); q.lineTo(x + 3, y - 6); q.close(); c.drawPath(q, p); p.setStyle(Paint.Style.FILL);
    }

    private void drawShutter(Canvas c, float x, float y) {
        p.setColor(Color.WHITE); c.drawCircle(x, y, 51, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(0xFF111111); c.drawCircle(x, y, 40, p); p.setStyle(Paint.Style.FILL);
        if (busy) { p.setColor(0xFF111111); c.drawRoundRect(x - 12, y - 12, x + 12, y + 12, 4, 4, p); }
    }

    private void drawMode(Canvas c, float x, float y) {
        rounded(c, x - 48, y - 45, x + 48, y + 45, 24, 0x88000000);
        center(c, "MODO", x, y - 2, 12, Color.WHITE, true);
        center(c, MODES[mode.ordinal()], x, y + 23, 12, Color.WHITE, true);
    }

    private void drawModeSheet(Canvas c) {
        int w = getWidth(), h = getHeight();
        rounded(c, 12, 102, w - 12, h - 55, 30, 0xF20A0A0A);
        txt(c, "MODO DE CAPTURA", 34, 145, 27, Color.WHITE, true);
        float y = 166;
        for (int i = 0; i < MODES.length; i++) {
            boolean active = i == mode.ordinal();
            rounded(c, 26, y, w - 26, y + 68, 20, active ? 0xFFF5F5F5 : 0x331F1F1F);
            txt(c, MODES[i], 48, y + 29, 20, active ? Color.BLACK : Color.WHITE, true);
            txt(c, DESCS[i], 48, y + 51, 12, active ? 0xFF333333 : 0xCCFFFFFF, false);
            y += 75;
        }
        txt(c, "Toque fora para fechar", 34, h - 77, 12, 0xBFFFFFFF, false);
    }

    private void drawInfo(Canvas c) {
        int w = getWidth(), h = getHeight();
        rounded(c, 16, 105, w - 16, h - 60, 28, 0xF50A0A0A);
        txt(c, "ULTRAZOOM • INFORMAÇÕES", 38, 148, 25, Color.WHITE, true);
        float y = 190;
        infoRow(c, "Zoom atual", zoomString(), y); y += 34;
        infoRow(c, "Modo", MODES[mode.ordinal()], y); y += 34;
        infoRow(c, "Lente", zoom < 1 ? "ULTRAWIDE" : "PRINCIPAL", y); y += 34;
        infoRow(c, "Hardware", String.format(Locale.US, "%.1f×", maxHardware), y); y += 34;
        infoRow(c, "0,5×", wideSupported ? "DISPONÍVEL" : "NÃO DISPONÍVEL", y); y += 34;
        infoRow(c, "Flash", flashAvailable ? "DISPONÍVEL" : "NÃO DISPONÍVEL", y); y += 34;
        infoRow(c, "Visão noturna", lowLightBoostSupported ? "BOOST DISPONÍVEL" : "MULTI-FRAME", y); y += 34;
        infoRow(c, "Build", BUILD_ID, y);
        txt(c, "A câmera informa os limites reais do aparelho.", 38, h - 102, 12, 0xBFFFFFFF, false);
        txt(c, "Toque no topo para fechar", 38, h - 78, 12, 0xBFFFFFFF, false);
    }

    private void infoRow(Canvas c, String a, String b, float y) { txt(c, a, 38, y, 13, 0x99FFFFFF, false); txt(c, b, 220, y, 16, Color.WHITE, true); }

    private String zoomTextForStatus() { return String.format(Locale.US, "%.1f×", zoom); }

    private void open() {
        try {
            CameraManager cm = (CameraManager) getContext().getSystemService(Context.CAMERA_SERVICE);
            mainCameraId = null; wideCameraId = null; wideSupported = false;
            String fallback = null; long largest = -1;
            String logicalWide = null;
            float logicalWideFov = 0f, bestMainFov = 0f;

            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
                if (fallback == null) fallback = id;
                float fov = horizontalFov(cc);
                Size pa = cc.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
                long area = pa == null ? 0 : (long) pa.getWidth() * pa.getHeight();
                RangeZ rz = range(cc);
                int[] caps = cc.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
                boolean logical = hasCapability(caps, CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA);
                if (logical && rz.min <= .6f && rz.max > 1f) {
                    // Prefer a logical multi-camera with a true sub-1x zoom range.
                    mainCameraId = id; bestMainFov = fov;
                } else if (area > largest) {
                    largest = area;
                    if (mainCameraId == null) { mainCameraId = id; bestMainFov = fov; }
                }
                if (fov > logicalWideFov) { logicalWideFov = fov; logicalWide = id; }
            }
            if (mainCameraId == null) mainCameraId = fallback;
            if (mainCameraId == null) return;

            CameraCharacteristics main = cm.getCameraCharacteristics(mainCameraId);
            RangeZ mr = range(main);
            // If the selected main camera has no native 0.5x, search for a separate wider back camera.
            if (mr.min <= .55f) {
                wideSupported = true;
                wideCameraId = mainCameraId;
            } else {
                float mainFov = horizontalFov(main);
                for (String id : cm.getCameraIdList()) {
                    if (id.equals(mainCameraId)) continue;
                    CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                    Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                    if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
                    float fov = horizontalFov(cc);
                    RangeZ rz = range(cc);
                    if (fov > mainFov * 1.12f && fov > bestMainFov * 1.05f && rz.max >= 1f) {
                        wideCameraId = id; wideSupported = true; break;
                    }
                }
            }
            if (cameraId == null) cameraId = mainCameraId;
            chars = cm.getCameraCharacteristics(cameraId);
            sensor = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            RangeZ rr = range(chars); minHardware = rr.min; maxHardware = rr.max;
            prepareReader(chars);
            flashAvailable = Boolean.TRUE.equals(chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE));
            lowLightBoostSupported = false;
            if (Build.VERSION.SDK_INT >= 35) {
                int[] ae = chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES);
                if (ae != null) for (int v : ae) if (v == CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY) lowLightBoostSupported = true;
            }
            if (checkSelfPermissionSafe()) cm.openCamera(cameraId, new CameraDevice.StateCallback() {
                public void onOpened(CameraDevice d) { device = d; createSession(); }
                public void onDisconnected(CameraDevice d) { d.close(); device = null; }
                public void onError(CameraDevice d, int e) { d.close(); device = null; status = "ERRO NA CÂMERA"; postInvalidate(); }
            }, cameraHandler);
        } catch (Exception e) { status = "CÂMERA INDISPONÍVEL"; postInvalidate(); }
    }

    private boolean checkSelfPermissionSafe() { return getContext().checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED; }
    private boolean hasCapability(int[] caps, int wanted) { if (caps == null) return false; for (int c : caps) if (c == wanted) return true; return false; }

    private void prepareReader(CameraCharacteristics cc) {
        if (reader != null) { reader.close(); reader = null; }
        android.hardware.camera2.params.StreamConfigurationMap map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        jpegSize = new Size(1920, 1080);
        if (map != null) {
            Size[] ss = map.getOutputSizes(android.graphics.ImageFormat.JPEG);
            if (ss != null && ss.length > 0) {
                Size best = ss[0];
                for (Size s : ss) if ((long)s.getWidth() * s.getHeight() > (long)best.getWidth() * best.getHeight()) best = s;
                jpegSize = best;
            }
        }
        reader = ImageReader.newInstance(jpegSize.getWidth(), jpegSize.getHeight(), android.graphics.ImageFormat.JPEG, 3);
        reader.setOnImageAvailableListener(rdr -> {
            Image im = null;
            try {
                im = rdr.acquireLatestImage();
                if (im != null && busy) {
                    ByteBuffer b = im.getPlanes()[0].getBuffer();
                    byte[] data = new byte[b.remaining()]; b.get(data);
                    BitmapFactory.Options opt = new BitmapFactory.Options(); opt.inPreferredConfig = Bitmap.Config.ARGB_8888;
                    Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length, opt);
                    if (bm != null) finishPhoto(bm);
                }
            } catch (Exception ignored) { }
            finally { if (im != null) im.close(); }
        }, workHandler);
    }

    private float horizontalFov(CameraCharacteristics cc) {
        try {
            float[] fs = cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            android.util.SizeF s = cc.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            if (fs != null && fs.length > 0 && s != null && fs[0] > 0) return (float)(2 * Math.atan(s.getWidth() / (2 * fs[0])));
        } catch (Exception ignored) { }
        return 0;
    }
    private static class RangeZ { final float min, max; RangeZ(float a, float b) { min = a; max = b; } }
    private RangeZ range(CameraCharacteristics cc) {
        if (Build.VERSION.SDK_INT >= 30) {
            Range<Float> r = cc.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
            if (r != null) return new RangeZ(r.getLower(), r.getUpper());
        }
        Float z = cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
        return new RangeZ(1f, Math.max(1f, z == null ? 1f : z));
    }

    private void createSession() {
        try {
            SurfaceTexture st = preview.getSurfaceTexture(); if (st == null || device == null) return;
            st.setDefaultBufferSize(1920, 1080);
            Surface ps = new Surface(st);
            device.createCaptureSession(Arrays.asList(ps, reader.getSurface()), new CameraCaptureSession.StateCallback() {
                public void onConfigured(CameraCaptureSession s) { session = s; applyPreview(); }
                public void onConfigureFailed(CameraCaptureSession s) { status = "FALHA NA CÂMERA"; postInvalidate(); }
            }, cameraHandler);
        } catch (Exception ignored) { }
    }

    private CaptureRequest.Builder request(int template) throws Exception {
        CaptureRequest.Builder b = device.createCaptureRequest(template);
        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        int ae = CaptureRequest.CONTROL_AE_MODE_ON;
        if (mode == Mode.NIGHT && lowLightBoostSupported && template == CameraDevice.TEMPLATE_PREVIEW) ae = CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY;
        if (template == CameraDevice.TEMPLATE_STILL_CAPTURE && flashAvailable) {
            if (flashMode == 1) ae = CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH;
            else if (flashMode == 2) ae = CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH;
        }
        b.set(CaptureRequest.CONTROL_AE_MODE, ae);
        if (template == CameraDevice.TEMPLATE_PREVIEW && flashAvailable && flashMode == 2) b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH);
        else if (flashAvailable) b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);

        if (Build.VERSION.SDK_INT >= 30 && zoom >= minHardware && zoom <= maxHardware) {
            b.set(CaptureRequest.CONTROL_ZOOM_RATIO, Math.max(minHardware, Math.min(maxHardware, zoom)));
        } else {
            b.set(CaptureRequest.SCALER_CROP_REGION, crop(Math.max(1f, zoom)));
        }
        if (mode == Mode.NIGHT && template == CameraDevice.TEMPLATE_STILL_CAPTURE) {
            Range<Integer> ar = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            if (ar != null) b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, Math.min(ar.getUpper(), Math.max(ar.getLower(), 2)));
        }
        return b;
    }

    private Rect crop(float z) {
        if (sensor == null) return null;
        z = Math.max(1f, z);
        int cw = Math.max(2, (int)(sensor.width() / z)), ch = Math.max(2, (int)(sensor.height() / z));
        return new Rect(sensor.centerX() - cw / 2, sensor.centerY() - ch / 2, sensor.centerX() + cw / 2, sensor.centerY() + ch / 2);
    }
    private void applyPreview() {
        try { if (session == null) return; CaptureRequest.Builder b = request(CameraDevice.TEMPLATE_PREVIEW); b.addTarget(new Surface(preview.getSurfaceTexture())); session.setRepeatingRequest(b.build(), null, cameraHandler); transform(); }
        catch (Exception ignored) { }
    }
    private void transform() { if (preview != null) preview.setTransform(new Matrix()); }

    private void selectWide() {
        if (!wideSupported) { status = "0,5× NÃO DISPONÍVEL NESTE APARELHO"; invalidate(); return; }
        zoom = .5f;
        if (!cameraId.equals(wideCameraId)) { cameraId = wideCameraId; close(); open(); }
        else { status = "0,5× • ULTRAWIDE"; applyPreview(); invalidate(); }
    }
    private void selectMain(float z) {
        if (mainCameraId == null) { status = "CÂMERA PRINCIPAL INDISPONÍVEL"; invalidate(); return; }
        zoom = Math.max(1f, Math.min(100f, z));
        if (!cameraId.equals(mainCameraId)) { cameraId = mainCameraId; close(); open(); }
        else { status = zoom > maxHardware ? "ZOOM DIGITAL • " + zoomTextForStatus() : "ZOOM • " + zoomTextForStatus(); applyPreview(); invalidate(); }
    }

    private void capture() {
        if (busy || session == null || device == null) return;
        busy = true; burstFrames.clear(); finalizeScheduled = false;
        target = mode == Mode.AUTO || mode == Mode.PRO ? 1 : mode == Mode.ULTRA ? 2 : mode == Mode.MAX ? 3 : 2;
        progress = 0;
        status = mode == Mode.NIGHT ? "NIGHT • CAPTURANDO" : "CAPTURANDO • 0%"; issue(); invalidate();
    }

    private void issue() {
        if (!busy) return;
        try {
            CaptureRequest.Builder b = request(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(reader.getSurface()); b.set(CaptureRequest.JPEG_ORIENTATION, rotation());
            session.capture(b.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest r, TotalCaptureResult result) {
                    progress++;
                    if (progress < target) workHandler.postDelayed(() -> issue(), mode == Mode.NIGHT ? 220 : 100);
                    else workHandler.postDelayed(() -> { if (busy && progress >= target) status = "PROCESSAMENTO…"; }, 80);
                }
            }, cameraHandler);
        } catch (Exception e) { busy = false; status = "FALHA AO FOTOGRAFAR"; invalidate(); }
    }

    private void finishPhoto(Bitmap bm) {
        if (!busy || bm == null) { if (bm != null) bm.recycle(); return; }
        burstFrames.add(bm);
        if (progress >= target && burstFrames.size() >= target) finalizeCapture();
        else if (progress >= target && !finalizeScheduled) {
            finalizeScheduled = true;
            postDelayed(this::finalizeCapture, 900);
        }
    }

    private void finalizeCapture() {
        if (!busy) return;
        Bitmap best = null;
        synchronized (burstFrames) {
            if (!burstFrames.isEmpty()) {
                best = burstFrames.get(0);
                for (Bitmap b : burstFrames) {
                    if (b != null && sharpnessScore(b) > sharpnessScore(best)) best = b;
                }
            }
        }
        if (best != null) {
            if (mode == Mode.NIGHT) best = liftNight(best);
            save(best, mode == Mode.NIGHT ? "NIGHT" : MODES[mode.ordinal()]);
        }
        synchronized (burstFrames) {
            for (Bitmap b : burstFrames) if (b != null && b != best) b.recycle();
            burstFrames.clear();
        }
        if (best != null) best.recycle();
        busy = false; finalizeScheduled = false;
        status = best == null ? "NÃO FOI POSSÍVEL FOTOGRAFAR" : "FOTO SALVA • " + zoomString();
        invalidate();
        postDelayed(() -> { if (!busy) { status = MODES[mode.ordinal()] + " • PRONTO"; invalidate(); } }, 1800);
    }

    private double sharpnessScore(Bitmap b) {
        int w = Math.min(180, b.getWidth()), h = Math.min(140, b.getHeight());
        Bitmap s = Bitmap.createScaledBitmap(b, w, h, true);
        int[] px = new int[w * h]; s.getPixels(px, 0, w, 0, 0, w, h);
        double sum = 0, sum2 = 0; int n = 0;
        for (int y = 1; y < h - 1; y += 2) for (int x = 1; x < w - 1; x += 2) {
            int i = y * w + x;
            int c = Color.red(px[i]) + Color.green(px[i]) + Color.blue(px[i]);
            int l = Color.red(px[i - 1]) + Color.green(px[i - 1]) + Color.blue(px[i - 1]);
            int r = Color.red(px[i + 1]) + Color.green(px[i + 1]) + Color.blue(px[i + 1]);
            int u = Color.red(px[i - w]) + Color.green(px[i - w]) + Color.blue(px[i - w]);
            int d = Color.red(px[i + w]) + Color.green(px[i + w]) + Color.blue(px[i + w]);
            double q = c * 4 - l - r - u - d; sum += q; sum2 += q * q; n++;
        }
        if (s != b) s.recycle(); double mean = sum / Math.max(1, n); return sum2 / Math.max(1, n) - mean * mean;
    }

    private Bitmap liftNight(Bitmap src) {
        Bitmap out = src.copy(Bitmap.Config.ARGB_8888, true);
        int w = out.getWidth(), h = out.getHeight(); int[] px = new int[w * h]; out.getPixels(px, 0, w, 0, 0, w, h);
        for (int i = 0; i < px.length; i++) {
            int r = nightTone(Color.red(px[i])); int g = nightTone(Color.green(px[i])); int b = nightTone(Color.blue(px[i]));
            px[i] = Color.rgb(r, g, b);
        }
        out.setPixels(px, 0, w, 0, 0, w, h); return out;
    }
    private int nightTone(int v) { double n = v / 255.0; double lifted = Math.pow(Math.min(1, n * 1.18), .82); return Math.max(0, Math.min(255, (int)(lifted * 255))); }

    private int rotation() {
        int r = getContext().getDisplay().getRotation();
        return r == Surface.ROTATION_0 ? 90 : r == Surface.ROTATION_90 ? 0 : r == Surface.ROTATION_180 ? 270 : 180;
    }
    private void save(Bitmap b, String tag) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "UltraZoom_" + tag + "_" + System.currentTimeMillis() + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/UltraZoom");
            Uri u = getContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u != null) { OutputStream o = getContext().getContentResolver().openOutputStream(u); b.compress(Bitmap.CompressFormat.JPEG, 97, o); if (o != null) o.close(); }
        } catch (Exception ignored) { }
    }

    private void focus(float x, float y) {
        if (session == null || device == null) return;
        focusX = x; focusY = y; focusUntil = System.currentTimeMillis() + 1200;
        invalidate();
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent e) { return true; }
    @Override public boolean onTouchEvent(MotionEvent e) {
        int w = getWidth(), h = getHeight(); float x = e.getX(), y = e.getY();
        if (e.getPointerCount() == 2) {
            if (e.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) { pinchDistance = distance(e); pinchStart = zoom; }
            else if (e.getActionMasked() == MotionEvent.ACTION_MOVE && pinchDistance > 0) { float nz = Math.max(.5f, Math.min(100f, pinchStart * distance(e) / pinchDistance)); if (nz < 1f) selectWide(); else selectMain(nz); }
            else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) pinchDistance = 0;
            return true;
        }
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        if (showInfo) { showInfo = false; invalidate(); return true; }
        if (showModeMenu) {
            if (y >= 166 && y <= 166 + MODES.length * 75) { int i = (int)((y - 166) / 75); if (i >= 0 && i < MODES.length) { mode = Mode.values()[i]; showModeMenu = false; status = MODES[i] + " • PRONTO"; applyPreview(); invalidate(); } }
            else { showModeMenu = false; invalidate(); }
            return true;
        }
        if (y > h - 160 && x < w * .28f) { if (!flashAvailable) status = "FLASH INDISPONÍVEL"; else { flashMode = (flashMode + 1) % 3; applyPreview(); status = flashMode == 0 ? "FLASH • OFF" : flashMode == 1 ? "FLASH • AUTO" : "FLASH • ON"; invalidate(); } return true; }
        if (y > h - 170 && x > w * .72f) { showModeMenu = true; invalidate(); return true; }
        if (y > h - 175 && Math.abs(x - w / 2f) < 115) { capture(); return true; }
        if (y >= 112 && y <= 184) {
            float gap = 10, bw = (w - 48 - 3 * gap) / 4f; int i = (int)((x - 24) / (bw + gap));
            if (i == 0) selectWide(); else if (i == 1) selectMain(1); else if (i == 2) selectMain(2); else if (i == 3) selectMain(6); return true;
        }
        if (y > h - 290 && y < h - 150) { float ratio = Math.max(0, Math.min(1, (x - 24) / (float)(w - 48))); float nz = (float)Math.exp(Math.log(.5) + ratio * (Math.log(100) - Math.log(.5))); if (nz < 1f) selectWide(); else selectMain(nz); return true; }
        if ((y < 110 && x > w - 170) || (y > h - 65 && x > w - 90)) { showInfo = true; invalidate(); return true; }
        focus(x, y); return true;
    }

    private float distance(MotionEvent e) { float dx = e.getX(1) - e.getX(0), dy = e.getY(1) - e.getY(0); return (float)Math.sqrt(dx * dx + dy * dy); }
    void start() { startThreads(); if (preview.isAvailable() && device == null) open(); }
    void stop() { close(); }
    private void close() { try { if (session != null) { session.close(); session = null; } if (device != null) { device.close(); device = null; } } catch (Exception ignored) { } }
    void shutdown() { close(); try { if (reader != null) reader.close(); } catch (Exception ignored) { } try { if (cameraThread != null) cameraThread.quitSafely(); } catch (Exception ignored) { } try { if (workThread != null) workThread.quitSafely(); } catch (Exception ignored) { } }
}
