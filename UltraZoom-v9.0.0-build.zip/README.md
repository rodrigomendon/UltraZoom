# UltraZoom 8.1 Premium

Build ID: UZ-081-PREMIUM

Camera app focused on high-magnification capture with a premium, readable camera UI.

## Highlights
- Large, high-contrast controls and shutter button
- 0.5x ultrawide when the device exposes a compatible ultrawide camera or native zoom-ratio range
- 1x / 2x / 6x quick lens buttons
- Continuous 0.5x–100x zoom slider and two-finger pinch zoom
- Native zoom up to the camera's reported hardware range
- Digital crop extension beyond hardware range, clearly labeled as digital
- FOTO, AUTO, PRO, ULTRA, MAX, NIGHT and LAB modes
- Flash OFF / AUTO / ON
- Tap-to-focus
- Multi-frame capture and best-frame selection
- Night multi-frame alignment, fusion and tonal lift
- Device capability information panel
- Photos saved to Pictures/UltraZoom
