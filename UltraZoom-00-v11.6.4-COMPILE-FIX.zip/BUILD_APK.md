# UltraZoom 11.6.3

1. Upload `UltraZoom-00-v11.6.3-diagnostic.zip` to the repository root.
2. Replace `.github/workflows/build-apk.yml` with the workflow from this ZIP.
3. Push to `main` or run **Build UltraZoom APK** manually.
4. The workflow selects exactly one ZIP containing `UZ-116.3-GENERIC-FIX`.
5. It runs structural checks and `gradle --no-daemon --stacktrace clean assembleDebug`.
6. The APK is published as `UltraZoom-v11.6-debug-apk`.

After installation, open **ⓘ** and send the diagnostic screen. Do not interpret 0.5× as a software bug until the physical/logical camera data is checked.
