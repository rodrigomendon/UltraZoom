# Build UltraZoom 11.0.0

1. Na raiz do repositório, envie o arquivo `UltraZoom-v11.0.0-build.zip`.
2. Se houver ZIPs antigos `UltraZoom*.zip`, eles podem permanecer: o workflow identifica a versão nova procurando `UZ-110-TRIPLE-A` dentro do arquivo.
3. Abra **Actions → Build UltraZoom APK**.
4. O esperado é **Success**.
5. Em **Artifacts**, baixe `UltraZoom-v11-debug-apk`.

O workflow extrai com `unzip -o`, portanto não deve aparecer `replace README.md?`.
