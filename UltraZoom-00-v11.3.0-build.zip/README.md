# UltraZoom 11.3.0

Build-ready Android Camera2 project.

## 11.3 improvements
- Real overview/minimap snapshot using a dedicated low-resolution YUV stream, with live zoom crop indicator.
- More conservative ultrawide detection and physical/logical camera diagnostics.
- Hardware zoom plus real digital crop for values above the camera-reported hardware limit.
- Preview transform based on the Camera2Basic approach to preserve aspect ratio.
- Robust multi-frame capture finalization when image delivery and capture callbacks arrive in either order.
- 0.5x / 1x / 2x / 6x / 10x quick controls, 100x logarithmic zoom control, flash, capture, modes and Night mode.
- Premium-oriented HUD with larger hierarchy and explicit processing state.

Build identifiers: `UZ-113-TRIPLE-A` and legacy compatibility marker `UZ-110-TRIPLE-A`.

- Build hardening: correct `SurfaceTexture` package import and workflow checks to prevent stale/incorrect source selection.
