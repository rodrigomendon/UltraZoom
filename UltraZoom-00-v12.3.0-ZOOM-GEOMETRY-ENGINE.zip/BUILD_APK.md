# UltraZoom 12.3.0 — build

1. Put `UltraZoom-00-v12.3.0-ZOOM-GEOMETRY-ENGINE.zip` in the repository root.
2. The workflow finds exactly one archive containing `UZ-123-ZOOM-GEOMETRY-ENGINE`.
3. GitHub Actions unpacks the archive as an isolated Android project.
4. It validates the source markers, then runs `gradle clean assembleDebug`.
5. The debug artifact is published as `UltraZoom-v12.3-debug-apk`.

The local environment used to prepare this archive does not contain the Android SDK/Gradle toolchain, so local Android compilation is not claimed.
