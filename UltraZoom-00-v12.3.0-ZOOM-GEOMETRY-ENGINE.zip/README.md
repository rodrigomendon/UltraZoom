# UltraZoom 12.3.0 — Zoom + Geometry Engine

Build identifier: `UZ-123-ZOOM-GEOMETRY-ENGINE`.

A 12.3 is an architectural revision of the Camera2 pipeline. It separates requested zoom (UI), reported zoom (CAM) and proven/applied geometry (GEO), with an explicit confidence state machine that prevents double-zoom fallback.

## Zoom confidence

`UNKNOWN → PROBING → TRUSTED_RATIO / TRUSTED_CROP_ONLY / UNRELIABLE`.

The app never applies compensating crop while confidence is UNKNOWN, PROBING or UNRELIABLE. A full `SCALER_CROP_REGION` is not treated as proof that zoom failed. `TRUSTED_CROP_ONLY` is entered only after an explicit calibration observation and then uses crop mode deliberately.

## Geometry

The native camera frame is treated as the 4:3 reference. The phone viewport adapts to it with uniform scaling; preview, minimap and capture diagnostics share the same sensor reference.

## Calibration

The `CAL` control opens an engineering calibration mode. Use a fixed, measurable target (ruler, grid, door), capture 1×/2×/5×/10× and enter the observed visual magnification. The session is exported as JSON under `Pictures/UltraZoom/calibracao/`. Automatic feature correlation is intentionally left for a later revision.

## Image engine

Multi-frame captures use bounded decode resolution and an ImageReader with sufficient buffering to reduce memory pressure. UI updates from camera/work handlers are posted back to the UI thread.

## Build

The workflow selects exactly one ZIP containing `UZ-123-ZOOM-GEOMETRY-ENGINE`, validates critical source markers and runs `clean assembleDebug` with Java 17, Gradle 9.4.1 and Android SDK 36.
