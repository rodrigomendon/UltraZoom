# Build UltraZoom 11.4.0

1. Put exactly one `UltraZoom-*.zip` containing `UZ-114-TRIPLE-A` in the repository root.
2. The workflow selects that archive only when its `app/src/main/java/com/rodrigo/ultrazoom/MainActivity.java` contains the exact build marker.
3. It rejects zero or multiple matching archives to avoid stale ZIP selection.
4. It checks the project structure and the correct `android.graphics.SurfaceTexture` import.
5. It installs Java 17, Gradle 9.4.1 and Android SDK platform/build-tools 36.
6. It runs `gradle --no-daemon --stacktrace clean assembleDebug`.
7. The APK is verified and uploaded as `UltraZoom-v11.4-debug-apk`.

The final proof of a successful Android build is the green GitHub Actions run on the user's repository; this environment does not contain the Android SDK/Gradle toolchain needed to reproduce that build locally.
