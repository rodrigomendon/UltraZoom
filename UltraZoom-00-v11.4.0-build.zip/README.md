# UltraZoom 11.4.0

Build-ready Android Camera2 project.

## 11.4 improvements
- Real ultrawide routing: when the main logical camera exposes a wider physical camera, the app uses Camera2 `OutputConfiguration.setPhysicalCameraId()` instead of merely listing the physical ID.
- Rear-camera discovery no longer stops at the first logical camera; diagnostics enumerate public rear cameras and physical members.
- 0.5× is only advertised when a real sub-1× logical ratio or a materially wider physical/public rear camera is detected.
- Preview transform rewritten as a uniform center-crop with sensor/display rotation, preventing non-uniform stretching.
- Focus tap now creates Camera2 AF/AE metering regions and triggers autofocus when the device exposes those regions.
- Overview/minimap refresh is less stale and its framing remains tied to the applied zoom value.
- Hardware zoom remains bounded by the camera-reported range; values above that are explicit digital framing, not fabricated optical detail.
- Version/build markers are synchronized at 11.4.0 / `UZ-114-TRIPLE-A`.

## Important limitation
The app cannot reproduce every proprietary computational-photography feature of the Motorola stock camera. The 100× mode is digital framing beyond the camera's reported hardware zoom limit; it does not create optical detail that the sensor did not capture.

## Build
The repository workflow prepares the exact UZ-114 ZIP, checks the source marker/imports, installs Android 36/build-tools 36.0.0, runs a clean debug build, verifies the APK and uploads it as an artifact.
