# UltraZoom 12.1.0 — Computational Zoom Engine

Build identifier: `UZ-121-IMAGE-ENGINE`.

Esta versão parte do UZ-120 e concentra a melhoria no motor de zoom e imagem, sem sacrificar a orientação que já funciona no aparelho de teste.

## Principais mudanças
- AE fica travada durante todo o gesto de zoom e só é liberada após o gesto terminar.
- Removida a camada escura usada durante a transição de zoom; ela não mascara mais o preview.
- Minimap em formato vertical, com conteúdo YUV rotacionado para a orientação visual do app.
- Retângulo do minimapa passa a respeitar a proporção real do preview.
- Rotação do JPEG passa a usar SENSOR_ORIENTATION + rotação do display, sem tabela fixa para um único aparelho.
- Fusão multi-frame deixa de ser uma média simples: extremos são rejeitados quando há frames suficientes, reduzindo impacto de ruído/outliers.
- Frames continuam em resolução nativa até a fusão e o crop digital ocorre somente depois.
- Mantidas as configurações Camera2 de alta qualidade para captura estática.
- Diagnóstico continua mostrando zoom solicitado e zoom aplicado pelo Camera2.

## Limitações
- O Motorola Edge 60 Fusion testado não expõe uma ultrawide utilizável pela Camera2 pública; portanto 0,5× continua desabilitado nesse aparelho.
- O valor 10× é o limite reportado pelo Camera2. O app não afirma que ele seja equivalente ao rótulo de zoom da câmera nativa Motorola.
- Zoom acima do limite de hardware é crop/upscale computacional; não cria informação óptica que o sensor não capturou.

## Build
O workflow seleciona exatamente um ZIP contendo `UZ-121-IMAGE-ENGINE`, valida os arquivos críticos e executa `clean assembleDebug` com Java 17, Gradle 9.4.1 e Android 36.
