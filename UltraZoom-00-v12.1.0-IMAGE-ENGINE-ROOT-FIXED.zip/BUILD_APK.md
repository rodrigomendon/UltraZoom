# UltraZoom 12.1.0

1. Envie `UltraZoom-00-v12.1.0-IMAGE-ENGINE.zip` para a raiz do repositório.
2. O workflow encontra exatamente um ZIP contendo `UZ-121-IMAGE-ENGINE`.
3. Não deixe ZIPs antigos UltraZoom na raiz que ainda contenham um BUILD_ID diferente se eles forem considerados candidatos pelo workflow.
4. O workflow extrai o projeto, executa as verificações estruturais e roda `gradle --no-daemon --stacktrace clean assembleDebug`.
5. O APK será publicado como `UltraZoom-v12.1-debug-apk`.
