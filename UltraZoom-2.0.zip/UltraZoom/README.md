# UltraZoom 2.0

Computational camera prototype for Android 11+.

## Modes
- AUTO: adapts the number of captured frames to zoom level.
- RÁPIDO: single-frame capture with fast crop/scale.
- PRO: multi-frame capture and quality selection.
- ULTRA: multi-frame capture, alignment, fusion and refinement.
- MAX: maximum supported burst in this build, with heavier processing.
- LAB: captures and saves three experimental results: best frame, fusion and refined result.

The processing engine is intentionally modular so later versions can add device-specific tuning and neural super-resolution without changing the camera UI.
