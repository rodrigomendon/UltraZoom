package com.rodrigo.ultrazoom;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.MeteringRectangle;
import android.media.Image;
import android.media.ImageFormat;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Size;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.TextureView;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ = 44;
    private UltraCameraView camera;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        camera = new UltraCameraView(this);
        setContentView(camera);
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ);
        } else camera.start();
    }
    @Override protected void onResume() { super.onResume(); if (camera != null && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) camera.start(); }
    @Override protected void onPause() { if (camera != null) camera.stop(); super.onPause(); }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r == REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) camera.start();
        else Toast.makeText(this,"A câmera é necessária para o UltraZoom.",Toast.LENGTH_LONG).show();
    }
}

class UltraCameraView extends ViewGroup {
    private enum Mode { AUTO, RAPIDO, PRO, ULTRA, MAX, LAB }
    private TextureView preview;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private CameraDevice device;
    private CameraCaptureSession session;
    private CameraCharacteristics chars;
    private String cameraId;
    private Size jpegSize;
    private Rect sensor;
    private float maxHardware = 1f, zoom = 1f;
    private boolean flashAvailable, torch, busy;
    private ImageReader reader;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private HandlerThread workThread;
    private Handler workHandler;
    private final ExecutorService cpu = Executors.newSingleThreadExecutor();
    private ScaleGestureDetector pinch;
    private GestureDetector tap;
    private float downX, downY;
    private Mode mode = Mode.AUTO;
    private final List<Bitmap> burstFrames = Collections.synchronizedList(new ArrayList<Bitmap>());
    private int burstTarget, capturesIssued;
    private long burstStarted;
    private String status = "PRONTO";
    private int statusProgress;
    private boolean showLab;
    private int backCameraCount=0;
    private final String[] modeNames = {"AUTO","RÁPIDO","PRO","ULTRA","MAX","LAB"};

    UltraCameraView(Context c) {
        super(c);
        setWillNotDraw(false);
        setBackgroundColor(Color.BLACK);
        text.setTypeface(Typeface.create("sans", Typeface.BOLD));
        startThreads();
        preview = new TextureView(c);
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){open();}
            public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){transform();}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture s){close();return true;}
            public void onSurfaceTextureUpdated(SurfaceTexture s){}
        });
        addView(preview);
        pinch = new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            public boolean onScale(ScaleGestureDetector d){setZoom(zoom*d.getScaleFactor());return true;}
        });
        tap = new GestureDetector(c,new GestureDetector.SimpleOnGestureListener(){
            public boolean onDown(MotionEvent e){downX=e.getX();downY=e.getY();return true;}
            public boolean onSingleTapUp(MotionEvent e){
                if (e.getY() > getHeight()-245 && e.getY() < getHeight()-180) { selectModeAt(e.getX()); return true; }
                focus(e.getX(),e.getY()); return true;
            }
        });
    }

    private void startThreads(){
        if(cameraThread==null){cameraThread=new HandlerThread("UltraZoom-Camera");cameraThread.start();cameraHandler=new Handler(cameraThread.getLooper());}
        if(workThread==null){workThread=new HandlerThread("UltraZoom-Work");workThread.start();workHandler=new Handler(workThread.getLooper());}
    }

    @Override protected void onLayout(boolean c,int l,int t,int r,int b){preview.layout(0,0,getWidth(),getHeight());transform();}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        int w=getWidth(), h=getHeight();
        p.setStyle(Paint.Style.FILL); p.setColor(0xA8000000); c.drawRect(0,0,w,100,p); c.drawRect(0,h-250,w,h,p);
        text.setColor(Color.WHITE); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(20); c.drawText("ULTRAZOOM",24,38,text);
        text.setTypeface(Typeface.DEFAULT); text.setTextSize(12); c.drawText("COMPUTATIONAL CAMERA",24,62,text);
        text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(29);
        String z=zoom<10?String.format(Locale.US,"%.1fx",zoom):String.format(Locale.US,"%.0fx",zoom);
        float tw=text.measureText(z); c.drawText(z,w-tw-24,43,text);
        text.setTypeface(Typeface.DEFAULT); text.setTextSize(12); text.setColor(0xE6FFFFFF);
        c.drawText(status + (burstTarget>0 && busy ? "  "+statusProgress+"/"+burstTarget : ""),24,82,text);

        // mode strip
        float left=10, top=h-222, bw=(w-20)/6f;
        for(int i=0;i<6;i++){
            boolean active=mode.ordinal()==i;
            p.setColor(active?0xFFFFFFFF:0x55333333); c.drawRoundRect(left+i*bw,top,left+(i+1)*bw-3,top+42,10,10,p);
            text.setColor(active?Color.BLACK:Color.WHITE); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(10);
            String s=modeNames[i]; float sw=text.measureText(s); c.drawText(s,left+i*bw+(bw-3-sw)/2,top+26,text);
        }
        text.setTypeface(Typeface.DEFAULT); text.setColor(0xCCFFFFFF); text.setTextSize(12); c.drawText("pinça para ampliar • toque para focar",24,h-164,text);
        drawButton(c,42,h-112,torch?"⚡":"ϟ",torch);
        drawButton(c,w/2f,h-110,"●",false);
        drawButton(c,w-42,h-112,"100",false);
        text.setTextSize(10); text.setColor(0xCCFFFFFF); c.drawText("MAX",w-58,h-78,text);
        if(showLab){
            p.setColor(0xEE111111); c.drawRoundRect(18,110,w-18,h-270,22,22,p);
            text.setColor(Color.WHITE); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(18); c.drawText("LABORATÓRIO",38,145,text);
            text.setTypeface(Typeface.DEFAULT); text.setTextSize(13);
            c.drawText("Teste interno de captura computacional",38,171,text);
            c.drawText("LAB compara melhor frame, fusão e refinamento.",38,195,text);
            c.drawText("Câmeras traseiras: "+backCameraCount+"   •   sensor: "+(sensor!=null?sensor.width()+"×"+sensor.height():"—"),38,219,text);
            c.drawText("JPEG: "+(jpegSize!=null?jpegSize.getWidth()+"×"+jpegSize.getHeight():"—")+"   •   hardware max: "+String.format(Locale.US,"%.1fx",maxHardware),38,242,text);
            c.drawText("Toque novamente no LAB para fechar.",38,265,text);
        }
    }

    private void drawButton(Canvas c,float x,float y,String s,boolean active){
        p.setColor(active?0xFFFFFFFF:0x66000000); c.drawCircle(x,y,29,p);
        text.setColor(active?Color.BLACK:Color.WHITE); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); text.setTextSize(s.equals("●")?28:15);
        float tw=text.measureText(s); c.drawText(s,x-tw/2,y+6,text);
    }

    private void selectModeAt(float x){
        float bw=(getWidth()-20)/6f; int idx=(int)((x-10)/bw); if(idx<0)idx=0;if(idx>5)idx=5;
        mode=Mode.values()[idx]; showLab=mode==Mode.LAB; status=mode==Mode.AUTO?"AUTO • ADAPTATIVO":modeNames[idx]+" • PRONTO"; invalidate();
    }

    private void open(){
        try{
            CameraManager m=(CameraManager)getContext().getSystemService(Context.CAMERA_SERVICE);
            String best=null; CameraCharacteristics bestChars=null;
            for(String id:m.getCameraIdList()){
                CameraCharacteristics cc=m.getCameraCharacteristics(id); Integer facing=cc.get(CameraCharacteristics.LENS_FACING);
                if(facing!=null&&facing==CameraCharacteristics.LENS_FACING_BACK){backCameraCount++; if(best==null){best=id;bestChars=cc;}}
            }
            if(best==null)return; cameraId=best; chars=bestChars;
            sensor=chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Float hz=chars.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM); if(hz!=null)maxHardware=Math.max(1f,hz);
            android.hardware.camera2.params.StreamConfigurationMap map=chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if(map!=null){Size[] ss=map.getOutputSizes(ImageFormat.JPEG); if(ss!=null&&ss.length>0){jpegSize=ss[0];for(Size s:ss)if((long)s.getWidth()*s.getHeight()>(long)jpegSize.getWidth()*jpegSize.getHeight())jpegSize=s;}}
            flashAvailable=Boolean.TRUE.equals(chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE));
            if(reader!=null)reader.close();
            reader=ImageReader.newInstance(jpegSize!=null?jpegSize.getWidth():1920,jpegSize!=null?jpegSize.getHeight():1080,ImageFormat.JPEG,8);
            reader.setOnImageAvailableListener(r->{Image im=null;try{im=r.acquireNextImage();if(im==null)return;ByteBuffer bb=im.getPlanes()[0].getBuffer();byte[] data=new byte[bb.remaining()];bb.get(data);if(busy){Bitmap b=BitmapFactory.decodeByteArray(data,0,data.length);if(b!=null)burstFrames.add(b);}}catch(Exception ignored){}finally{if(im!=null)im.close();}},cameraHandler);
            if(getContext().checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED){
                m.openCamera(cameraId,new CameraDevice.StateCallback(){public void onOpened(CameraDevice d){device=d;createSession();}public void onDisconnected(CameraDevice d){d.close();device=null;}public void onError(CameraDevice d,int e){d.close();device=null;}},cameraHandler);
            }
        }catch(Exception e){post(()->Toast.makeText(getContext(),"Câmera indisponível: "+e.getMessage(),Toast.LENGTH_LONG).show());}
    }

    private void createSession(){
        try{
            SurfaceTexture st=preview.getSurfaceTexture();if(st==null)return;st.setDefaultBufferSize(1920,1080);Surface ps=new Surface(st);
            device.createCaptureSession(Arrays.asList(ps,reader.getSurface()),new CameraCaptureSession.StateCallback(){public void onConfigured(CameraCaptureSession s){session=s;applyPreview();}public void onConfigureFailed(CameraCaptureSession s){status="FALHA NA SESSÃO";postInvalidate();}},cameraHandler);
        }catch(Exception ignored){}
    }

    private CaptureRequest.Builder baseRequest(int template)throws Exception{
        CaptureRequest.Builder b=device.createCaptureRequest(template);
        b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        b.set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON);
        if(flashAvailable)b.set(CaptureRequest.FLASH_MODE,torch?CaptureRequest.FLASH_MODE_TORCH:CaptureRequest.FLASH_MODE_OFF);
        if(Build.VERSION.SDK_INT>=30)b.set(CaptureRequest.CONTROL_ZOOM_RATIO,Math.min(zoom,maxHardware));else b.set(CaptureRequest.SCALER_CROP_REGION,cropRect(Math.min(zoom,maxHardware)));
        return b;
    }

    private void applyPreview(){
        try{if(session==null||device==null)return;CaptureRequest.Builder b=baseRequest(CameraDevice.TEMPLATE_PREVIEW);b.addTarget(new Surface(preview.getSurfaceTexture()));session.setRepeatingRequest(b.build(),null,cameraHandler);transform();}
        catch(Exception ignored){}
    }

    private Rect cropRect(float z){if(sensor==null)return null;int w=Math.max(1,(int)(sensor.width()/z)),h=Math.max(1,(int)(sensor.height()/z));int l=sensor.centerX()-w/2,t=sensor.centerY()-h/2;return new Rect(l,t,l+w,t+h);}

    private void setZoom(float v){zoom=Math.max(1f,Math.min(100f,v));applyPreview();invalidate();}

    private void transform(){
        if(preview==null)return;float extra=Math.max(1f,zoom/Math.max(1f,maxHardware));Matrix m=new Matrix();float cx=getWidth()/2f,cy=getHeight()/2f;m.setScale(extra,extra,cx,cy);preview.setTransform(m);
    }

    private void focus(float x,float y){
        if(session==null||device==null||sensor==null||busy)return;
        try{float vx=Math.max(0,Math.min(1,x/getWidth())),vy=Math.max(0,Math.min(1,y/getHeight()));float z=Math.min(zoom,maxHardware);int w=(int)(sensor.width()/z),h=(int)(sensor.height()/z);int l=sensor.centerX()-w/2,t=sensor.centerY()-h/2;int fx=(int)(l+vx*w),fy=(int)(t+vy*h);int sw=Math.max(100,w/8),sh=Math.max(100,h/8);Rect r=new Rect(Math.max(sensor.left,fx-sw/2),Math.max(sensor.top,fy-sh/2),Math.min(sensor.right,fx+sw/2),Math.min(sensor.bottom,fy+sh/2));CaptureRequest.Builder b=baseRequest(CameraDevice.TEMPLATE_PREVIEW);b.addTarget(new Surface(preview.getSurfaceTexture()));b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_AUTO);b.set(CaptureRequest.CONTROL_AF_TRIGGER,CaptureRequest.CONTROL_AF_TRIGGER_START);b.set(CaptureRequest.CONTROL_AF_REGIONS,new MeteringRectangle[]{new MeteringRectangle(r,MeteringRectangle.METERING_WEIGHT_MAX-1)});session.capture(b.build(),null,cameraHandler);applyPreview();}
        catch(Exception ignored){}
    }

    private int rotation(){int r=getContext().getSystemService(WindowManager.class).getDefaultDisplay().getRotation();if(r==Surface.ROTATION_0)return 90;if(r==Surface.ROTATION_90)return 0;if(r==Surface.ROTATION_180)return 270;return 180;}

    private int framesForMode(){
        switch(mode){case RAPIDO:return 1;case PRO:return 4;case ULTRA:return 6;case MAX:return Math.max(4,Math.min(8,autoFrames()+2));case LAB:return 8;default:return autoFrames();}
    }
    private int autoFrames(){
        ActivityManager am=(ActivityManager)getContext().getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); if(am!=null)am.getMemoryInfo(mi);
        long free=mi.availMem/(1024L*1024L);
        int cap=free>3500?8:free>2200?6:free>1400?4:2;
        if(zoom<3)return Math.min(2,cap); if(zoom<8)return Math.min(4,cap); if(zoom<20)return Math.min(6,cap); return cap;
    }

    private void capture(){
        if(busy||session==null||device==null)return;
        busy=true;burstFrames.clear();burstTarget=framesForMode();capturesIssued=0;burstStarted=System.currentTimeMillis();status=(mode==Mode.RAPIDO?"CAPTURANDO": "CAPTURA COMPUTACIONAL");invalidate();issueStill(0);
    }

    private void issueStill(int index){
        if(!busy)return;
        try{
            CaptureRequest.Builder b=baseRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);b.addTarget(reader.getSurface());b.set(CaptureRequest.JPEG_ORIENTATION,rotation());
            session.capture(b.build(),new CameraCaptureSession.CaptureCallback(){
                @Override public void onCaptureCompleted(CameraCaptureSession s,CaptureRequest r,TotalCaptureResult result){
                    capturesIssued++;statusProgress=capturesIssued;postInvalidate();
                    if(capturesIssued<burstTarget){workHandler.postDelayed(()->issueStill(capturesIssued), mode==Mode.MAX||mode==Mode.LAB?80:45);}
                    else workHandler.postDelayed(()->finishBurst(),600);
                }
            },cameraHandler);
        }catch(Exception e){busy=false;status="ERRO DE CAPTURA";invalidate();}
    }

    private void finishBurst(){
        final ArrayList<Bitmap> frames;
        synchronized(burstFrames){frames=new ArrayList<>(burstFrames);}
        if(frames.isEmpty()){busy=false;status="NENHUM FRAME";invalidate();return;}
        status="ANALISANDO";invalidate();
        cpu.execute(()->processFrames(frames));
    }

    private void processFrames(ArrayList<Bitmap> frames){
        try{
            List<FrameScore> scored=new ArrayList<>();
            for(Bitmap b:frames)scored.add(new FrameScore(b,sharpness(b)));
            Collections.sort(scored,Comparator.comparingDouble((FrameScore f)->f.score).reversed());
            Bitmap best=scored.get(0).bitmap;
            if(mode==Mode.RAPIDO){saveBitmap(cropAndScale(best,zoom),"RAPIDO");complete("RÁPIDO • "+frames.size()+" frame");return;}
            status="ALINHANDO";postInvalidate();
            int limit=Math.min(frames.size(),mode==Mode.PRO?4:mode==Mode.ULTRA?6:8);
            ArrayList<Bitmap> selected=new ArrayList<>();for(int i=0;i<limit;i++)selected.add(scored.get(i).bitmap);
            Bitmap fused=fuseAligned(selected,zoom);
            status="REFINANDO";postInvalidate();
            Bitmap enhanced=enhance(fused);
            if(mode==Mode.LAB){
                saveBitmap(cropAndScale(best,zoom),"LAB_BEST");
                saveBitmap(cropAndScale(fused,zoom),"LAB_FUSAO");
                saveBitmap(cropAndScale(enhanced,zoom),"LAB_MAX");
                if(!fused.isRecycled())fused.recycle();
                recycleExcept(frames,best,enhanced);
                complete("LAB • "+selected.size()+" frames • 3 resultados");return;
            }
            saveBitmap(cropAndScale(enhanced,zoom),mode==Mode.MAX?"MAX":modeNames[mode.ordinal()]);
            if(!fused.isRecycled())fused.recycle();
            recycleExcept(frames,enhanced);
            complete(modeNames[mode.ordinal()]+" • "+selected.size()+" frames");
        }catch(Exception e){complete("FALHA NO PROCESSAMENTO");}
    }

    private void recycleExcept(List<Bitmap> all,Bitmap... keep){
        for(Bitmap b:all){boolean k=false;for(Bitmap x:keep)if(b==x)k=true;if(!k&&!b.isRecycled())b.recycle();}
    }

    private static class FrameScore{Bitmap bitmap;double score;FrameScore(Bitmap b,double s){bitmap=b;score=s;}}

    private double sharpness(Bitmap b){
        int w=Math.min(160,b.getWidth()),h=Math.min(120,b.getHeight());Bitmap s=Bitmap.createScaledBitmap(b,w,h,true);int[] px=new int[w*h];s.getPixels(px,0,w,0,0,w,h);double sum=0,sum2=0;int n=0;
        for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int c=luma(px[y*w+x]);int l=luma(px[y*w+x-1]),r=luma(px[y*w+x+1]),u=luma(px[(y-1)*w+x]),d=luma(px[(y+1)*w+x]);double v=(4*c-l-r-u-d);sum+=v;sum2+=v*v;n++;}
        if(!s.isRecycled())s.recycle();double mean=sum/n;return Math.max(0,sum2/n-mean*mean);
    }

    private int luma(int c){return (77*Color.red(c)+150*Color.green(c)+29*Color.blue(c))>>8;}

    private Bitmap fuseAligned(ArrayList<Bitmap> frames,float z){
        Bitmap ref=cropAndScale(frames.get(0),z,1280);int w=ref.getWidth(),h=ref.getHeight();
        long[] acc=new long[w*h*3];float[] weight=new float[w*h];
        addAligned(ref,ref,acc,weight,1f);
        for(int i=1;i<frames.size();i++){Bitmap b=cropAndScale(frames.get(i),z,1280);int[] shift=findShift(ref,b);Bitmap aligned=translate(b,shift[0],shift[1]);addAligned(aligned,ref,acc,weight,0.75f);if(!aligned.isRecycled())aligned.recycle();if(!b.isRecycled())b.recycle();}
        int[] out=new int[w*h];for(int i=0;i<out.length;i++){float q=Math.max(1,weight[i]);int rr=(int)Math.min(255,acc[i*3]/q),gg=(int)Math.min(255,acc[i*3+1]/q),bb=(int)Math.min(255,acc[i*3+2]/q);out[i]=Color.rgb(rr,gg,bb);}Bitmap result=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);result.setPixels(out,0,w,0,0,w,h);ref.recycle();return result;
    }

    private void addAligned(Bitmap b,Bitmap ref,long[] acc,float[] weight,float wt){
        int w=ref.getWidth(),h=ref.getHeight(),bw=b.getWidth(),bh=b.getHeight();Bitmap s=b;if(bw!=w||bh!=h)s=Bitmap.createScaledBitmap(b,w,h,true);int[] px=new int[w*h];s.getPixels(px,0,w,0,0,w,h);for(int i=0;i<px.length;i++){int c=px[i];acc[i*3]+=Color.red(c)*wt;acc[i*3+1]+=Color.green(c)*wt;acc[i*3+2]+=Color.blue(c)*wt;weight[i]+=wt;}if(s!=b&&!s.isRecycled())s.recycle();
    }

    private int[] findShift(Bitmap a,Bitmap b){
        int size=96;Bitmap aa=Bitmap.createScaledBitmap(a,size,size,true),bb=Bitmap.createScaledBitmap(b,size,size,true);int[] ap=new int[size*size],bp=new int[size*size];aa.getPixels(ap,0,size,0,0,size,size);bb.getPixels(bp,0,size,0,0,size,size);double best=Double.MAX_VALUE;int bx=0,by=0;
        for(int dy=-4;dy<=4;dy++)for(int dx=-4;dx<=4;dx++){double err=0;int n=0;for(int y=10;y<size-10;y+=3)for(int x=10;x<size-10;x+=3){int xx=x+dx,yy=y+dy;if(xx<0||xx>=size||yy<0||yy>=size)continue;err+=Math.abs(luma(ap[y*size+x])-luma(bp[yy*size+xx]));n++;}err/=Math.max(1,n);if(err<best){best=err;bx=dx;by=dy;}}
        aa.recycle();bb.recycle();return new int[]{bx*(a.getWidth()/size),by*(a.getHeight()/size)};
    }

    private Bitmap translate(Bitmap b,int dx,int dy){Matrix m=new Matrix();m.setTranslate(dx,dy);Bitmap out=Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);return out;}

    private Bitmap enhance(Bitmap b){
        Bitmap out=Bitmap.createBitmap(b.getWidth(),b.getHeight(),Bitmap.Config.ARGB_8888);int w=b.getWidth(),h=b.getHeight();int[] in=new int[w*h],px=new int[w*h];b.getPixels(in,0,w,0,0,w,h);
        for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int i=y*w+x,c=in[i];int l=in[i-1],r=in[i+1],u=in[i-w],d=in[i+w];int rr=Color.red(c)+clamp((Color.red(c)*4-Color.red(l)-Color.red(r)-Color.red(u)-Color.red(d))/12);int gg=Color.green(c)+clamp((Color.green(c)*4-Color.green(l)-Color.green(r)-Color.green(u)-Color.green(d))/12);int bb=Color.blue(c)+clamp((Color.blue(c)*4-Color.blue(l)-Color.blue(r)-Color.blue(u)-Color.blue(d))/12);px[i]=Color.rgb(clamp(rr),clamp(gg),clamp(bb));}
        out.setPixels(px,0,w,0,0,w,h);if(!b.isRecycled())b.recycle();return out;
    }
    private int clamp(int v){return Math.max(-30,Math.min(30,v));}

    private Bitmap cropAndScale(Bitmap src,float z){return cropAndScale(src,z,4096);}
    private Bitmap cropAndScale(Bitmap src,float z,int maxDim){
        int cw=Math.max(1,(int)(src.getWidth()/Math.min(z,100f))),ch=Math.max(1,(int)(src.getHeight()/Math.min(z,100f)));int l=Math.max(0,(src.getWidth()-cw)/2),t=Math.max(0,(src.getHeight()-ch)/2);Bitmap crop=Bitmap.createBitmap(src,l,t,Math.min(cw,src.getWidth()-l),Math.min(ch,src.getHeight()-t));int ow=Math.min(maxDim,Math.max(1080,crop.getWidth()));int oh=Math.min(maxDim,Math.max(1080,(int)((long)crop.getHeight()*ow/(double)crop.getWidth())));Bitmap out=Bitmap.createScaledBitmap(crop,ow,oh,true);if(crop!=src&&!crop.isRecycled())crop.recycle();return out;
    }

    private void saveBitmap(Bitmap b,String tag){
        try{ContentValues cv=new ContentValues();cv.put(MediaStore.Images.Media.DISPLAY_NAME,"UltraZoom_"+tag+"_"+System.currentTimeMillis()+".jpg");cv.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");cv.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/UltraZoom");Uri u=getContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);if(u!=null){OutputStream os=getContext().getContentResolver().openOutputStream(u);b.compress(Bitmap.CompressFormat.JPEG,97,os);os.close();}}
        catch(Exception ignored){}finally{if(b!=null&&!b.isRecycled())b.recycle();}
    }

    private void complete(String s){busy=false;burstTarget=0;status=s;postInvalidate();postDelayed(()->{if(!busy){status=mode==Mode.AUTO?"AUTO • ADAPTATIVO":modeNames[mode.ordinal()]+" • PRONTO";invalidate();}},2200);}

    private void close(){
        try{if(session!=null){session.close();session=null;}if(device!=null){device.close();device=null;}if(reader!=null){reader.close();reader=null;}busy=false;}catch(Exception ignored){}
    }
    void start(){startThreads();if(preview.isAvailable()&&device==null)open();}
    void stop(){close();}

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_UP){float y=e.getY(),x=e.getX();
            if(y>getHeight()-250&&y<getHeight()-180){selectModeAt(x);return true;}
            if(y>getHeight()-180){if(Math.abs(x-getWidth()/2f)<85){capture();return true;}if(x<100){torch=!torch;applyPreview();invalidate();return true;}if(x>getWidth()-100){mode=Mode.MAX;setZoom(100);status="MAX • PRONTO";invalidate();return true;}}
        }
        pinch.onTouchEvent(e);tap.onTouchEvent(e);return true;
    }
}
