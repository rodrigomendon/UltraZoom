# UltraZoom 11.5.0

1. Envie `UltraZoom-00-v11.5.0-build.zip` para a raiz do repositório.
2. Substitua o workflow do repositório pelo `.github/workflows/build-apk.yml` que acompanha o ZIP.
3. Execute `Build UltraZoom APK` manualmente.
4. O workflow deve encontrar exatamente um ZIP com `UZ-115-TRIPLE-A`.
5. Se passar pelas verificações, executará `gradle --no-daemon --stacktrace clean assembleDebug`.
6. O APK será publicado como artefato `UltraZoom-v11.5-debug-apk`.

## Verificações críticas

- `UZ-115-TRIPLE-A`
- `import android.graphics.SurfaceTexture;`
- ausência de `android.view.SurfaceTexture`
- `setRectToRect` + `bufferRect` + escala uniforme
- seleção por `SENSOR_INFO_PIXEL_ARRAY_SIZE`
- `getPhysicalCameraIds()`
- `setPhysicalCameraId()`
- `UiLayout` e `validateLayout()`
- AF/AE `MeteringRectangle`
- nenhum literal hexadecimal Java acima de 32 bits sem sufixo válido
