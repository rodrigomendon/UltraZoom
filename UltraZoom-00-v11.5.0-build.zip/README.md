# UltraZoom 11.5.0 — correção estrutural

Build-ready Android Camera2 project.

## Objetivo desta versão

A 11.5 não trata os problemas como cosméticos. Ela corrige a estrutura do preview, seleção da câmera principal, diagnóstico real de câmeras físicas/públicas e layout.

### 11.5 mudanças
- Transformação do `TextureView` reescrita seguindo o padrão Camera2Basic: retângulo de buffer orientado, mapeamento `setRectToRect`, escala uniforme e rotação. O cálculo considera SENSOR_ORIENTATION de 0/90/180/270 e não usa escala X/Y independente.
- Seleção da câmera principal agora prioriza `SENSOR_INFO_PIXEL_ARRAY_SIZE`; em empate, menor ID. O diagnóstico mostra o critério usado.
- Diagnóstico lista todas as câmeras traseiras públicas com ID, resolução, FOV calculado e faixa de zoom.
- Diagnóstico mostra o resultado de `getPhysicalCameraIds()` da principal e tenta obter características de cada ID físico; se o fabricante não as expõe ao CameraManager, isso aparece explicitamente em vez de ser inferido.
- 0,5× só é habilitado quando há evidência de uma faixa lógica sub-1×, uma câmera física comprovadamente mais ampla ou uma câmera traseira pública comprovadamente mais ampla.
- Layout passou a ter um único `UiLayout` que calcula minimapa, lentes, barra de zoom, flash, obturador, modo e info. Há validação programática contra sobreposição.
- O minimapa foi retirado da região dos botões de lente.
- Transição visual curta é aplicada ao trocar de lente/reabrir câmera para evitar corte seco da interface.
- Toques de interface usam os mesmos `RectF` desenhados, eliminando coordenadas divergentes entre desenho e interação.
- AF/AE por toque permanece ativo.
- Zoom de hardware continua limitado ao range informado pela câmera; acima dele o app identifica explicitamente o crop digital.

## Limitação de prova

Esta versão foi submetida a validação estrutural/estática no ambiente de desenvolvimento, incluindo checagem de layout em tamanhos de tela representativos. O ambiente desta conversa não possui Android SDK/Gradle nem o Motorola Edge 60 Fusion conectado; portanto não é possível fabricar prints reais do aparelho ou declarar que o 0,5× existe no hardware sem executar o APK no aparelho. O próprio painel de diagnóstico da 11.5 foi preparado para fornecer esses números reais.

## Build

O workflow procura exatamente um ZIP contendo `UZ-115-TRIPLE-A`, falha se houver zero ou mais de um candidato, verifica os pontos críticos do código e executa `clean assembleDebug` com Java 17, Gradle 9.4.1 e Android 36.
