# UltraZoom 12.0.0 — Reviewed Build

Build identifier: `UZ-120-IMAGE-ENGINE`.

Esta versão passou por uma revisão estrutural antes do upload. O foco desta revisão é preservar as correções de orientação/zoom/AE da 11.6.5, eliminar a inconsistência do workflow do GitHub e reduzir a criação repetitiva de objetos `Surface` durante o zoom e foco.

## O que está nesta versão
- Transformação da `TextureView` alinhada ao padrão oficial do Camera2: a `TextureView` já compensa a orientação do sensor; a transformação adicional trata escala e rotação da tela.
- AE Lock temporário durante mudanças de zoom para reduzir oscilações de exposição.
- `CONTROL_ZOOM_METHOD_ZOOM_RATIO` em Android 16/API 36.
- Zoom de hardware respeitando o intervalo real reportado pela câmera (1x–10x neste aparelho testado).
- Acima do limite óptico/digital reportado, o app usa crop digital real em vez de apenas alterar o número exibido.
- Reutilização de uma `Surface` persistente para o preview, evitando criar uma nova `Surface` a cada atualização de zoom/foco.
- Workflow corrigido para selecionar exatamente esta versão pelo `BUILD_ID`.

## Limitação conhecida
O aparelho de teste não expõe a ultrawide como câmera pública/physical camera utilizável pelo Camera2, portanto 0,5x continua indisponível nesse caminho. Isso não é tratado como erro nesta versão.

## Build
O projeto deve ser enviado ao GitHub e compilado pelo workflow `.github/workflows/build-apk.yml`. A validação local desta revisão é estrutural/estática; a compilação Android real deve ser confirmada pelo GitHub Actions.
