package com.rodrigo.ultrazoom.diagnostic;

public final class AfStateMachine {
    public enum State { IDLE, CANCELLING, STARTING, SCANNING, FOCUSED, FAILED, TIMEOUT }
    private State state = State.IDLE;
    public void cancel(){ state=State.CANCELLING; }
    public void start(){ if(state==State.CANCELLING || state==State.IDLE || state==State.FAILED || state==State.TIMEOUT) state=State.STARTING; }
    public void result(Integer af){
        if(af==null) return;
        if(af==2 || af==4) state=State.FOCUSED;
        else if(af==1 || af==3) state=State.SCANNING;
        else if(af==0) state=State.IDLE;
    }
    public void timeout(){ if(state==State.STARTING || state==State.SCANNING) state=State.TIMEOUT; }
    public State get(){return state;}
    private AfStateMachine() {}
    public static AfStateMachine create(){return new AfStateMachine();}
}
