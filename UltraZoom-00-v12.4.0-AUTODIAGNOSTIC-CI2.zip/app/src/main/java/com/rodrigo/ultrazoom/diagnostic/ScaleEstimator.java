package com.rodrigo.ultrazoom.diagnostic;

/** Conservative scale estimator for small grayscale preview thumbnails. */
public final class ScaleEstimator {
    public static final class Result { public final float scale, confidence; public Result(float s,float c){scale=s;confidence=c;} }
    public static Result estimate(byte[] a,int aw,int ah,byte[] b,int bw,int bh,float minScale,float maxScale){
        if(a==null||b==null||aw<16||ah<16||bw<16||bh<16) return new Result(Float.NaN,0f);
        int featuresA=edgeCount(a,aw,ah), featuresB=edgeCount(b,bw,bh);
        if(featuresA<18 || featuresB<18) return new Result(Float.NaN,0f);
        float best=Float.NaN, second=-1f, bestScore=-1f;
        for(float s=minScale;s<=maxScale+0.001f;s+=0.05f){
            float score=similarity(a,aw,ah,b,bw,bh,s);
            if(score>bestScore){second=bestScore;bestScore=score;best=s;} else if(score>second) second=score;
        }
        float margin=bestScore-Math.max(0f,second);
        float conf=Math.max(0f,Math.min(1f,(bestScore-0.55f)*2f + margin*3f));
        return new Result(best,conf);
    }
    private static float similarity(byte[] a,int aw,int ah,byte[] b,int bw,int bh,float scale){
        int n=0; double sum=0,sa=0,sb=0,saa=0,sbb=0,sab=0;
        int w=Math.min(80,Math.min(aw,bw)), h=Math.min(60,Math.min(ah,bh));
        for(int y=2;y<h-2;y+=2) for(int x=2;x<w-2;x+=2){
            int bx=Math.round((x-w/2f)/scale+bw/2f), by=Math.round((y-h/2f)/scale+bh/2f);
            if(bx<1||bx>=bw-1||by<1||by>=bh-1) continue;
            float va=grad(a,aw,x,y), vb=grad(b,bw,bx,by);
            sa+=va; sb+=vb; saa+=va*va; sbb+=vb*vb; sab+=va*vb; n++;
        }
        if(n<30)return 0f; double da=n*saa-sa*sa, db=n*sbb-sb*sb;
        if(da<=1e-6||db<=1e-6)return 0f; return (float)((n*sab-sa*sb)/Math.sqrt(da*db)*0.5+0.5);
    }
    private static float grad(byte[] p,int w,int x,int y){
        int i=y*w+x; return Math.abs((p[i+1]&255)-(p[i-1]&255))+Math.abs((p[i+w]&255)-(p[i-w]&255));
    }
    private static int edgeCount(byte[] p,int w,int h){int c=0;for(int y=1;y<h-1;y+=2)for(int x=1;x<w-1;x+=2)if(grad(p,w,x,y)>45)c++;return c;}
    private ScaleEstimator(){}
}
