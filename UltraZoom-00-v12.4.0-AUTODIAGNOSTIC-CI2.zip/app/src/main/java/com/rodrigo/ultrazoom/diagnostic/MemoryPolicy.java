package com.rodrigo.ultrazoom.diagnostic;

public final class MemoryPolicy {
    public static int safeTargetFrames(int requested, int maxImages, int hardCap) {
        int cap = Math.max(1, Math.min(maxImages, hardCap));
        return Math.max(1, Math.min(requested, cap));
    }
    public static long estimatedArgbBytes(int width,int height,int frames){
        return Math.max(0L,width)*Math.max(0L,height)*4L*Math.max(0,frames);
    }
    private MemoryPolicy() {}
}
