package com.rodrigo.ultrazoom.diagnostic;

public final class ZoomConfidenceEngine {
    public enum State { UNKNOWN, PARTIAL, CONFIRMED, FAIL, REVOKED }
    /** FAIL/REVOKED absorbs. UNKNOWN is missing evidence, not failure. */
    public static State combine(State a, State b, State c) {
        if (a == State.FAIL || b == State.FAIL || c == State.FAIL ||
            a == State.REVOKED || b == State.REVOKED || c == State.REVOKED) return State.REVOKED;
        State[] v={a,b,c}; boolean anyConfirmed=false, anyPartial=false, anyUnknown=false;
        for(State s:v){ if(s==State.CONFIRMED)anyConfirmed=true; else if(s==State.PARTIAL)anyPartial=true; else if(s==State.UNKNOWN)anyUnknown=true; }
        if(anyPartial || (anyUnknown && anyConfirmed)) return State.PARTIAL;
        if(anyConfirmed) return State.CONFIRMED;
        return State.UNKNOWN;
    }
    private ZoomConfidenceEngine() {}
}
