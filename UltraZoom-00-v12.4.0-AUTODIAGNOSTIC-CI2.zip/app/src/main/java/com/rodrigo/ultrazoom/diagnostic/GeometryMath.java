package com.rodrigo.ultrazoom.diagnostic;

public final class GeometryMath {
    public static final class Point { public final float x,y; public Point(float x,float y){this.x=x;this.y=y;} }
    public static Point mapUniform(float x, float y, float srcW, float srcH, float dstLeft, float dstTop, float dstW, float dstH) {
        float scale = Math.min(dstW/srcW, dstH/srcH);
        float ox = dstLeft + (dstW-srcW*scale)/2f;
        float oy = dstTop + (dstH-srcH*scale)/2f;
        return new Point(ox+x*scale, oy+y*scale);
    }
    public static float aspect(float w,float h){ return w/Math.max(1f,h); }
    private GeometryMath() {}
}
