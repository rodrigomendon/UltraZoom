package com.rodrigo.ultrazoom;
import com.rodrigo.ultrazoom.diagnostic.ZoomConfidenceEngine;
import org.junit.Test;
import static org.junit.Assert.*;
public class ZoomConfidenceEngineTest {
 @Test public void unknownDoesNotFail(){ assertEquals(ZoomConfidenceEngine.State.PARTIAL, ZoomConfidenceEngine.combine(ZoomConfidenceEngine.State.CONFIRMED,ZoomConfidenceEngine.State.CONFIRMED,ZoomConfidenceEngine.State.UNKNOWN)); }
 @Test public void failIsAbsorbing(){ assertEquals(ZoomConfidenceEngine.State.REVOKED, ZoomConfidenceEngine.combine(ZoomConfidenceEngine.State.CONFIRMED,ZoomConfidenceEngine.State.FAIL,ZoomConfidenceEngine.State.UNKNOWN)); assertEquals(ZoomConfidenceEngine.State.REVOKED, ZoomConfidenceEngine.combine(ZoomConfidenceEngine.State.CONFIRMED,ZoomConfidenceEngine.State.CONFIRMED,ZoomConfidenceEngine.State.FAIL)); }
 @Test public void allUnknown(){ assertEquals(ZoomConfidenceEngine.State.UNKNOWN, ZoomConfidenceEngine.combine(ZoomConfidenceEngine.State.UNKNOWN,ZoomConfidenceEngine.State.UNKNOWN,ZoomConfidenceEngine.State.UNKNOWN)); }
 @Test public void allConfirmed(){ assertEquals(ZoomConfidenceEngine.State.CONFIRMED, ZoomConfidenceEngine.combine(ZoomConfidenceEngine.State.CONFIRMED,ZoomConfidenceEngine.State.CONFIRMED,ZoomConfidenceEngine.State.CONFIRMED)); }
}
