package com.rodrigo.ultrazoom;
import com.rodrigo.ultrazoom.diagnostic.MemoryPolicy;
import org.junit.Test;
import static org.junit.Assert.*;
public class MemoryPolicyTest {
 @Test public void targetNeverExceedsReader(){ assertEquals(4,MemoryPolicy.safeTargetFrames(5,4,4)); assertEquals(3,MemoryPolicy.safeTargetFrames(3,6,4)); }
 @Test public void byteEstimate(){ assertEquals(48L*1024*1024,MemoryPolicy.estimatedArgbBytes(4096,3072,1)); }
}
