package com.rodrigo.ultrazoom;
import com.rodrigo.ultrazoom.diagnostic.GeometryMath;
import org.junit.Test;
import static org.junit.Assert.*;
public class GeometryMathTest {
 @Test public void fourCornersPreserveAspect(){
  GeometryMath.Point a=GeometryMath.mapUniform(0,0,4,3,0,0,400,300);
  GeometryMath.Point b=GeometryMath.mapUniform(4,0,4,3,0,0,400,300);
  GeometryMath.Point c=GeometryMath.mapUniform(0,3,4,3,0,0,400,300);
  GeometryMath.Point d=GeometryMath.mapUniform(4,3,4,3,0,0,400,300);
  assertEquals(0,a.x,.001); assertEquals(0,a.y,.001);
  assertEquals(400,b.x,.001); assertEquals(0,b.y,.001);
  assertEquals(0,c.x,.001); assertEquals(300,c.y,.001);
  assertEquals(400,d.x,.001); assertEquals(300,d.y,.001);
  assertEquals(400f/300f, GeometryMath.aspect(4,3), .001);
 }
}
