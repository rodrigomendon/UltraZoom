package com.rodrigo.ultrazoom;
import com.rodrigo.ultrazoom.diagnostic.ScaleEstimator;
import org.junit.Test;
import static org.junit.Assert.*;
public class ScaleEstimatorTest {
 @Test public void rejectsFeaturelessScene(){ byte[] a=new byte[160*120], b=new byte[160*120]; ScaleEstimator.Result r=ScaleEstimator.estimate(a,160,120,b,160,120,1f,3f); assertEquals(0f,r.confidence,.001f); }
}
