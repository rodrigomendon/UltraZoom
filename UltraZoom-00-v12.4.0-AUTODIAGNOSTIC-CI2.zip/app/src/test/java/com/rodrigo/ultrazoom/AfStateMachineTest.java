package com.rodrigo.ultrazoom;
import com.rodrigo.ultrazoom.diagnostic.AfStateMachine;
import org.junit.Test;
import static org.junit.Assert.*;
public class AfStateMachineTest {
 @Test public void cancelStartFocused(){ AfStateMachine a=AfStateMachine.create(); a.cancel(); a.start(); a.result(1); a.result(4); assertEquals(AfStateMachine.State.FOCUSED,a.get()); }
 @Test public void timeoutIsExplicit(){ AfStateMachine a=AfStateMachine.create(); a.cancel(); a.start(); a.result(1); a.timeout(); assertEquals(AfStateMachine.State.TIMEOUT,a.get()); }
}
