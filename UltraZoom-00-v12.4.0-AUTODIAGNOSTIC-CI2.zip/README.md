# UltraZoom 12.4.0 — Auto Diagnostic

Build identifier: `UZ-124-AUTODIAGNOSTIC`.

This package contains the 12.4.0 Auto Diagnostic source plus the corrected geometry unit test. The previous CI failure was caused by an incorrect assertion in `GeometryMathTest`, not by the geometry implementation.

The version separates zoom diagnosis into three layers:

- **A — Declarado:** Camera2 `CaptureResult`, zoom ratio and crop geometry.
- **B — Observado:** comparison of preview frames captured at consecutive zoom levels when sufficient overlap/features exist.
- **C — Inferido:** detail evidence from JPEGs the user voluntarily captures; no hidden still capture is performed.

`UNKNOWN` means evidence is not available. It is not a failure. `FAIL` is contradictory evidence and is absorbing: any FAIL revokes the corresponding confirmation and requires recheck.

The diagnostic collector is opportunistic: it does not run in background, does not run below 20% battery, limits sampling/storage, and never modifies the photo saved by the user.

No manual calibration and no software photo zoom beyond the camera-reported range are included.

## Confidence rule

- Any `FAIL` → `REVOKED`.
- Otherwise, missing evidence (`UNKNOWN`) is not failure.
- `CONFIRMED + CONFIRMED + UNKNOWN` → `PARTIAL`.
- All three confirmed → `CONFIRMED`.

## Build

The repository workflow runs unit tests before the Android build, then performs static regression checks and `assembleDebug`.
