# UltraZoom 10.0.0

Versão focada em zoom real, controles persistentes e interface premium.

## Principais recursos
- Zoom exibido com o valor realmente aplicado.
- Zoom digital por `SCALER_CROP_REGION` acima do limite de hardware, inclusive até 100x, sem apenas alterar o número na tela.
- Detecção conservadora de ultrawide 0,5x; quando não houver suporte, o app informa isso.
- Minimap de enquadramento com retângulo proporcional ao crop.
- Preview sem esticar a imagem, usando transformação baseada na proporção do buffer.
- Botão de foto central, flash OFF/AUTO/ON, seletor de modos e painel de diagnóstico.
- Modos AUTO, PRO, ULTRA, MAX e NIGHT.
- NIGHT usa Low Light Boost quando suportado e processamento adicional/múltiplos frames quando não suportado.
- Controles permanecem visíveis depois da autorização da câmera.

## Build
O workflow `.github/workflows/build-apk.yml` procura primeiro `UltraZoom-v10.0.0-build.zip`, extrai com `unzip -o` em diretório temporário e só então executa `assembleDebug`.
