package com.rodrigo.ultrazoom;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Size;
import android.util.SizeF;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceTexture;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ = 44;
    private UltraCameraView camera;

    @Override public void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        immersive();
        camera = new UltraCameraView(this);
        setContentView(camera);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ);
        } else {
            camera.start();
        }
    }

    private void immersive() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override protected void onResume() {
        super.onResume();
        immersive();
        if (camera != null && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) camera.start();
    }

    @Override protected void onPause() {
        if (camera != null) camera.stop();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (camera != null) camera.shutdown();
        super.onDestroy();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) camera.start();
        else Toast.makeText(this, "A câmera é necessária para o UltraZoom.", Toast.LENGTH_LONG).show();
    }
}

class UltraCameraView extends ViewGroup {
    private enum Mode { AUTO, PRO, ULTRA, MAX, NIGHT }
    private static final String BUILD_ID = "UZ-100-TRIPLE-A";
    private static final int WHITE_92 = 0xEBFFFFFF;
    private static final int WHITE_70 = 0xB3FFFFFF;
    private static final int PANEL = 0xC90A0A0C;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextureView preview;
    private CameraDevice device;
    private CameraCaptureSession session;
    private CameraCharacteristics chars;
    private String cameraId;
    private String mainCameraId;
    private String wideCameraId;
    private Size jpegSize;
    private Rect sensor;
    private float maxHardware = 1f;
    private float minHardware = 1f;
    private float zoom = 1f;
    private boolean flashAvailable;
    private boolean lowLightBoostSupported;
    private boolean wideSupported;
    private boolean busy;
    private boolean showInfo;
    private boolean showModeMenu;
    private int flashMode = 0; // off / auto / on
    private ImageReader reader;
    private HandlerThread cameraThread;
    private HandlerThread workThread;
    private Handler cameraHandler;
    private Handler workHandler;
    private Mode mode = Mode.AUTO;
    private String status = "INICIANDO CÂMERA…";
    private float focusX = -1f, focusY = -1f;
    private long focusUntil;
    private float pinchStart = 1f, pinchDistance;
    private int targetFrames;
    private int completedCaptures;
    private boolean finalizeScheduled;
    private final List<Bitmap> frames = Collections.synchronizedList(new ArrayList<Bitmap>());
    private Bitmap miniBitmap;
    private long lastMiniCapture;
    private boolean miniCapturePending;

    private static final String[] MODES = {"AUTO", "PRO", "ULTRA", "MAX", "NIGHT"};
    private static final String[] DESCS = {
            "Equilíbrio automático", "Controle manual e estabilidade", "Processamento multi-frame", "Máxima ampliação disponível", "Baixa luz + múltiplos frames"
    };

    UltraCameraView(Context c) {
        super(c);
        setWillNotDraw(false);
        setBackgroundColor(Color.BLACK);
        text.setTypeface(Typeface.create("sans", Typeface.BOLD));
        startThreads();
        preview = new TextureView(c);
        preview.setOpaque(true);
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) { open(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) { transform(); }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { close(); return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture s) { captureMiniIfNeeded(); }
        });
        addView(preview);
    }

    private void startThreads() {
        if (cameraThread == null) {
            cameraThread = new HandlerThread("UZ-Camera");
            cameraThread.start();
            cameraHandler = new Handler(cameraThread.getLooper());
        }
        if (workThread == null) {
            workThread = new HandlerThread("UZ-Work");
            workThread.start();
            workHandler = new Handler(workThread.getLooper());
        }
    }

    @Override protected void onMeasure(int ws, int hs) {
        int w = Math.max(1, MeasureSpec.getSize(ws));
        int h = Math.max(1, MeasureSpec.getSize(hs));
        setMeasuredDimension(w, h);
        preview.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
    }

    @Override protected void onLayout(boolean changed, int l, int top, int r, int b) {
        preview.layout(0, 0, getWidth(), getHeight());
        transform();
    }

    @Override protected void dispatchDraw(Canvas c) {
        super.dispatchDraw(c);
        drawHud(c);
    }

    private void rounded(Canvas c, float l, float top, float r, float b, float radius, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawRoundRect(l, top, r, b, radius, radius, p);
    }

    private void strokeRound(Canvas c, float l, float top, float r, float b, float radius, float stroke, int color) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(stroke);
        p.setColor(color);
        c.drawRoundRect(l, top, r, b, radius, radius, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        text.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        text.setTextSize(size);
        text.setColor(color);
        c.drawText(s, x, y, text);
    }

    private void center(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        text.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        text.setTextSize(size);
        text.setColor(color);
        c.drawText(s, x - text.measureText(s) / 2f, y, text);
    }

    private void drawHud(Canvas c) {
        int w = getWidth(), h = getHeight();
        float scale = Math.max(0.85f, Math.min(1.35f, w / 1080f));

        // Cinematic glass panels. Controls stay visible after permission is granted.
        rounded(c, 0, 0, w, 150 * scale, 0, 0xB5000000);
        rounded(c, 0, h - 360 * scale, w, h, 0, 0xD9070709);

        txt(c, "ULTRAZOOM", 28 * scale, 42 * scale, 26 * scale, Color.WHITE, true);
        txt(c, "CAMERA COMPUTACIONAL", 30 * scale, 66 * scale, 12 * scale, WHITE_70, true);
        txt(c, "● " + status, 30 * scale, 93 * scale, 12 * scale, 0xD9FFFFFF, false);

        // The actual applied value is intentionally dominant.
        center(c, zoomString(), w - 105 * scale, 52 * scale, 44 * scale, Color.WHITE, true);
        center(c, MODES[mode.ordinal()], w - 105 * scale, 80 * scale, 14 * scale, WHITE_92, true);
        center(c, zoomDomain(), w - 105 * scale, 102 * scale, 11 * scale, WHITE_70, false);

        drawMiniMap(c, w, scale);
        drawLensPills(c, w, scale);
        drawZoomBar(c, w, h, scale);
        drawBottom(c, w, h, scale);

        if (focusUntil > System.currentTimeMillis()) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3 * scale);
            p.setColor(Color.WHITE);
            c.drawRoundRect(focusX - 34 * scale, focusY - 34 * scale, focusX + 34 * scale, focusY + 34 * scale, 8, 8, p);
            p.setStyle(Paint.Style.FILL);
            postInvalidateDelayed(80);
        }
        if (showModeMenu) drawModeSheet(c, scale);
        if (showInfo) drawInfo(c, scale);
    }

    private String zoomString() {
        if (zoom < 10f) return String.format(Locale.US, "%.1f×", zoom);
        if (zoom < 100f) return String.format(Locale.US, "%.0f×", zoom);
        return "100×";
    }

    private String zoomDomain() {
        if (zoom < 0.99f) return "ULTRAWIDE";
        if (zoom <= maxHardware + 0.01f) return "HARDWARE";
        return "CROP DIGITAL REAL";
    }

    private void drawMiniMap(Canvas c, int w, float s) {
        float left = w - 174 * s, top = 112 * s, right = w - 28 * s, bottom = 196 * s;
        rounded(c, left, top, right, bottom, 14 * s, 0xB0000000);
        if (miniBitmap != null && !miniBitmap.isRecycled()) {
            Rect src = new Rect(0, 0, miniBitmap.getWidth(), miniBitmap.getHeight());
            c.drawBitmap(miniBitmap, src, new RectF(left + 4 * s, top + 4 * s, right - 4 * s, bottom - 4 * s), p);
        }
        RectF view = zoomViewRect(left + 4 * s, top + 4 * s, right - 4 * s, bottom - 4 * s);
        strokeRound(c, view.left, view.top, view.right, view.bottom, 3 * s, 2 * s, Color.WHITE);
        txt(c, "ENQUADRAMENTO", left + 9 * s, bottom + 16 * s, 8 * s, WHITE_92, true);
    }

    private RectF zoomViewRect(float l, float t, float r, float b) {
        if (sensor == null) return new RectF(l, t, r, b);
        float z = Math.max(1f, zoom);
        float fracW = Math.min(1f, 1f / z);
        float fracH = Math.min(1f, 1f / z);
        float cx = 0.5f, cy = 0.5f;
        float rw = (r - l) * fracW;
        float rh = (b - t) * fracH;
        return new RectF(cx * (r - l) + l - rw / 2f, cy * (b - t) + t - rh / 2f,
                cx * (r - l) + l + rw / 2f, cy * (b - t) + t + rh / 2f);
    }

    private void drawLensPills(Canvas c, int w, float s) {
        float y = 164 * s;
        float gap = 8 * s;
        float bw = (w - 56 * s - 4 * gap) / 5f;
        String[] lens = {"0,5×", "1×", "2×", "6×", "10×"};
        for (int i = 0; i < lens.length; i++) {
            float x = 28 * s + i * (bw + gap);
            boolean active = (i == 0 && zoom < 0.75f) || (i == 1 && zoom >= 0.75f && zoom < 1.5f) ||
                    (i == 2 && zoom >= 1.5f && zoom < 4f) || (i == 3 && zoom >= 4f && zoom < 8f) || (i == 4 && zoom >= 8f && zoom < 14f);
            boolean enabled = i != 0 || wideSupported;
            int bg = active ? 0xFFF4F4F4 : 0x80000000;
            if (!enabled) bg = 0x55101010;
            rounded(c, x, y, x + bw, y + 58 * s, 28 * s, bg);
            center(c, lens[i], x + bw / 2f, y + 38 * s, 19 * s, active ? Color.BLACK : (enabled ? Color.WHITE : 0x77FFFFFF), true);
        }
        if (!wideSupported) txt(c, "0,5× indisponível neste aparelho", 30 * s, y + 79 * s, 11 * s, 0xCCFFFFFF, false);
    }

    private void drawZoomBar(Canvas c, int w, int h, float s) {
        float y = h - 324 * s;
        txt(c, "AMPLIAÇÃO", 28 * s, y, 15 * s, Color.WHITE, true);
        txt(c, zoomString() + " aplicado", w - 175 * s, y, 14 * s, WHITE_92, true);
        String[] vals = {"0,5", "1", "2", "4", "6", "10", "20", "50", "100"};
        float step = (w - 56 * s) / 8f;
        for (int i = 0; i < vals.length; i++) {
            float v = Float.parseFloat(vals[i].replace(',', '.'));
            boolean active = Math.abs(zoom - v) < (v < 2 ? .08f : .4f);
            center(c, vals[i] + "×", 28 * s + i * step, y + 29 * s, (active ? 16 : 13) * s, active ? Color.WHITE : WHITE_70, active);
        }
        p.setColor(0xAAFFFFFF);
        c.drawRoundRect(28 * s, y + 51 * s, w - 28 * s, y + 57 * s, 4 * s, 4 * s, p);
        double lo = Math.log(.5), hi = Math.log(100);
        double q = (Math.log(Math.max(.5, Math.min(100, zoom))) - lo) / (hi - lo);
        p.setColor(Color.WHITE);
        c.drawCircle(28 * s + (float)q * (w - 56 * s), y + 54 * s, 9 * s, p);
        txt(c, "0,5×", 28 * s, y + 84 * s, 11 * s, WHITE_70, false);
        txt(c, "100×", w - 64 * s, y + 84 * s, 11 * s, WHITE_70, false);
    }

    private void drawBottom(Canvas c, int w, int h, float s) {
        float cy = h - 130 * s;
        drawFlash(c, 82 * s, cy, s);
        drawShutter(c, w / 2f, cy, s);
        drawMode(c, w - 82 * s, cy, s);
        center(c, flashLabel(), 82 * s, cy + 65 * s, 13 * s, Color.WHITE, true);
        center(c, "FOTOGRAFAR", w / 2f, cy + 65 * s, 14 * s, Color.WHITE, true);
        center(c, "MODO", w - 82 * s, cy + 65 * s, 13 * s, Color.WHITE, true);
        txt(c, "Toque no preview para focar", 28 * s, h - 25 * s, 12 * s, WHITE_70, false);
        txt(c, "ⓘ", w - 52 * s, h - 21 * s, 24 * s, Color.WHITE, true);
    }

    private String flashLabel() {
        return flashMode == 0 ? "FLASH OFF" : flashMode == 1 ? "FLASH AUTO" : "FLASH ON";
    }

    private void drawFlash(Canvas c, float x, float y, float s) {
        rounded(c, x - 52 * s, y - 48 * s, x + 52 * s, y + 48 * s, 26 * s, flashMode == 0 ? 0x70000000 : 0xFFF2F2F2);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4 * s);
        p.setColor(flashMode == 0 ? Color.WHITE : Color.BLACK);
        Path q = new Path();
        q.moveTo(x + 7 * s, y - 30 * s); q.lineTo(x - 13 * s, y + 3 * s); q.lineTo(x + 2 * s, y + 3 * s);
        q.lineTo(x - 7 * s, y + 30 * s); q.lineTo(x + 19 * s, y - 7 * s); q.lineTo(x + 4 * s, y - 7 * s); q.close();
        c.drawPath(q, p); p.setStyle(Paint.Style.FILL);
    }

    private void drawShutter(Canvas c, float x, float y, float s) {
        p.setColor(Color.WHITE); c.drawCircle(x, y, 54 * s, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4 * s); p.setColor(0xFF111111); c.drawCircle(x, y, 42 * s, p); p.setStyle(Paint.Style.FILL);
        if (busy) { p.setColor(0xFF111111); c.drawRoundRect(x - 13 * s, y - 13 * s, x + 13 * s, y + 13 * s, 4 * s, 4 * s, p); }
    }

    private void drawMode(Canvas c, float x, float y, float s) {
        rounded(c, x - 52 * s, y - 48 * s, x + 52 * s, y + 48 * s, 26 * s, 0x85000000);
        center(c, "MODO", x, y - 3 * s, 12 * s, Color.WHITE, true);
        center(c, MODES[mode.ordinal()], x, y + 24 * s, 13 * s, Color.WHITE, true);
    }

    private void drawModeSheet(Canvas c, float s) {
        int w = getWidth(), h = getHeight();
        rounded(c, 18 * s, 108 * s, w - 18 * s, h - 52 * s, 30 * s, 0xF20B0B0D);
        txt(c, "MODO DE CAPTURA", 38 * s, 151 * s, 27 * s, Color.WHITE, true);
        float y = 174 * s;
        for (int i = 0; i < MODES.length; i++) {
            boolean active = i == mode.ordinal();
            rounded(c, 30 * s, y, w - 30 * s, y + 72 * s, 22 * s, active ? 0xFFF4F4F4 : 0x331F1F22);
            txt(c, MODES[i], 52 * s, y + 31 * s, 21 * s, active ? Color.BLACK : Color.WHITE, true);
            txt(c, DESCS[i], 52 * s, y + 55 * s, 13 * s, active ? 0xFF333333 : 0xCCFFFFFF, false);
            y += 79 * s;
        }
        txt(c, "Toque fora para fechar", 38 * s, h - 76 * s, 12 * s, WHITE_70, false);
    }

    private void drawInfo(Canvas c, float s) {
        int w = getWidth(), h = getHeight();
        rounded(c, 18 * s, 105 * s, w - 18 * s, h - 52 * s, 30 * s, 0xF20B0B0D);
        txt(c, "ULTRAZOOM • DIAGNÓSTICO", 38 * s, 149 * s, 25 * s, Color.WHITE, true);
        float y = 193 * s;
        infoRow(c, "Zoom aplicado", zoomString(), y, s); y += 38 * s;
        infoRow(c, "Modo", MODES[mode.ordinal()], y, s); y += 38 * s;
        infoRow(c, "Câmera", cameraId == null ? "—" : cameraId, y, s); y += 38 * s;
        infoRow(c, "Hardware", String.format(Locale.US, "%.1f×", maxHardware), y, s); y += 38 * s;
        infoRow(c, "0,5× ultrawide", wideSupported ? "DISPONÍVEL" : "INDISPONÍVEL", y, s); y += 38 * s;
        infoRow(c, "Flash", flashAvailable ? "DISPONÍVEL" : "INDISPONÍVEL", y, s); y += 38 * s;
        infoRow(c, "Night Boost", lowLightBoostSupported ? "SUPORTADO" : "MULTI-FRAME", y, s); y += 38 * s;
        infoRow(c, "Sensor", sensor == null ? "—" : sensor.width() + " × " + sensor.height(), y, s); y += 38 * s;
        txt(c, "BUILD " + BUILD_ID, 38 * s, y + 4 * s, 12 * s, WHITE_70, false);
        txt(c, "O app nunca mostra zoom maior sem aplicar o enquadramento real.", 38 * s, h - 108 * s, 12 * s, WHITE_70, false);
        txt(c, "Toque fora para fechar", 38 * s, h - 78 * s, 12 * s, WHITE_70, false);
    }

    private void infoRow(Canvas c, String a, String b, float y, float s) {
        txt(c, a, 38 * s, y, 13 * s, 0x99FFFFFF, false);
        txt(c, b, 270 * s, y, 16 * s, Color.WHITE, true);
    }

    private void open() {
        if (device != null) return;
        try {
            CameraManager cm = (CameraManager)getContext().getSystemService(Context.CAMERA_SERVICE);
            String[] ids = cm.getCameraIdList();
            mainCameraId = null;
            wideCameraId = null;
            wideSupported = false;
            float bestMainFov = Float.MAX_VALUE;
            float widestFov = 0f;
            String fallback = null;

            // Prefer the logical back camera, then a normal back camera with a usable sensor.
            for (String id : ids) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
                if (fallback == null) fallback = id;
                float fov = horizontalFov(cc);
                int[] caps = cc.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
                boolean logical = hasCapability(caps, CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA);
                if (logical) {
                    mainCameraId = id;
                    bestMainFov = fov > 0 ? fov : Float.MAX_VALUE;
                    break;
                }
                if (fov > 0 && fov < bestMainFov) { mainCameraId = id; bestMainFov = fov; }
            }
            if (mainCameraId == null) mainCameraId = fallback;
            if (mainCameraId == null) { status = "NENHUMA CÂMERA TRASEIRA"; invalidate(); return; }

            CameraCharacteristics main = cm.getCameraCharacteristics(mainCameraId);
            float mainFov = horizontalFov(main);
            RangeZ mainRange = range(main);
            // A logical camera can expose the ultrawide through a sub-1x zoom ratio.
            if (mainRange.min <= 0.55f) {
                wideSupported = true;
                wideCameraId = mainCameraId;
            }

            // Otherwise find a physically wider back camera. Compare focal length/FOV, not arbitrary IDs.
            for (String id : ids) {
                if (id.equals(mainCameraId)) continue;
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
                float fov = horizontalFov(cc);
                if (fov > widestFov) widestFov = fov;
                if (mainFov > 0 && fov > mainFov * 1.18f) {
                    RangeZ rz = range(cc);
                    if (rz.max >= 1f) {
                        wideCameraId = id;
                        wideSupported = true;
                    }
                }
            }
            if (!wideSupported && widestFov > 0 && mainFov <= 0) {
                // Conservative fallback when focal metadata is incomplete: only advertise a separate camera
                // when it has a materially larger sensor FOV than the selected main camera.
                for (String id : ids) {
                    if (id.equals(mainCameraId)) continue;
                    CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                    Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                    if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
                    float fov = horizontalFov(cc);
                    if (fov >= widestFov * .99f) { wideCameraId = id; wideSupported = true; break; }
                }
            }

            if (cameraId == null) cameraId = mainCameraId;
            chars = cm.getCameraCharacteristics(cameraId);
            sensor = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            RangeZ rr = range(chars);
            minHardware = rr.min;
            maxHardware = rr.max;
            if (cameraId.equals(wideCameraId) && zoom < 1f) zoom = .5f;
            else if (!cameraId.equals(wideCameraId) && zoom < 1f) zoom = 1f;
            prepareReader(chars);
            flashAvailable = Boolean.TRUE.equals(chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE));
            lowLightBoostSupported = supportsLowLightBoost(chars);
            status = "CÂMERA PRONTA • " + (wideSupported ? "0,5× DISPONÍVEL" : "0,5× INDISPONÍVEL");

            if (getContext().checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
            cm.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice d) { device = d; createSession(); }
                @Override public void onDisconnected(CameraDevice d) { d.close(); device = null; }
                @Override public void onError(CameraDevice d, int e) { d.close(); device = null; status = "ERRO NA CÂMERA"; postInvalidate(); }
            }, cameraHandler);
            invalidate();
        } catch (Exception e) {
            status = "CÂMERA INDISPONÍVEL";
            postInvalidate();
        }
    }

    private boolean supportsLowLightBoost(CameraCharacteristics cc) {
        if (Build.VERSION.SDK_INT < 35) return false;
        int[] modes = cc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES);
        if (modes == null) return false;
        for (int m : modes) if (m == CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY) return true;
        return false;
    }

    private boolean hasCapability(int[] caps, int wanted) {
        if (caps == null) return false;
        for (int c : caps) if (c == wanted) return true;
        return false;
    }

    private void prepareReader(CameraCharacteristics cc) {
        if (reader != null) { reader.close(); reader = null; }
        StreamConfigurationMap map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        jpegSize = new Size(1920, 1080);
        if (map != null) {
            Size[] sizes = map.getOutputSizes(android.graphics.ImageFormat.JPEG);
            if (sizes != null && sizes.length > 0) {
                Size best = sizes[0];
                for (Size s : sizes) if ((long)s.getWidth() * s.getHeight() > (long)best.getWidth() * best.getHeight()) best = s;
                jpegSize = best;
            }
        }
        reader = ImageReader.newInstance(jpegSize.getWidth(), jpegSize.getHeight(), android.graphics.ImageFormat.JPEG, 4);
        reader.setOnImageAvailableListener(rdr -> {
            Image im = null;
            try {
                im = rdr.acquireLatestImage();
                if (im != null && busy) {
                    ByteBuffer buf = im.getPlanes()[0].getBuffer();
                    byte[] data = new byte[buf.remaining()];
                    buf.get(data);
                    BitmapFactory.Options opt = new BitmapFactory.Options();
                    opt.inPreferredConfig = Bitmap.Config.ARGB_8888;
                    Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length, opt);
                    if (bm != null) finishPhoto(bm);
                }
            } catch (Exception ignored) {
            } finally {
                if (im != null) im.close();
            }
        }, workHandler);
    }

    private float horizontalFov(CameraCharacteristics cc) {
        try {
            float[] fs = cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            SizeF physical = cc.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            if (fs != null && fs.length > 0 && physical != null && fs[0] > 0) {
                return (float)(2d * Math.atan(physical.getWidth() / (2d * fs[0])));
            }
        } catch (Exception ignored) { }
        return 0f;
    }

    private static class RangeZ {
        final float min, max;
        RangeZ(float min, float max) { this.min = min; this.max = max; }
    }

    private RangeZ range(CameraCharacteristics cc) {
        if (Build.VERSION.SDK_INT >= 30) {
            Range<Float> r = cc.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
            if (r != null) return new RangeZ(r.getLower(), r.getUpper());
        }
        Float z = cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
        return new RangeZ(1f, Math.max(1f, z == null ? 1f : z));
    }

    private void createSession() {
        try {
            SurfaceTexture st = preview.getSurfaceTexture();
            if (st == null || device == null || reader == null) return;
            Size previewSize = choosePreviewSize(chars);
            st.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            Surface ps = new Surface(st);
            device.createCaptureSession(Arrays.asList(ps, reader.getSurface()), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) {
                    session = s;
                    applyPreview();
                }
                @Override public void onConfigureFailed(CameraCaptureSession s) {
                    status = "FALHA AO CONFIGURAR CÂMERA";
                    postInvalidate();
                }
            }, cameraHandler);
        } catch (Exception e) {
            status = "FALHA NA SESSÃO";
            postInvalidate();
        }
    }

    private Size choosePreviewSize(CameraCharacteristics cc) {
        StreamConfigurationMap map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (map == null) return new Size(1920, 1080);
        Size[] sizes = map.getOutputSizes(SurfaceTexture.class);
        if (sizes == null || sizes.length == 0) return new Size(1920, 1080);
        float targetRatio = getHeight() == 0 ? 16f / 9f : (float)getWidth() / (float)getHeight();
        Size best = sizes[0];
        double bestScore = Double.MAX_VALUE;
        for (Size s : sizes) {
            float ratio = (float)s.getWidth() / (float)s.getHeight();
            double ratioScore = Math.abs(ratio - targetRatio);
            long area = (long)s.getWidth() * s.getHeight();
            double areaPenalty = area > 1920L * 1080L ? 0.15 : 0;
            double score = ratioScore * 10 + areaPenalty;
            if (score < bestScore) { bestScore = score; best = s; }
        }
        return best;
    }

    private CaptureRequest.Builder request(int template) throws Exception {
        CaptureRequest.Builder b = device.createCaptureRequest(template);
        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);

        int ae = CaptureRequest.CONTROL_AE_MODE_ON;
        if (mode == Mode.NIGHT && lowLightBoostSupported && template == CameraDevice.TEMPLATE_PREVIEW) {
            ae = CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY;
        } else if (template == CameraDevice.TEMPLATE_STILL_CAPTURE && flashAvailable) {
            if (flashMode == 1) ae = CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH;
            else if (flashMode == 2) ae = CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH;
        }
        b.set(CaptureRequest.CONTROL_AE_MODE, ae);
        if (flashAvailable) {
            if (template == CameraDevice.TEMPLATE_PREVIEW && flashMode == 2) b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH);
            else b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
        }

        // Critical: digital zoom above the hardware ratio ALWAYS uses a new crop request.
        // This is applied to preview AND still capture, so the number cannot advance without a real crop.
        if (zoom < 1f && cameraId != null && cameraId.equals(wideCameraId)) {
            // Logical multi-camera systems may expose the ultrawide as a real sub-1x ratio.
            // Separate physical ultrawide cameras normally start at 1x and therefore need no crop.
            if (Build.VERSION.SDK_INT >= 30 && minHardware < 1f && zoom >= minHardware && zoom <= maxHardware) {
                b.set(CaptureRequest.CONTROL_ZOOM_RATIO, Math.max(minHardware, Math.min(maxHardware, zoom)));
            } else {
                b.set(CaptureRequest.SCALER_CROP_REGION, sensor);
            }
        } else if (Build.VERSION.SDK_INT >= 30 && zoom >= minHardware && zoom <= maxHardware) {
            b.set(CaptureRequest.CONTROL_ZOOM_RATIO, Math.max(minHardware, Math.min(maxHardware, zoom)));
        } else {
            b.set(CaptureRequest.SCALER_CROP_REGION, cropForZoom(Math.max(1f, zoom)));
        }

        if (mode == Mode.NIGHT && template == CameraDevice.TEMPLATE_STILL_CAPTURE && !lowLightBoostSupported) {
            Range<Integer> ar = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            if (ar != null) {
                int ev = Math.min(ar.getUpper(), Math.max(ar.getLower(), 2));
                b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev);
            }
        }
        return b;
    }

    private Rect cropForZoom(float z) {
        if (sensor == null) return null;
        z = Math.max(1f, Math.min(100f, z));
        int cw = Math.max(2, Math.round(sensor.width() / z));
        int ch = Math.max(2, Math.round(sensor.height() / z));
        int left = sensor.centerX() - cw / 2;
        int top = sensor.centerY() - ch / 2;
        Rect r = new Rect(left, top, left + cw, top + ch);
        r.intersect(sensor);
        return r;
    }

    private void applyPreview() {
        try {
            if (session == null || preview.getSurfaceTexture() == null) return;
            CaptureRequest.Builder b = request(CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(new Surface(preview.getSurfaceTexture()));
            session.setRepeatingRequest(b.build(), null, cameraHandler);
            transform();
            status = mode == Mode.NIGHT ? "NIGHT • PRÉ-VISUALIZAÇÃO" : "PRONTO • " + zoomString();
            invalidate();
        } catch (Exception e) {
            status = "ERRO AO APLICAR ZOOM";
            invalidate();
        }
    }

    private void transform() {
        if (preview == null || chars == null) return;
        try {
            Size ps = choosePreviewSize(chars);
            float viewRatio = getWidth() / (float)Math.max(1, getHeight());
            float bufferRatio = ps.getWidth() / (float)Math.max(1, ps.getHeight());
            Matrix m = new Matrix();
            float sx, sy;
            if (bufferRatio > viewRatio) {
                // Center-crop without stretching: crop excess horizontal buffer.
                sx = 1f;
                sy = bufferRatio / viewRatio;
            } else {
                sx = viewRatio / bufferRatio;
                sy = 1f;
            }
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            m.setScale(sx, sy, cx, cy);
            preview.setTransform(m);
        } catch (Exception ignored) { }
    }

    private void selectWide() {
        if (!wideSupported || wideCameraId == null) {
            status = "0,5× INDISPONÍVEL NESTE APARELHO";
            invalidate();
            return;
        }
        zoom = .5f;
        if (!wideCameraId.equals(cameraId)) {
            cameraId = wideCameraId;
            close();
            open();
        } else {
            status = "0,5× • ULTRAWIDE REAL";
            applyPreview();
            invalidate();
        }
    }

    private void selectMain(float z) {
        if (mainCameraId == null) {
            status = "CÂMERA PRINCIPAL INDISPONÍVEL";
            invalidate();
            return;
        }
        zoom = Math.max(1f, Math.min(100f, z));
        if (!mainCameraId.equals(cameraId)) {
            cameraId = mainCameraId;
            close();
            open();
        } else {
            status = zoom > maxHardware ? "CROP DIGITAL REAL • " + zoomString() : "HARDWARE • " + zoomString();
            applyPreview();
            invalidate();
        }
    }

    private void capture() {
        if (busy || session == null || device == null || reader == null) return;
        busy = true;
        frames.clear();
        finalizeScheduled = false;
        if (mode == Mode.NIGHT) targetFrames = 4;
        else if (mode == Mode.MAX || mode == Mode.ULTRA) targetFrames = 3;
        else targetFrames = 1;
        completedCaptures = 0;
        status = mode == Mode.NIGHT ? "NIGHT • CAPTURANDO 4 FRAMES" : "CAPTURANDO • " + zoomString();
        issueCapture();
        invalidate();
    }

    private void issueCapture() {
        if (!busy) return;
        try {
            CaptureRequest.Builder b = request(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(reader.getSurface());
            b.set(CaptureRequest.JPEG_ORIENTATION, rotation());
            session.capture(b.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest r, TotalCaptureResult result) {
                    completedCaptures++;
                    if (completedCaptures < targetFrames) workHandler.postDelayed(() -> issueCapture(), mode == Mode.NIGHT ? 180 : 90);
                    else workHandler.postDelayed(() -> { if (busy) status = "PROCESSANDO…"; invalidate(); }, 100);
                }
            }, cameraHandler);
        } catch (Exception e) {
            busy = false;
            status = "FALHA AO FOTOGRAFAR";
            invalidate();
        }
    }

    private void finishPhoto(Bitmap bm) {
        if (!busy || bm == null) {
            if (bm != null) bm.recycle();
            return;
        }
        frames.add(bm);
        if (completedCaptures >= targetFrames && frames.size() >= targetFrames) finalizeCapture();
        else if (completedCaptures >= targetFrames && !finalizeScheduled) {
            finalizeScheduled = true;
            workHandler.postDelayed(this::finalizeCapture, 1200);
        }
    }

    private void finalizeCapture() {
        if (!busy) return;
        Bitmap best = null;
        synchronized (frames) {
            if (!frames.isEmpty()) {
                best = frames.get(0);
                for (Bitmap b : frames) if (b != null && sharpnessScore(b) > sharpnessScore(best)) best = b;
            }
        }
        if (best != null) {
            Bitmap output = best;
            if (mode == Mode.NIGHT) output = liftNight(best);
            save(output, mode == Mode.NIGHT ? "NIGHT" : MODES[mode.ordinal()]);
            if (output != best) output.recycle();
        }
        synchronized (frames) {
            for (Bitmap b : frames) if (b != null) b.recycle();
            frames.clear();
        }
        busy = false;
        finalizeScheduled = false;
        status = best == null ? "NÃO FOI POSSÍVEL FOTOGRAFAR" : "FOTO SALVA • " + zoomString();
        invalidate();
        postDelayed(() -> { if (!busy) { status = MODES[mode.ordinal()] + " • PRONTO"; invalidate(); } }, 1800);
    }

    private double sharpnessScore(Bitmap b) {
        int w = Math.min(180, b.getWidth()), h = Math.min(140, b.getHeight());
        Bitmap s = Bitmap.createScaledBitmap(b, w, h, true);
        int[] px = new int[w * h];
        s.getPixels(px, 0, w, 0, 0, w, h);
        double sum = 0, sum2 = 0; int n = 0;
        for (int y = 1; y < h - 1; y += 2) for (int x = 1; x < w - 1; x += 2) {
            int i = y * w + x;
            int center = Color.red(px[i]) + Color.green(px[i]) + Color.blue(px[i]);
            int l = Color.red(px[i - 1]) + Color.green(px[i - 1]) + Color.blue(px[i - 1]);
            int r = Color.red(px[i + 1]) + Color.green(px[i + 1]) + Color.blue(px[i + 1]);
            int u = Color.red(px[i - w]) + Color.green(px[i - w]) + Color.blue(px[i - w]);
            int d = Color.red(px[i + w]) + Color.green(px[i + w]) + Color.blue(px[i + w]);
            double q = center * 4d - l - r - u - d;
            sum += q; sum2 += q * q; n++;
        }
        if (s != b) s.recycle();
        double mean = sum / Math.max(1, n);
        return sum2 / Math.max(1, n) - mean * mean;
    }

    private Bitmap liftNight(Bitmap src) {
        Bitmap out = src.copy(Bitmap.Config.ARGB_8888, true);
        if (out == null) return src;
        int w = out.getWidth(), h = out.getHeight();
        int[] px = new int[w * h];
        out.getPixels(px, 0, w, 0, 0, w, h);
        for (int i = 0; i < px.length; i++) {
            int r = nightTone(Color.red(px[i]));
            int g = nightTone(Color.green(px[i]));
            int b = nightTone(Color.blue(px[i]));
            px[i] = Color.rgb(r, g, b);
        }
        out.setPixels(px, 0, w, 0, 0, w, h);
        return out;
    }

    private int nightTone(int v) {
        double n = v / 255d;
        double lifted = Math.pow(Math.min(1d, n * 1.24d), .80d);
        return Math.max(0, Math.min(255, (int)(lifted * 255d)));
    }

    private int rotation() {
        int r = getContext().getDisplay().getRotation();
        return r == Surface.ROTATION_0 ? 90 : r == Surface.ROTATION_90 ? 0 : r == Surface.ROTATION_180 ? 270 : 180;
    }

    private void save(Bitmap b, String tag) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "UltraZoom_" + tag + "_" + System.currentTimeMillis() + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/UltraZoom");
            Uri u = getContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u != null) {
                OutputStream o = getContext().getContentResolver().openOutputStream(u);
                if (o != null) {
                    b.compress(Bitmap.CompressFormat.JPEG, 97, o);
                    o.close();
                }
            }
        } catch (Exception ignored) { }
    }

    private void focus(float x, float y) {
        if (session == null || device == null) return;
        focusX = x; focusY = y; focusUntil = System.currentTimeMillis() + 1200;
        invalidate();
    }

    private void captureMiniIfNeeded() {
        long now = System.currentTimeMillis();
        if (miniCapturePending || now - lastMiniCapture < 350 || !preview.isAvailable()) return;
        miniCapturePending = true;
        lastMiniCapture = now;
        workHandler.post(() -> {
            try {
                Bitmap b = preview.getBitmap(144, 96);
                if (b != null) {
                    Bitmap old = miniBitmap;
                    miniBitmap = b;
                    if (old != null && !old.isRecycled()) old.recycle();
                    postInvalidate();
                }
            } catch (Exception ignored) {
            } finally {
                miniCapturePending = false;
            }
        });
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent e) { return true; }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int w = getWidth(), h = getHeight();
        float x = e.getX(), y = e.getY();
        float s = Math.max(0.85f, Math.min(1.35f, w / 1080f));

        if (e.getPointerCount() == 2) {
            if (e.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
                pinchDistance = distance(e); pinchStart = zoom;
            } else if (e.getActionMasked() == MotionEvent.ACTION_MOVE && pinchDistance > 0) {
                float nz = Math.max(.5f, Math.min(100f, pinchStart * distance(e) / pinchDistance));
                if (nz < 1f) selectWide(); else selectMain(nz);
            } else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                pinchDistance = 0;
            }
            return true;
        }
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;

        if (showInfo) { showInfo = false; invalidate(); return true; }
        if (showModeMenu) {
            float top = 174 * s;
            if (y >= top && y <= top + MODES.length * 79 * s) {
                int i = (int)((y - top) / (79 * s));
                if (i >= 0 && i < MODES.length) {
                    mode = Mode.values()[i];
                    showModeMenu = false;
                    status = MODES[i] + " • PRONTO";
                    applyPreview();
                    invalidate();
                }
            } else { showModeMenu = false; invalidate(); }
            return true;
        }

        if (y > h - 205 * s && x < w * .28f) {
            if (!flashAvailable) status = "FLASH INDISPONÍVEL";
            else {
                flashMode = (flashMode + 1) % 3;
                applyPreview();
                status = flashLabel();
            }
            invalidate();
            return true;
        }
        if (y > h - 220 * s && x > w * .72f) { showModeMenu = true; invalidate(); return true; }
        if (y > h - 225 * s && Math.abs(x - w / 2f) < 125 * s) { capture(); return true; }

        if (y >= 160 * s && y <= 240 * s) {
            float gap = 8 * s, bw = (w - 56 * s - 4 * gap) / 5f;
            int i = (int)((x - 28 * s) / (bw + gap));
            if (i == 0) selectWide();
            else if (i == 1) selectMain(1f);
            else if (i == 2) selectMain(2f);
            else if (i == 3) selectMain(6f);
            else if (i == 4) selectMain(10f);
            return true;
        }
        if (y > h - 355 * s && y < h - 190 * s) {
            float ratio = Math.max(0, Math.min(1, (x - 28 * s) / (float)(w - 56 * s)));
            float nz = (float)Math.exp(Math.log(.5) + ratio * (Math.log(100) - Math.log(.5)));
            if (nz < 1f) selectWide(); else selectMain(nz);
            return true;
        }
        if ((y < 125 * s && x > w - 205 * s) || (y > h - 80 * s && x > w - 105 * s)) {
            showInfo = true; invalidate(); return true;
        }
        focus(x, y);
        return true;
    }

    private float distance(MotionEvent e) {
        float dx = e.getX(1) - e.getX(0), dy = e.getY(1) - e.getY(0);
        return (float)Math.sqrt(dx * dx + dy * dy);
    }

    void start() {
        startThreads();
        if (preview.isAvailable() && device == null) open();
    }

    void stop() { close(); }

    private void close() {
        try { if (session != null) { session.close(); session = null; } } catch (Exception ignored) { }
        try { if (device != null) { device.close(); device = null; } } catch (Exception ignored) { }
    }

    void shutdown() {
        close();
        try { if (reader != null) reader.close(); } catch (Exception ignored) { }
        if (miniBitmap != null && !miniBitmap.isRecycled()) miniBitmap.recycle();
        try { if (cameraThread != null) cameraThread.quitSafely(); } catch (Exception ignored) { }
        try { if (workThread != null) workThread.quitSafely(); } catch (Exception ignored) { }
    }
}
