# Build no GitHub

1. Envie **somente** `UltraZoom-v10.0.0-build.zip` para a raiz do repositório.
2. O arquivo `.github/workflows/build-apk.yml` já está dentro do ZIP.
3. O workflow extrai com sobrescrita (`unzip -o`), portanto não deve aparecer a pergunta `replace README.md?`.
4. Abra **Actions → Build UltraZoom APK**.
5. O resultado esperado é `Success` e o artefato `UltraZoom-debug-apk`.

O ZIP foi montado com o projeto na raiz (não dentro de uma segunda pasta UltraZoom), contém `settings.gradle`, `build.gradle`, `app/build.gradle`, Manifest, `MainActivity.java` e o workflow.
