# UltraZoom 12.2.0 — Native Frame Engine

Build identifier: `UZ-122-NATIVE-FRAME-ENGINE`.

Esta versão encerra a fase de testes de geometria e transforma o diagnóstico anterior em uma arquitetura de preview permanente. O objetivo é que 1× represente o quadro nativo 4:3 do sensor, sem esticar a imagem e sem usar um preview 16:9 que force um corte horizontal agressivo.

## O que mudou
- Preview permanente em stream 4:3, priorizando a proporção do sensor.
- Frame visual 3:4 no aparelho em modo retrato, centralizado e com escala uniforme.
- Removido o modo experimental `TESTAR SENSOR 4:3`; o frame nativo agora é o comportamento padrão.
- A transformação do TextureView deixou de usar o preenchimento duplo que podia distorcer/cortar o enquadramento.
- Diagnóstico passa a separar três valores: UI (pedido), CAM (resultado Camera2) e GEO (zoom geométrico derivado do crop).
- O minimapa passa a desenhar o campo de visão a partir da geometria do sensor/crop, e não da proporção da tela.
- Quando o aparelho reporta um `SCALER_CROP_REGION` cheio mesmo usando `CONTROL_ZOOM_RATIO`, o minimapa usa o crop geométrico solicitado como fallback.
- Mantido o bloqueio de AE durante o gesto de zoom.
- Mantido o processamento multi-frame e captura JPEG em alta resolução.
- Zoom acima do limite de hardware continua usando crop/upscale digital adicional, sem fingir que é zoom óptico.
- Mantida a investigação de multicâmera/physical IDs, sem fabricar 0,5× quando a Camera2 pública não fornece a lente.

## Por que esta é uma mudança estrutural
O teste anterior mostrou que o sensor e o stream 4:3 preservam a distância aparente correta, enquanto o preview 16:9 podia sacrificar parte do campo horizontal para preencher a tela alta. Agora a geometria 4:3 deixa de ser um teste e vira a referência do motor.

## Limitações conhecidas
- A Camera2 pública do aparelho de teste continua não expondo uma câmera traseira ultrawide independente para 0,5×.
- O valor `CAM` pode ser inconsistente em alguns firmwares; por isso o app não usa esse número sozinho para desenhar o campo de visão.
- Zoom acima do limite físico/hardware é digital.

## Build
O workflow seleciona exatamente um ZIP contendo `UZ-122-NATIVE-FRAME-ENGINE`, valida os arquivos críticos e executa `clean assembleDebug` com Java 17, Gradle 9.4.1 e Android 36.
