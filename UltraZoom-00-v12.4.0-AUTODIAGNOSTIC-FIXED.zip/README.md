# UltraZoom 12.4.0 — Auto Diagnostic

Build identifier: `UZ-124-AUTODIAGNOSTIC`.

This version separates zoom diagnosis into three independent layers:

- **A — Declarado:** Camera2 `CaptureResult`, zoom ratio and crop geometry.
- **B — Observado:** comparison of preview frames captured at consecutive zoom levels when sufficient overlap/features exist.
- **C — Inferido:** detail evidence from JPEGs the user voluntarily captures; no hidden still capture is performed.

`UNKNOWN` means evidence is not available. It is not a failure. `FAIL` is contradictory evidence and is absorbing: any FAIL revokes the corresponding confirmation and requires recheck.

The diagnostic collector is opportunistic: it does not run in background, does not run below 20% battery, limits sampling/storage, and never modifies the photo saved by the user.

No manual calibration and no software photo zoom beyond the camera-reported range are included.

## Confidence rule

- Any `FAIL` → `REVOKED`.
- Otherwise, missing evidence (`UNKNOWN`) is not failure.
- `CONFIRMED + CONFIRMED + UNKNOWN` → `PARTIAL`.
- All three confirmed → `CONFIRMED`.

## Build

The repository workflow requires exactly `UltraZoom-00-v12.4.0-AUTODIAGNOSTIC.zip`, runs unit tests before the Android build, then performs static regression checks and `assembleDebug`.
