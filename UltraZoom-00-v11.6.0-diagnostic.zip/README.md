# UltraZoom 11.6.0 — Diagnostic Build

Build identifier: `UZ-116-DIAGNOSTIC`.

This version is intentionally diagnostic-first. It does not claim to solve rotation or 0.5×. It exposes the real Camera2 capabilities of the phone so the next quality-zoom implementation is based on measurements.

## What this build measures
- Device/model/Android SDK.
- Public rear camera IDs and selection criterion.
- Sensor pixel/active arrays, physical sensor size, focal length and calculated horizontal FOV.
- `CONTROL_ZOOM_RATIO_RANGE` and `SCALER_AVAILABLE_MAX_DIGITAL_ZOOM`.
- Logical multi-camera capability and `getPhysicalCameraIds()`.
- JPEG maximum and selected capture size. This diagnostic build selects the largest JPEG size exposed by Camera2.
- Preview output selection and orientation/display relationship.
- OIS/EIS, AF/AE/AWB modes and metering-region counts.
- Camera2 capabilities, including RAW/reprocessing/burst/logical multi-camera when exposed.

## Important
The 0.5× button remains disabled unless Camera2 exposes evidence of a wider camera. The diagnostic panel is the source of truth for deciding whether that feature is possible through this API on the device.

## Build
The GitHub workflow selects exactly one archive containing `UZ-116-DIAGNOSTIC`, prepares an isolated project, runs structural checks, then executes `clean assembleDebug` with Java 17, Gradle 9.4.1 and Android 36.
