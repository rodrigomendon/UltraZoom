package com.rodrigo.ultrazoom;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Size;
import android.util.SizeF;
import android.view.MotionEvent;
import android.view.Surface;
import android.graphics.SurfaceTexture;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private static final int REQ = 44;
    private UltraCameraView camera;

    @Override public void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        immersive();
        camera = new UltraCameraView(this);
        setContentView(camera);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ);
        } else {
            camera.start();
        }
    }

    private void immersive() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override protected void onResume() {
        super.onResume();
        immersive();
        if (camera != null && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) camera.start();
    }

    @Override protected void onPause() {
        if (camera != null) camera.stop();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (camera != null) camera.shutdown();
        super.onDestroy();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) camera.start();
        else Toast.makeText(this, "A câmera é necessária para o UltraZoom.", Toast.LENGTH_LONG).show();
    }
}

class UltraCameraView extends ViewGroup {
    private enum Mode { AUTO, PRO, ULTRA, MAX, NIGHT }
    private static final String BUILD_ID = "UZ-116-DIAGNOSTIC";
    private static final String LEGACY_BUILD_ID = "UZ-115-TRIPLE-A";
    // Diagnostic build: hardware/preview facts are collected without changing the core capture pipeline.
    private static final int WHITE_92 = 0xEBFFFFFF;
    private static final int WHITE_70 = 0xB3FFFFFF;
    private static final int PANEL = 0xC90A0A0C;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextureView preview;
    private CameraDevice device;
    private CameraCaptureSession session;
    private CameraCharacteristics chars;
    private String cameraId;
    private String mainCameraId;
    private String wideCameraId;
    private String physicalWideId;
    private String activePhysicalId;
    private CameraCharacteristics deviceChars;
    private Size jpegSize;
    private Size previewSize;
    private Rect sensor;
    private float maxHardware = 1f;
    private float minHardware = 1f;
    private float zoom = 1f;
    private boolean flashAvailable;
    private boolean lowLightBoostSupported;
    private boolean wideSupported;
    private int backCameraCount;
    private String cameraDiagnostics = "—";
    private boolean showInfo;
    private boolean showModeMenu;
    private int flashMode = 0; // off / auto / on
    private ImageReader reader;
    private ImageReader miniReader;
    private HandlerThread cameraThread;
    private HandlerThread workThread;
    private Handler cameraHandler;
    private Handler workHandler;
    private Executor cameraExecutor;
    private Mode mode = Mode.AUTO;
    private String status = "INICIANDO CÂMERA…";
    private float focusX = -1f, focusY = -1f;
    private long focusUntil;
    private float pinchStart = 1f, pinchDistance;
    private int targetFrames;
    private volatile int completedCaptures;
    private volatile boolean busy;
    private boolean finalizeScheduled;
    private final List<Bitmap> frames = Collections.synchronizedList(new ArrayList<Bitmap>());
    private Bitmap miniBitmap;
    private long lastMiniCapture;
    private boolean miniCapturePending;
    private boolean miniInSession;
    private Rect focusRegion;
    private final UiLayout ui = new UiLayout();
    private boolean layoutValid = true;
    private String layoutDiagnostic = "OK";
    private String cameraSelectionReason = "—";
    private String physicalDiagnostic = "—";
    private String publicCameraDiagnostic = "—";
    private String detailedDiagnostics = "—";
    private String outputDiagnostics = "—";
    private String orientationDiagnostics = "—";
    private String stabilizationDiagnostics = "—";
    private String focusDiagnostics = "—";
    private String capabilitiesDiagnostics = "—";
    private String physicalIdsDiagnostics = "—";
    private String zoomDiagnostics = "—";
    private String previewSelectionDiagnostic = "—";
    private Size largestJpegSize;
    private long transitionUntil;
    private float transitionAlpha;
    
    private static final String[] MODES = {"AUTO", "PRO", "ULTRA", "MAX", "NIGHT"};
    private static final String[] DESCS = {
            "Equilíbrio automático", "Controle manual e estabilidade", "Processamento multi-frame", "Máxima ampliação disponível", "Visão noturna • baixa luz + múltiplos frames"
    };

    private static class UiLayout {
        final RectF mini = new RectF();
        final RectF zoomArea = new RectF();
        final RectF flash = new RectF();
        final RectF shutter = new RectF();
        final RectF mode = new RectF();
        final RectF info = new RectF();
        final RectF[] lens = new RectF[]{new RectF(), new RectF(), new RectF(), new RectF(), new RectF()};
        float scale = 1f;
        float lensGap = 0f;
        float lensWidth = 0f;

        void compute(int w, int h) {
            scale = Math.max(0.88f, Math.min(1.24f, w / 900f));
            mini.set(w - 174 * scale, 108 * scale, w - 28 * scale, 188 * scale);
            float y = 202 * scale;
            lensGap = 8 * scale;
            lensWidth = (w - 56 * scale - 4 * lensGap) / 5f;
            for (int i = 0; i < lens.length; i++) {
                float x = 28 * scale + i * (lensWidth + lensGap);
                lens[i].set(x, y, x + lensWidth, y + 58 * scale);
            }
            float zy = h - 358 * scale;
            zoomArea.set(28 * scale, zy - 8 * scale, w - 28 * scale, zy + 128 * scale);
            float cy = h - 118 * scale;
            flash.set(28 * scale, cy - 50 * scale, 136 * scale, cy + 50 * scale);
            shutter.set(w / 2f - 62 * scale, cy - 62 * scale, w / 2f + 62 * scale, cy + 62 * scale);
            mode.set(w - 136 * scale, cy - 50 * scale, w - 28 * scale, cy + 50 * scale);
            info.set(w - 84 * scale, h - 62 * scale, w - 18 * scale, h - 4 * scale);
        }
    }

    UltraCameraView(Context c) {
        super(c);
        setWillNotDraw(false);
        setBackgroundColor(Color.BLACK);
        text.setTypeface(Typeface.create("sans", Typeface.BOLD));
        startThreads();
        preview = new TextureView(c);
        preview.setOpaque(true);
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) { open(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) { transform(); }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { close(); return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture s) { captureMiniIfNeeded(); }
        });
        addView(preview);
    }

    private void startThreads() {
        if (cameraThread == null) {
            cameraThread = new HandlerThread("UZ-Camera");
            cameraThread.start();
            cameraHandler = new Handler(cameraThread.getLooper());
            cameraExecutor = command -> cameraHandler.post(command);
        }
        if (workThread == null) {
            workThread = new HandlerThread("UZ-Work");
            workThread.start();
            workHandler = new Handler(workThread.getLooper());
        }
    }

    @Override protected void onMeasure(int ws, int hs) {
        int w = Math.max(1, MeasureSpec.getSize(ws));
        int h = Math.max(1, MeasureSpec.getSize(hs));
        setMeasuredDimension(w, h);
        preview.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
    }

    @Override protected void onLayout(boolean changed, int l, int top, int r, int b) {
        preview.layout(0, 0, getWidth(), getHeight());
        ui.compute(getWidth(), getHeight());
        validateLayout();
        transform();
    }

    @Override protected void dispatchDraw(Canvas c) {
        super.dispatchDraw(c);
        drawHud(c);
    }

    private void rounded(Canvas c, float l, float top, float r, float b, float radius, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawRoundRect(l, top, r, b, radius, radius, p);
    }

    private void strokeRound(Canvas c, float l, float top, float r, float b, float radius, float stroke, int color) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(stroke);
        p.setColor(color);
        c.drawRoundRect(l, top, r, b, radius, radius, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        text.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        text.setTextSize(size);
        text.setColor(color);
        c.drawText(s, x, y, text);
    }

    private void center(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        text.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        text.setTextSize(size);
        text.setColor(color);
        c.drawText(s, x - text.measureText(s) / 2f, y, text);
    }

    private void drawHud(Canvas c) {
        int w = getWidth(), h = getHeight();
        ui.compute(w, h);
        float scale = ui.scale;

        // Cinematic glass panels. Controls stay visible after permission is granted.
        rounded(c, 0, 0, w, 150 * scale, 0, 0xB5000000);
        rounded(c, 0, h - 360 * scale, w, h, 0, 0xD9070709);

        txt(c, "ULTRAZOOM", 28 * scale, 44 * scale, 30 * scale, Color.WHITE, true);
        txt(c, "CÂMERA COMPUTACIONAL", 30 * scale, 70 * scale, 15 * scale, WHITE_70, true);
        txt(c, "● " + status, 30 * scale, 96 * scale, 16 * scale, 0xD9FFFFFF, false);

        // The actual applied value is intentionally dominant.
        center(c, zoomString(), w - 105 * scale, 54 * scale, 50 * scale, Color.WHITE, true);
        center(c, MODES[mode.ordinal()], w - 105 * scale, 80 * scale, 16 * scale, WHITE_92, true);
        center(c, zoomDomain(), w - 105 * scale, 102 * scale, 13 * scale, WHITE_70, false);

        drawMiniMap(c, w, scale);
        drawLensPills(c, w, scale);
        drawZoomBar(c, w, h, scale);
        drawBottom(c, w, h, scale);

        if (transitionUntil > System.currentTimeMillis()) {
            float left = (transitionUntil - System.currentTimeMillis()) / 180f;
            int alpha = Math.max(0, Math.min(190, Math.round(transitionAlpha * left * 255f)));
            p.setColor((alpha << 24));
            c.drawRect(0, 0, w, h, p);
            postInvalidateDelayed(16);
        }

        if (focusUntil > System.currentTimeMillis()) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3 * scale);
            p.setColor(Color.WHITE);
            c.drawRoundRect(focusX - 34 * scale, focusY - 34 * scale, focusX + 34 * scale, focusY + 34 * scale, 8, 8, p);
            p.setStyle(Paint.Style.FILL);
            postInvalidateDelayed(80);
        }
        if (showModeMenu) drawModeSheet(c, scale);
        if (showInfo) drawInfo(c, scale);
    }

    private String zoomString() {
        if (zoom < 10f) return String.format(Locale.US, "%.1f×", zoom);
        if (zoom < 100f) return String.format(Locale.US, "%.0f×", zoom);
        return "100×";
    }

    private String zoomDomain() {
        if (zoom < 0.99f) return "ULTRAWIDE REAL";
        if (zoom <= maxHardware + 0.01f) return "ZOOM HARDWARE";
        return String.format(Locale.US, "HARDWARE %.1f× + DIGITAL", maxHardware);
    }

    private void drawMiniMap(Canvas c, int w, float s) {
        RectF box = ui.mini;
        rounded(c, box.left, box.top, box.right, box.bottom, 14 * s, 0xD0000000);
        strokeRound(c, box.left, box.top, box.right, box.bottom, 14 * s, 1.5f * s, 0xCCFFFFFF);
        RectF image = new RectF(box.left + 4 * s, box.top + 4 * s, box.right - 4 * s, box.bottom - 4 * s);
        if (miniBitmap != null && !miniBitmap.isRecycled()) {
            Rect src = new Rect(0, 0, miniBitmap.getWidth(), miniBitmap.getHeight());
            c.drawBitmap(miniBitmap, src, image, p);
        }
        RectF view = zoomViewRect(image.left, image.top, image.right, image.bottom);
        strokeRound(c, view.left, view.top, view.right, view.bottom, 3 * s, 2 * s, Color.WHITE);
        txt(c, miniInSession ? "VISÃO GERAL" : "MAPA OFF", box.left + 9 * s, box.bottom + 17 * s, 10 * s, WHITE_92, true);
    }

    private RectF zoomViewRect(float l, float t, float r, float b) {
        float z = Math.max(0.5f, Math.min(100f, zoom));
        float frameFraction = z < 1f ? 1f : 1f / z;
        float rw = (r - l) * frameFraction;
        float rh = (b - t) * frameFraction;
        float cx = (l + r) / 2f;
        float cy = (t + b) / 2f;
        return new RectF(cx - rw / 2f, cy - rh / 2f, cx + rw / 2f, cy + rh / 2f);
    }

    private void drawLensPills(Canvas c, int w, float s) {
        String[] lens = {"0,5×", "1×", "2×", "6×", "10×"};
        for (int i = 0; i < lens.length; i++) {
            RectF r = ui.lens[i];
            boolean active = (i == 0 && zoom < 0.75f) || (i == 1 && zoom >= 0.75f && zoom < 1.5f) ||
                    (i == 2 && zoom >= 1.5f && zoom < 4f) || (i == 3 && zoom >= 4f && zoom < 8f) || (i == 4 && zoom >= 8f && zoom < 14f);
            boolean enabled = i != 0 || wideSupported;
            int bg = active ? 0xFFF7F7F7 : 0xB8141417;
            if (!enabled) bg = 0x66141417;
            rounded(c, r.left, r.top, r.right, r.bottom, 30 * s, bg);
            center(c, lens[i], r.centerX(), r.top + 38 * s, 21 * s, active ? Color.BLACK : (enabled ? Color.WHITE : 0x88FFFFFF), true);
        }
        if (!wideSupported) {
            RectF r = new RectF(28 * s, ui.lens[0].bottom + 8 * s, Math.min(w - 28 * s, 330 * s), ui.lens[0].bottom + 40 * s);
            rounded(c, r.left, r.top, r.right, r.bottom, 16 * s, 0xB0000000);
            txt(c, "0,5× não disponível neste aparelho", r.left + 13 * s, r.top + 22 * s, 12 * s, 0xDDFFFFFF, true);
        }
    }

    private void drawZoomBar(Canvas c, int w, int h, float s) {
        float y = h - 354 * s;
        txt(c, "ZOOM", 28 * s, y, 18 * s, Color.WHITE, true);
        txt(c, zoomString() + " APLICADO", w - 210 * s, y, 16 * s, WHITE_92, true);
        String[] vals = {"0,5", "1", "2", "4", "6", "10", "20", "50", "100"};
        float step = (w - 56 * s) / 8f;
        for (int i = 0; i < vals.length; i++) {
            float v = Float.parseFloat(vals[i].replace(',', '.'));
            boolean active = Math.abs(zoom - v) < (v < 2 ? .08f : .5f);
            center(c, vals[i] + "×", 28 * s + i * step, y + 32 * s, (active ? 17 : 15) * s, active ? Color.WHITE : WHITE_70, active);
        }
        p.setColor(0xCCFFFFFF);
        c.drawRoundRect(28 * s, y + 55 * s, w - 28 * s, y + 62 * s, 4 * s, 4 * s, p);
        double lo = Math.log(.5), hi = Math.log(100);
        double q = (Math.log(Math.max(.5, Math.min(100, zoom))) - lo) / (hi - lo);
        p.setColor(Color.WHITE);
        c.drawCircle(28 * s + (float)q * (w - 56 * s), y + 58 * s, 11 * s, p);
        txt(c, "0,5×", 28 * s, y + 92 * s, 13 * s, WHITE_70, false);
        txt(c, "100×", w - 70 * s, y + 92 * s, 13 * s, WHITE_70, false);
        if (zoom > maxHardware + 0.01f) {
            String sub = String.format(Locale.US, "Hardware %.1f×  •  digital %.1f×", maxHardware, zoom / Math.max(1f, maxHardware));
            center(c, sub, w / 2f, y + 120 * s, 13 * s, 0xCCFFFFFF, false);
        }
    }

    private void drawBottom(Canvas c, int w, int h, float s) {
        float cy = ui.shutter.centerY();
        drawFlash(c, ui.flash.centerX(), cy, s);
        drawShutter(c, ui.shutter.centerX(), cy, s);
        drawMode(c, ui.mode.centerX(), cy, s);
        center(c, flashLabel(), ui.flash.centerX(), ui.flash.bottom + 18 * s, 14 * s, Color.WHITE, true);
        center(c, "FOTO", ui.shutter.centerX(), ui.shutter.bottom + 18 * s, 16 * s, Color.WHITE, true);
        center(c, MODES[mode.ordinal()], ui.mode.centerX(), ui.mode.bottom + 18 * s, 14 * s, Color.WHITE, true);
        if (mode == Mode.NIGHT) {
            rounded(c, w / 2f - 70 * s, cy - 88 * s, w / 2f + 70 * s, cy - 56 * s, 16 * s, 0xCCFFFFFF);
            center(c, "VISÃO NOTURNA", w / 2f, cy - 65 * s, 12 * s, Color.BLACK, true);
        }
        txt(c, "Toque para focar", 28 * s, h - 24 * s, 13 * s, WHITE_70, false);
        rounded(c, ui.info.left, ui.info.top, ui.info.right, ui.info.bottom, 25 * s, 0xAA000000);
        center(c, "i", ui.info.centerX(), ui.info.bottom - 14 * s, 24 * s, Color.WHITE, true);
    }

    private String flashLabel() {
        return flashMode == 0 ? "FLASH OFF" : flashMode == 1 ? "FLASH AUTO" : "FLASH ON";
    }

    private void drawFlash(Canvas c, float x, float y, float s) {
        rounded(c, x - 52 * s, y - 48 * s, x + 52 * s, y + 48 * s, 26 * s, flashMode == 0 ? 0x70000000 : 0xFFF2F2F2);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4 * s);
        p.setColor(flashMode == 0 ? Color.WHITE : Color.BLACK);
        Path q = new Path();
        q.moveTo(x + 7 * s, y - 30 * s); q.lineTo(x - 13 * s, y + 3 * s); q.lineTo(x + 2 * s, y + 3 * s);
        q.lineTo(x - 7 * s, y + 30 * s); q.lineTo(x + 19 * s, y - 7 * s); q.lineTo(x + 4 * s, y - 7 * s); q.close();
        c.drawPath(q, p); p.setStyle(Paint.Style.FILL);
    }

    private void drawShutter(Canvas c, float x, float y, float s) {
        p.setColor(Color.WHITE); c.drawCircle(x, y, 54 * s, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4 * s); p.setColor(0xFF111111); c.drawCircle(x, y, 42 * s, p); p.setStyle(Paint.Style.FILL);
        if (busy) { p.setColor(0xFF111111); c.drawRoundRect(x - 13 * s, y - 13 * s, x + 13 * s, y + 13 * s, 4 * s, 4 * s, p); }
    }

    private void drawMode(Canvas c, float x, float y, float s) {
        rounded(c, x - 52 * s, y - 48 * s, x + 52 * s, y + 48 * s, 26 * s, 0x85000000);
        center(c, "MODO", x, y - 3 * s, 12 * s, Color.WHITE, true);
        center(c, MODES[mode.ordinal()], x, y + 24 * s, 13 * s, Color.WHITE, true);
    }

    private void drawModeSheet(Canvas c, float s) {
        int w = getWidth(), h = getHeight();
        rounded(c, 18 * s, 108 * s, w - 18 * s, h - 52 * s, 30 * s, 0xF20B0B0D);
        txt(c, "MODO DE CAPTURA", 38 * s, 151 * s, 27 * s, Color.WHITE, true);
        float y = 174 * s;
        for (int i = 0; i < MODES.length; i++) {
            boolean active = i == mode.ordinal();
            rounded(c, 30 * s, y, w - 30 * s, y + 72 * s, 22 * s, active ? 0xFFF4F4F4 : 0x331F1F22);
            txt(c, MODES[i], 52 * s, y + 31 * s, 21 * s, active ? Color.BLACK : Color.WHITE, true);
            txt(c, DESCS[i], 52 * s, y + 55 * s, 13 * s, active ? 0xFF333333 : 0xCCFFFFFF, false);
            y += 79 * s;
        }
        txt(c, "Toque fora para fechar", 38 * s, h - 76 * s, 12 * s, WHITE_70, false);
    }

    private void drawInfo(Canvas c, float s) {
        int w = getWidth(), h = getHeight();
        rounded(c, 10 * s, 42 * s, w - 10 * s, h - 18 * s, 24 * s, 0xF20B0B0D);
        txt(c, "ULTRAZOOM • DIAGNÓSTICO UZ-116", 26 * s, 78 * s, 21 * s, Color.WHITE, true);
        txt(c, "MEDIÇÃO REAL DO PIPELINE CAMERA2", 28 * s, 101 * s, 11 * s, WHITE_70, true);
        float y = 130 * s;
        infoRow(c, "Câmera ativa", cameraId == null ? "—" : cameraId, y, s); y += 25 * s;
        infoRow(c, "Principal", mainCameraId == null ? "—" : mainCameraId, y, s); y += 25 * s;
        infoRow(c, "Seleção", cameraSelectionReason, y, s); y += 25 * s;
        infoRow(c, "Zoom", zoomDiagnostics, y, s); y += 25 * s;
        infoRow(c, "JPEG", sizeString(jpegSize) + " • max " + sizeString(largestJpegSize), y, s); y += 25 * s;
        infoRow(c, "Preview", sizeString(previewSize), y, s); y += 25 * s;
        infoRow(c, "0,5×", wideSupported ? "EVIDÊNCIA DE ULTRAWIDE" : "NÃO EXPOSTO PELA CAMERA2", y, s); y += 25 * s;
        infoRow(c, "Layout", layoutValid ? "SEM SOBREPOSIÇÃO" : "FALHA", y, s); y += 26 * s;
        txt(c, "ORIENTAÇÃO", 26 * s, y, 11 * s, 0xAAFFFFFF, true); y += 17 * s;
        drawDiagnosticText(c, orientationDiagnostics + " • " + previewSelectionDiagnostic, 26 * s, y, w - 52 * s, 10 * s); y += 34 * s;
        txt(c, "DISPOSITIVO / CAPACIDADES", 26 * s, y, 11 * s, 0xAAFFFFFF, true); y += 17 * s;
        drawDiagnosticText(c, detailedDiagnostics, 26 * s, y, w - 52 * s, 9.5f * s);
        y = h - 155 * s;
        txt(c, "OIS / EIS", 26 * s, y, 11 * s, 0xAAFFFFFF, true); y += 16 * s;
        drawDiagnosticText(c, stabilizationDiagnostics, 26 * s, y, w - 52 * s, 9.5f * s); y += 29 * s;
        txt(c, "FOCO / EXPOSIÇÃO", 26 * s, y, 11 * s, 0xAAFFFFFF, true); y += 16 * s;
        drawDiagnosticText(c, focusDiagnostics, 26 * s, y, w - 52 * s, 9.5f * s);
        txt(c, "BUILD " + BUILD_ID + " • " + layoutDiagnostic, 26 * s, h - 35 * s, 9.5f * s, WHITE_70, false);
        txt(c, "Toque fora para fechar", w - 165 * s, h - 35 * s, 9.5f * s, WHITE_70, false);
    }

    private void drawDiagnosticText(Canvas c, String value, float x, float y, float width, float size) {
        String[] lines = value == null ? new String[]{"—"} : value.split("\\n");
        int count = Math.min(lines.length, 12);
        float lineH = Math.max(13f, size * 1.55f);
        for (int i = 0; i < count; i++) txt(c, ellipsize(lines[i], 105), x, y + i * lineH, size, WHITE_70, false);
    }

    private String ellipsize(String s, int max) {
        if (s == null) return "—";
        return s.length() <= max ? s : s.substring(0, Math.max(0, max - 1)) + "…";
    }

    private void infoRow(Canvas c, String a, String b, float y, float s) {
        txt(c, a, 38 * s, y, 15 * s, 0xAAFFFFFF, false);
        txt(c, b, 270 * s, y, 18 * s, Color.WHITE, true);
    }

    private boolean overlaps(RectF a, RectF b) {
        return RectF.intersects(a, b);
    }

    private void validateLayout() {
        layoutValid = true;
        layoutDiagnostic = "OK";
        for (int i = 0; i < ui.lens.length; i++) {
            if (ui.lens[i].left < 0 || ui.lens[i].right > getWidth()) { layoutValid = false; layoutDiagnostic = "LENTE FORA DA TELA"; }
            for (int j = i + 1; j < ui.lens.length; j++) if (overlaps(ui.lens[i], ui.lens[j])) { layoutValid = false; layoutDiagnostic = "LENTES SOBREPOSTAS"; }
        }
        if (overlaps(ui.mini, ui.lens[0]) || overlaps(ui.mini, ui.lens[1]) || overlaps(ui.mini, ui.lens[2]) || overlaps(ui.mini, ui.lens[3]) || overlaps(ui.mini, ui.lens[4])) {
            layoutValid = false; layoutDiagnostic = "MINIMAPA SOBRE LENTES";
        }
        if (overlaps(ui.zoomArea, ui.shutter) || overlaps(ui.zoomArea, ui.flash) || overlaps(ui.zoomArea, ui.mode)) {
            layoutValid = false; layoutDiagnostic = "ZOOM SOBRE CONTROLES";
        }
        if (overlaps(ui.flash, ui.shutter) || overlaps(ui.shutter, ui.mode) || overlaps(ui.flash, ui.mode)) {
            layoutValid = false; layoutDiagnostic = "CONTROLES INFERIORES SOBREPOSTOS";
        }
    }

    private static class CameraRecord {
        String id;
        boolean logical;
        float fov;
        RangeZ range;
        Size pixels;
        long area;
    }

    private boolean isBetterMain(CameraRecord candidate, CameraRecord current) {
        if (current == null) return true;
        if (candidate.area != current.area) return candidate.area > current.area;
        return compareCameraIds(candidate.id, current.id) < 0;
    }

    private int compareCameraIds(String a, String b) {
        try { return Integer.compare(Integer.parseInt(a), Integer.parseInt(b)); }
        catch (Exception ignored) { return a.compareTo(b); }
    }

    private String formatRecord(CameraRecord r) {
        String resolution = r.pixels == null ? "—" : r.pixels.getWidth() + "×" + r.pixels.getHeight();
        return "ID " + r.id + (r.logical ? " LOGICAL" : "") + " • " + resolution + " • " +
                (r.fov > 0 ? String.format(Locale.US, "FOV %.1f°", Math.toDegrees(r.fov)) : "FOV ?") + " • " +
                String.format(Locale.US, "zoom %.2f–%.1f×", r.range.min, r.range.max);
    }

    private String sizeString(Size s) {
        return s == null ? "—" : s.getWidth() + "×" + s.getHeight();
    }

    private String boolString(boolean v) { return v ? "SIM" : "NÃO"; }

    private String capabilityNames(int[] caps) {
        if (caps == null || caps.length == 0) return "—";
        ArrayList<String> out = new ArrayList<>();
        for (int c : caps) {
            switch (c) {
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE: out.add("BACKWARD"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR: out.add("MANUAL_SENSOR"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING: out.add("MANUAL_PP"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW: out.add("RAW"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_PRIVATE_REPROCESSING: out.add("PRIVATE_REPROCESS"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_READ_SENSOR_SETTINGS: out.add("READ_SENSOR"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BURST_CAPTURE: out.add("BURST"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_YUV_REPROCESSING: out.add("YUV_REPROCESS"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_DEPTH_OUTPUT: out.add("DEPTH"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_CONSTRAINED_HIGH_SPEED_VIDEO: out.add("HIGH_SPEED"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA: out.add("LOGICAL_MULTI"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MOTION_TRACKING: out.add("MOTION_TRACKING"); break;
                case CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_ULTRA_HIGH_RESOLUTION_SENSOR: out.add("ULTRA_HIGH_RES"); break;
                default: out.add("CAP_" + c); break;
            }
        }
        return join(out, ", ");
    }

    private String join(List<String> values, String sep) {
        StringBuilder b = new StringBuilder();
        for (String v : values) {
            if (b.length() > 0) b.append(sep);
            b.append(v);
        }
        return b.toString();
    }

    private String arrayString(int[] values) {
        if (values == null || values.length == 0) return "—";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) b.append(",");
            b.append(values[i]);
        }
        return b.toString();
    }

    private String floatArrayString(float[] values) {
        if (values == null || values.length == 0) return "—";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) b.append(",");
            b.append(String.format(Locale.US, "%.3f", values[i]));
        }
        return b.toString();
    }

    private String rangeString(Range<Float> r) {
        return r == null ? "—" : String.format(Locale.US, "%.2f–%.2f×", r.getLower(), r.getUpper());
    }

    private String orientationString(CameraCharacteristics cc) {
        Integer so = cc == null ? null : cc.get(CameraCharacteristics.SENSOR_ORIENTATION);
        int display = 0;
        try {
            int r = getContext().getDisplay().getRotation();
            display = r == Surface.ROTATION_90 ? 90 : r == Surface.ROTATION_180 ? 180 : r == Surface.ROTATION_270 ? 270 : 0;
        } catch (Exception ignored) { }
        int sensorOrientation = so == null ? -1 : so;
        int relative = sensorOrientation < 0 ? -1 : (sensorOrientation - display + 360) % 360;
        return "display=" + display + "° sensor=" + sensorOrientation + "° relative=" + relative + "°";
    }

    private String describeCamera(String id, CameraCharacteristics cc) {
        StringBuilder b = new StringBuilder();
        Size px = cc.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
        Size active = cc.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) == null ? null :
                new Size(cc.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE).width(), cc.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE).height());
        SizeF physical = cc.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
        float[] focal = cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
        Range<Float> zr = Build.VERSION.SDK_INT >= 30 ? cc.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) : null;
        Float dz = cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
        Integer level = cc.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL);
        int[] caps = cc.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
        Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
        b.append("ID=").append(id)
         .append(" facing=").append(facing == null ? "?" : facing)
         .append(" hwLevel=").append(level == null ? "?" : level)
         .append(" logical=").append(boolString(hasCapability(caps, CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)))
         .append(" pixels=").append(sizeString(px))
         .append(" active=").append(sizeString(active))
         .append(" physical=").append(physical == null ? "?" : String.format(Locale.US, "%.2f×%.2fmm", physical.getWidth(), physical.getHeight()))
         .append(" focal=").append(floatArrayString(focal))
         .append(" FOV=").append(horizontalFov(cc) > 0 ? String.format(Locale.US, "%.2f°", Math.toDegrees(horizontalFov(cc))) : "?")
         .append(" zoomRatio=").append(rangeString(zr))
         .append(" maxDigital=").append(dz == null ? "?" : String.format(Locale.US, "%.2f×", dz));
        return b.toString();
    }

    private void collectDetailedDiagnostics(CameraManager cm, String[] ids, CameraCharacteristics main) {
        StringBuilder d = new StringBuilder();
        d.append("DEVICE ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL)
         .append(" • Android ").append(Build.VERSION.SDK_INT).append(" • SDK ").append(Build.VERSION.RELEASE).append("\n");
        d.append("Display ").append(orientationString(main)).append("\n");
        Integer mainSo = main.get(CameraCharacteristics.SENSOR_ORIENTATION);
        d.append("Main sensor orientation=").append(mainSo == null ? "?" : mainSo).append("°\n");
        d.append("Main active array=").append(sizeString(main.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) == null ? null :
                new Size(main.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE).width(), main.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE).height()))).append("\n");
        d.append("Main pixel array=").append(sizeString(main.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE))).append("\n");
        d.append("Main FOV=").append(horizontalFov(main) > 0 ? String.format(Locale.US, "%.2f°", Math.toDegrees(horizontalFov(main))) : "?").append("\n");
        d.append("Main focal=").append(floatArrayString(main.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS))).append("mm\n");
        SizeF ps = main.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
        d.append("Sensor physical=").append(ps == null ? "?" : String.format(Locale.US, "%.2f×%.2fmm", ps.getWidth(), ps.getHeight())).append("\n");
        d.append("Hardware level=").append(main.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)).append("\n");
        d.append("Capabilities=").append(capabilityNames(main.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES))).append("\n");
        Range<Float> zr = Build.VERSION.SDK_INT >= 30 ? main.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) : null;
        Float dz = main.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
        d.append("CONTROL_ZOOM_RATIO_RANGE=").append(rangeString(zr)).append("\n");
        d.append("SCALER_MAX_DIGITAL_ZOOM=").append(dz == null ? "?" : String.format(Locale.US, "%.2f×", dz)).append("\n");
        d.append("Public rear count=").append(backCameraCount).append("\n");
        d.append("Camera IDs=").append(Arrays.toString(ids)).append("\n");
        d.append("JPEG selected=").append(sizeString(jpegSize)).append(" • largest=").append(sizeString(largestJpegSize)).append("\n");
        d.append("Preview selected=").append(sizeString(previewSize)).append(" • ").append(previewSelectionDiagnostic).append("\n");
        d.append("OIS/EIS=").append(stabilizationDiagnostics).append("\n");
        d.append("AF=").append(focusDiagnostics).append("\n");
        d.append("Physical IDs=").append(physicalIdsDiagnostics).append("\n");
        d.append("Outputs=").append(outputDiagnostics);
        detailedDiagnostics = d.toString();
    }

    private void collectCapabilityDiagnostics(CameraCharacteristics cc) {
        if (cc == null) return;
        int[] caps = cc.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
        capabilitiesDiagnostics = capabilityNames(caps);
        int[] afModes = cc.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES);
        int[] aeModes = cc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES);
        int[] awbModes = cc.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES);
        focusDiagnostics = "AF modes=" + arrayString(afModes) + " • maxAF=" +
                String.valueOf(cc.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF)) +
                " • maxAE=" + String.valueOf(cc.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE)) +
                " • AE=" + arrayString(aeModes) + " • AWB=" + arrayString(awbModes);
        boolean[] ois = cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION) == null ?
                new boolean[0] : cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION);
        int[] eis = cc.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
        stabilizationDiagnostics = "OIS=" + (ois.length == 0 ? "?" : Arrays.toString(ois)) + " • EIS=" + arrayString(eis);
        Range<Float> zr = Build.VERSION.SDK_INT >= 30 ? cc.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) : null;
        Float dz = cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
        zoomDiagnostics = "ratio=" + rangeString(zr) + " • maxDigital=" + (dz == null ? "?" : String.format(Locale.US, "%.2f×", dz));
    }

    private void collectOutputDiagnostics(CameraCharacteristics cc) {
        StreamConfigurationMap map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (map == null) { outputDiagnostics = "StreamConfigurationMap indisponível"; return; }
        StringBuilder b = new StringBuilder();
        Size[] js = map.getOutputSizes(android.graphics.ImageFormat.JPEG);
        if (js != null) {
            for (Size s : js) {
                if (largestJpegSize == null || (long)s.getWidth()*s.getHeight() > (long)largestJpegSize.getWidth()*largestJpegSize.getHeight()) largestJpegSize = s;
            }
        }
        b.append("JPEG count=").append(js == null ? 0 : js.length).append(" max=").append(sizeString(largestJpegSize));
        Size[] y = map.getOutputSizes(android.graphics.ImageFormat.YUV_420_888);
        b.append(" • YUV count=").append(y == null ? 0 : y.length);
        if (Build.VERSION.SDK_INT >= 23) {
            Size[] p = map.getOutputSizes(SurfaceTexture.class);
            b.append(" • PREVIEW count=").append(p == null ? 0 : p.length);
        }
        outputDiagnostics = b.toString();
    }

    private void open() {
        if (device != null) return;
        try {
            CameraManager cm = (CameraManager)getContext().getSystemService(Context.CAMERA_SERVICE);
            String[] ids = cm.getCameraIdList();
            mainCameraId = null; wideCameraId = null; physicalWideId = null; activePhysicalId = null;
            wideSupported = false; backCameraCount = 0;
            StringBuilder publicDiag = new StringBuilder();
            StringBuilder physicalDiag = new StringBuilder();
            CameraRecord best = null;
            CameraRecord bestWidePublic = null;

            for (String id : ids) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
                backCameraCount++;
                CameraRecord r = new CameraRecord();
                r.id = id;
                r.fov = horizontalFov(cc);
                r.range = range(cc);
                int[] caps = cc.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
                r.logical = hasCapability(caps, CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA);
                r.pixels = cc.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
                r.area = r.pixels == null ? 0L : (long)r.pixels.getWidth() * r.pixels.getHeight();
                publicDiag.append(formatRecord(r)).append("\n");
                if (isBetterMain(r, best)) best = r;
                if (bestWidePublic == null || (r.fov > bestWidePublic.fov)) bestWidePublic = r;
            }

            publicCameraDiagnostic = publicDiag.length() == 0 ? "Nenhuma câmera traseira pública." : publicDiag.toString().trim();
            if (best == null) {
                cameraDiagnostics = "Nenhuma câmera traseira";
                status = "NENHUMA CÂMERA TRASEIRA";
                invalidate();
                return;
            }
            mainCameraId = best.id;
            cameraSelectionReason = "MAIOR RESOLUÇÃO " + (best.pixels == null ? "DESCONHECIDA" : best.pixels.getWidth() + "×" + best.pixels.getHeight()) + "; empate → menor ID";

            CameraCharacteristics main = cm.getCameraCharacteristics(mainCameraId);
            collectCapabilityDiagnostics(main);
            collectOutputDiagnostics(main);
            float mainFov = horizontalFov(main);
            RangeZ mainRange = range(main);
            if (mainRange.min <= 0.55f) {
                wideSupported = true;
                wideCameraId = mainCameraId;
            }

            if (Build.VERSION.SDK_INT >= 28) {
                try {
                    java.util.Set<String> physicalIds = main.getPhysicalCameraIds();
                    if (physicalIds == null || physicalIds.isEmpty()) {
                        physicalDiag.append("getPhysicalCameraIds(): VAZIO\n");
                    } else {
                        physicalDiag.append("getPhysicalCameraIds(): ").append(physicalIds).append("\n");
                        float widest = 0f;
                        for (String pid : physicalIds) {
                            try {
                                CameraCharacteristics pc = cm.getCameraCharacteristics(pid);
                                float pfov = horizontalFov(pc);
                                RangeZ pr = range(pc);
                                Size pp = pc.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
                                physicalDiag.append("PHYS ").append(pid).append(" • ")
                                        .append(pp == null ? "res ?" : pp.getWidth() + "×" + pp.getHeight())
                                        .append(" • ").append(pfov > 0 ? String.format(Locale.US, "FOV %.1f°", Math.toDegrees(pfov)) : "FOV ?")
                                        .append(" • ").append(String.format(Locale.US, "zoom %.2f–%.1f×", pr.min, pr.max)).append("\n");
                                if (pfov > widest) {
                                    widest = pfov;
                                    if (mainFov > 0 && pfov > mainFov * 1.15f) physicalWideId = pid;
                                }
                            } catch (Exception ex) {
                                physicalDiag.append("PHYS ").append(pid).append(" • características não públicas para CameraManager\n");
                            }
                        }
                        if (physicalWideId != null) {
                            wideSupported = true;
                            wideCameraId = mainCameraId;
                        }
                    }
                } catch (Exception ex) {
                    physicalDiag.append("getPhysicalCameraIds(): erro ").append(ex.getClass().getSimpleName()).append("\n");
                }
            } else {
                physicalDiag.append("API < 28: physical IDs não suportados pelo caminho usado.\n");
            }

            // Only a separate public rear camera with a demonstrably wider FOV can be a
            // fallback ultrawide. Never infer 0.5x from a camera ID alone.
            if (!wideSupported) {
                float widestFov = 0f;
                String widestId = null;
                for (String id : ids) {
                    if (id.equals(mainCameraId)) continue;
                    try {
                        CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                        Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                        if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
                        float fov = horizontalFov(cc);
                        if (fov > widestFov) { widestFov = fov; widestId = id; }
                    } catch (Exception ignored) { }
                }
                if (widestId != null && mainFov > 0 && widestFov > mainFov * 1.15f) {
                    wideCameraId = widestId;
                    wideSupported = true;
                }
            }

            physicalIdsDiagnostics = physicalDiag.length() == 0 ? "não coletado" : physicalDiag.toString().replace("\n", " | ").trim();
            collectOutputDiagnostics(main);
            collectDetailedDiagnostics(cm, ids, main);
            if (cameraId == null || (!cameraId.equals(mainCameraId) && !cameraId.equals(wideCameraId))) cameraId = mainCameraId;
            if (zoom < 1f && !wideSupported) zoom = 1f;

            boolean usingSeparateWide = wideSupported && wideCameraId != null && !wideCameraId.equals(mainCameraId) && cameraId.equals(wideCameraId);
            boolean usingPhysicalWide = wideSupported && wideCameraId != null && wideCameraId.equals(mainCameraId) && zoom < 1f && physicalWideId != null;

            if (usingPhysicalWide) {
                activePhysicalId = physicalWideId;
                deviceChars = main;
                try { chars = cm.getCameraCharacteristics(physicalWideId); }
                catch (Exception ex) { chars = main; }
            } else if (usingSeparateWide) {
                activePhysicalId = null;
                deviceChars = cm.getCameraCharacteristics(cameraId);
                chars = deviceChars;
            } else {
                activePhysicalId = null;
                deviceChars = main;
                chars = main;
                cameraId = mainCameraId;
                if (zoom < 1f) zoom = 1f;
            }

            sensor = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            RangeZ rr = range(chars);
            minHardware = rr.min;
            maxHardware = rr.max;
            if (usingPhysicalWide || usingSeparateWide) {
                minHardware = Math.max(1f, minHardware);
                if (zoom < 1f) zoom = .5f;
            }

            prepareReader(chars);
            collectOutputDiagnostics(chars);
            collectCapabilityDiagnostics(chars);
            flashAvailable = Boolean.TRUE.equals(chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE));
            collectDetailedDiagnostics(cm, ids, main);
            lowLightBoostSupported = supportsLowLightBoost(chars);
            cameraDiagnostics = publicCameraDiagnostic;
            status = wideSupported ? "CÂMERA PRONTA • 0,5× DISPONÍVEL" : "CÂMERA PRONTA • 0,5× NÃO DISPONÍVEL";

            if (getContext().checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
            cm.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice d) { device = d; createSession(); }
                @Override public void onDisconnected(CameraDevice d) { d.close(); device = null; }
                @Override public void onError(CameraDevice d, int e) { d.close(); device = null; status = "ERRO NA CÂMERA"; postInvalidate(); }
            }, cameraHandler);
            invalidate();
        } catch (Exception e) {
            status = "CÂMERA INDISPONÍVEL";
            cameraDiagnostics = e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
            postInvalidate();
        }
    }

    private boolean supportsLowLightBoost(CameraCharacteristics cc) {
        if (Build.VERSION.SDK_INT < 35) return false;
        int[] modes = cc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES);
        if (modes == null) return false;
        for (int m : modes) if (m == CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY) return true;
        return false;
    }

    private boolean hasCapability(int[] caps, int wanted) {
        if (caps == null) return false;
        for (int c : caps) if (c == wanted) return true;
        return false;
    }

    private void prepareReader(CameraCharacteristics cc) {
        if (reader != null) { reader.close(); reader = null; }
        if (miniReader != null) { miniReader.close(); miniReader = null; }
        StreamConfigurationMap map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        jpegSize = new Size(1920, 1080);
        Size miniSize = new Size(640, 480);
        if (map != null) {
            Size[] sizes = map.getOutputSizes(android.graphics.ImageFormat.JPEG);
            if (sizes != null && sizes.length > 0) {
                Size bestUnder12 = null;
                Size largest = sizes[0];
                Size bestMini = null;
                for (Size candidate : sizes) {
                    long area = (long) candidate.getWidth() * candidate.getHeight();
                    long largestArea = (long) largest.getWidth() * largest.getHeight();
                    if (area > largestArea) largest = candidate;
                    if (area <= 12_000_000L && (bestUnder12 == null || area > (long) bestUnder12.getWidth() * bestUnder12.getHeight())) bestUnder12 = candidate;
                    if (area >= 250_000L && area <= 1_000_000L) {
                        if (bestMini == null || area > (long) bestMini.getWidth() * bestMini.getHeight()) bestMini = candidate;
                    }
                }
                jpegSize = largest;
                if (bestMini != null) miniSize = bestMini;
                else {
                    float target = 4f / 3f;
                    double best = Double.MAX_VALUE;
                    for (Size candidate : sizes) {
                        long area = (long) candidate.getWidth() * candidate.getHeight();
                        if (area > 1_500_000L) continue;
                        double score = Math.abs(((double)candidate.getWidth()/candidate.getHeight()) - target) * 10 + Math.abs(area - 500_000L) / 500_000d;
                        if (score < best) { best = score; miniSize = candidate; }
                    }
                }
            }
        }
        if (map != null) {
            Size[] yuvSizes = map.getOutputSizes(android.graphics.ImageFormat.YUV_420_888);
            if (yuvSizes != null && yuvSizes.length > 0) {
                Size best = null;
                double bestScore = Double.MAX_VALUE;
                for (Size candidate : yuvSizes) {
                    long area = (long) candidate.getWidth() * candidate.getHeight();
                    if (area < 100_000L || area > 1_500_000L) continue;
                    double ratio = (double) candidate.getWidth() / Math.max(1, candidate.getHeight());
                    double score = Math.abs(ratio - 4d / 3d) * 10d + Math.abs(area - 460_800d) / 460_800d;
                    if (score < bestScore) { bestScore = score; best = candidate; }
                }
                if (best != null) miniSize = best;
            }
        }

        reader = ImageReader.newInstance(jpegSize.getWidth(), jpegSize.getHeight(), android.graphics.ImageFormat.JPEG, 4);
        reader.setOnImageAvailableListener(rdr -> {
            Image im = null;
            try {
                im = rdr.acquireNextImage();
                if (im != null && busy) {
                    ByteBuffer buf = im.getPlanes()[0].getBuffer();
                    byte[] data = new byte[buf.remaining()];
                    buf.get(data);
                    BitmapFactory.Options opt = new BitmapFactory.Options();
                    opt.inPreferredConfig = Bitmap.Config.ARGB_8888;
                    Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length, opt);
                    if (bm != null) finishPhoto(bm);
                }
            } catch (Exception ignored) {
            } finally {
                if (im != null) im.close();
            }
        }, workHandler);

        miniReader = ImageReader.newInstance(miniSize.getWidth(), miniSize.getHeight(), android.graphics.ImageFormat.YUV_420_888, 2);
        miniReader.setOnImageAvailableListener(rdr -> {
            Image im = null;
            try {
                im = rdr.acquireLatestImage();
                if (im != null) {
                    Bitmap bm = yuvToBitmap(im);
                    if (bm != null) {
                        Bitmap old = miniBitmap;
                        miniBitmap = bm;
                        if (old != null && !old.isRecycled()) old.recycle();
                        postInvalidate();
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (im != null) im.close();
                miniCapturePending = false;
            }
        }, workHandler);
    }

    private Bitmap yuvToBitmap(Image image) {
        int w = image.getWidth(), h = image.getHeight();
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length < 3) return null;
        ByteBuffer yBuf = planes[0].getBuffer();
        ByteBuffer uBuf = planes[1].getBuffer();
        ByteBuffer vBuf = planes[2].getBuffer();
        int yRow = planes[0].getRowStride(), uRow = planes[1].getRowStride(), vRow = planes[2].getRowStride();
        int yPix = planes[0].getPixelStride(), uPix = planes[1].getPixelStride(), vPix = planes[2].getPixelStride();
        int[] pixels = new int[w * h];
        for (int yy = 0; yy < h; yy++) {
            int yBase = yy * yRow;
            int uvY = yy >> 1;
            for (int xx = 0; xx < w; xx++) {
                int yIndex = yBase + xx * yPix;
                int uvX = xx >> 1;
                int uIndex = uvY * uRow + uvX * uPix;
                int vIndex = uvY * vRow + uvX * vPix;
                int Y = (yBuf.get(yIndex) & 0xFF) - 16;
                int U = (uBuf.get(uIndex) & 0xFF) - 128;
                int V = (vBuf.get(vIndex) & 0xFF) - 128;
                int r = clamp255((298 * Y + 409 * V + 128) >> 8);
                int g = clamp255((298 * Y - 100 * U - 208 * V + 128) >> 8);
                int b = clamp255((298 * Y + 516 * U + 128) >> 8);
                pixels[yy * w + xx] = Color.rgb(r, g, b);
            }
        }
        Bitmap bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        bm.setPixels(pixels, 0, w, 0, 0, w, h);
        return bm;
    }

    private int clamp255(int v) { return Math.max(0, Math.min(255, v)); }

    private float horizontalFov(CameraCharacteristics cc) {
        try {
            float[] fs = cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            SizeF physical = cc.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            if (fs != null && fs.length > 0 && physical != null && fs[0] > 0) {
                return (float)(2d * Math.atan(physical.getWidth() / (2d * fs[0])));
            }
        } catch (Exception ignored) { }
        return 0f;
    }

    private static class RangeZ {
        final float min, max;
        RangeZ(float min, float max) { this.min = min; this.max = max; }
    }

    private RangeZ range(CameraCharacteristics cc) {
        if (Build.VERSION.SDK_INT >= 30) {
            Range<Float> r = cc.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
            if (r != null) return new RangeZ(r.getLower(), r.getUpper());
        }
        Float z = cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
        return new RangeZ(1f, Math.max(1f, z == null ? 1f : z));
    }

    private void createSession() {
        try {
            SurfaceTexture st = preview.getSurfaceTexture();
            if (st == null || device == null || reader == null || miniReader == null) return;
            previewSize = choosePreviewSize(chars);
            st.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            Surface ps = new Surface(st);
            miniInSession = false;

            if (Build.VERSION.SDK_INT >= 28 && activePhysicalId != null) {
                OutputConfiguration po = new OutputConfiguration(ps);
                OutputConfiguration jo = new OutputConfiguration(reader.getSurface());
                OutputConfiguration mo = new OutputConfiguration(miniReader.getSurface());
                po.setPhysicalCameraId(activePhysicalId);
                jo.setPhysicalCameraId(activePhysicalId);
                mo.setPhysicalCameraId(activePhysicalId);
                List<OutputConfiguration> outputs = Arrays.asList(po, jo, mo);
                SessionConfiguration config = new SessionConfiguration(SessionConfiguration.SESSION_REGULAR, outputs, cameraExecutor, new CameraCaptureSession.StateCallback() {
                    @Override public void onConfigured(CameraCaptureSession s) {
                        session = s;
                        miniInSession = true;
                        applyPreview();
                    }
                    @Override public void onConfigureFailed(CameraCaptureSession s) {
                        // Some OEMs do not allow the YUV minimap stream together with
                        // a physical-camera JPEG. Keep the real ultrawide alive with
                        // a simpler preview+JPEG session instead of disabling the lens.
                        createPhysicalFallbackSession(ps);
                    }
                });
                device.createCaptureSession(config);
            } else {
                device.createCaptureSession(Arrays.asList(ps, reader.getSurface(), miniReader.getSurface()), new CameraCaptureSession.StateCallback() {
                    @Override public void onConfigured(CameraCaptureSession s) {
                        session = s;
                        miniInSession = true;
                        applyPreview();
                    }
                    @Override public void onConfigureFailed(CameraCaptureSession s) {
                        createSimpleSession(ps, "FALHA AO CONFIGURAR CÂMERA");
                    }
                }, cameraHandler);
            }
        } catch (Exception e) {
            status = "FALHA NA SESSÃO";
            postInvalidate();
        }
    }

    private void createPhysicalFallbackSession(Surface ps) {
        try {
            OutputConfiguration po = new OutputConfiguration(ps);
            OutputConfiguration jo = new OutputConfiguration(reader.getSurface());
            po.setPhysicalCameraId(activePhysicalId);
            jo.setPhysicalCameraId(activePhysicalId);
            SessionConfiguration config = new SessionConfiguration(SessionConfiguration.SESSION_REGULAR, Arrays.asList(po, jo), cameraExecutor, new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) {
                    session = s;
                    miniInSession = false;
                    status = "0,5× • ULTRAWIDE REAL • MAPA OFF";
                    applyPreview();
                }
                @Override public void onConfigureFailed(CameraCaptureSession s) {
                    status = "ULTRAWIDE FÍSICA NÃO ACEITA ESTA SESSÃO";
                    postInvalidate();
                }
            });
            device.createCaptureSession(config);
        } catch (Exception e) {
            status = "ULTRAWIDE FÍSICA INDISPONÍVEL";
            postInvalidate();
        }
    }

    private void createSimpleSession(Surface ps, String failStatus) {
        try {
            device.createCaptureSession(Arrays.asList(ps, reader.getSurface()), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) {
                    session = s;
                    miniInSession = false;
                    status = "CÂMERA PRONTA • MAPA OFF";
                    applyPreview();
                }
                @Override public void onConfigureFailed(CameraCaptureSession s) {
                    status = failStatus;
                    postInvalidate();
                }
            }, cameraHandler);
        } catch (Exception e) {
            status = failStatus;
            postInvalidate();
        }
    }

    private Size choosePreviewSize(CameraCharacteristics cc) {
        StreamConfigurationMap map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (map == null) return new Size(1920, 1080);
        Size[] sizes = map.getOutputSizes(SurfaceTexture.class);
        if (sizes == null || sizes.length == 0) return new Size(1920, 1080);
        boolean portrait = getHeight() > getWidth();
        float targetRatio = getHeight() == 0 ? 16f / 9f : (float)getWidth() / (float)getHeight();
        Size best = sizes[0];
        double bestScore = Double.MAX_VALUE;
        for (Size s : sizes) {
            float rawRatio = (float)s.getWidth() / (float)s.getHeight();
            float displayRatio = portrait ? Math.min(rawRatio, 1f / Math.max(0.0001f, rawRatio)) : Math.max(rawRatio, 1f / Math.max(0.0001f, rawRatio));
            double ratioScore = Math.abs(displayRatio - targetRatio);
            long area = (long)s.getWidth() * s.getHeight();
            double areaPenalty = area > 1920L * 1080L ? 0.15 : 0;
            double score = ratioScore * 10 + areaPenalty;
            if (score < bestScore) { bestScore = score; best = s; }
        }
        previewSelectionDiagnostic = String.format(Locale.US, "target %.3f; portrait=%s; buffer=%s", targetRatio, portrait, sizeString(best));
        return best;
    }

    private CaptureRequest.Builder request(int template) throws Exception {
        CaptureRequest.Builder b = device.createCaptureRequest(template);
        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);

        int ae = CaptureRequest.CONTROL_AE_MODE_ON;
        if (mode == Mode.NIGHT && lowLightBoostSupported) {
            ae = CaptureRequest.CONTROL_AE_MODE_ON_LOW_LIGHT_BOOST_BRIGHTNESS_PRIORITY;
        } else if (template == CameraDevice.TEMPLATE_STILL_CAPTURE && flashAvailable) {
            if (flashMode == 1) ae = CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH;
            else if (flashMode == 2) ae = CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH;
        }
        b.set(CaptureRequest.CONTROL_AE_MODE, ae);
        if (flashAvailable) {
            if (template == CameraDevice.TEMPLATE_PREVIEW && flashMode == 2) b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH);
            else b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
        }

        applyHardwareZoom(b, zoom);
        if (focusRegion != null) {
            Integer maxAf = chars == null ? null : chars.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF);
            Integer maxAe = chars == null ? null : chars.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE);
            if (maxAf != null && maxAf > 0) b.set(CaptureRequest.CONTROL_AF_REGIONS, new android.hardware.camera2.params.MeteringRectangle[]{
                    new android.hardware.camera2.params.MeteringRectangle(focusRegion, 800)
            });
            if (maxAe != null && maxAe > 0) b.set(CaptureRequest.CONTROL_AE_REGIONS, new android.hardware.camera2.params.MeteringRectangle[]{
                    new android.hardware.camera2.params.MeteringRectangle(focusRegion, 600)
            });
        }

        if (mode == Mode.NIGHT && template == CameraDevice.TEMPLATE_STILL_CAPTURE && !lowLightBoostSupported) {
            Range<Integer> ar = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            if (ar != null) {
                int ev = Math.min(ar.getUpper(), Math.max(ar.getLower(), 2));
                b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev);
            }
        }
        return b;
    }

    private void applyHardwareZoom(CaptureRequest.Builder b, float requestedZoom) {
        if (sensor == null) return;
        // A separate/physical ultrawide is selected as a lens. Its native frame is 0.5x
        // relative to the main camera, so its own hardware zoom request remains at 1x.
        if (requestedZoom < 1f && activePhysicalId != null) {
            if (Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, 1f);
            else b.set(CaptureRequest.SCALER_CROP_REGION, sensor);
            return;
        }
        if (requestedZoom < 1f && cameraId != null && cameraId.equals(wideCameraId)) {
            if (Build.VERSION.SDK_INT >= 30 && minHardware < 1f && requestedZoom >= minHardware && requestedZoom <= maxHardware) {
                b.set(CaptureRequest.CONTROL_ZOOM_RATIO, Math.max(minHardware, Math.min(maxHardware, requestedZoom)));
            } else {
                b.set(CaptureRequest.SCALER_CROP_REGION, sensor);
            }
            return;
        }

        float hardwareZoom = Math.max(1f, Math.min(maxHardware, requestedZoom));
        if (Build.VERSION.SDK_INT >= 30 && hardwareZoom >= minHardware && hardwareZoom <= maxHardware) {
            b.set(CaptureRequest.CONTROL_ZOOM_RATIO, hardwareZoom);
        } else {
            Rect crop = cropForZoom(hardwareZoom);
            if (crop != null) b.set(CaptureRequest.SCALER_CROP_REGION, crop);
        }
    }

    private CaptureRequest.Builder requestAtZoom(int template, float forcedZoom) throws Exception {
        CaptureRequest.Builder b = request(template);
        applyHardwareZoom(b, forcedZoom);
        return b;
    }

    private Rect cropForZoom(float z) {
        if (sensor == null) return null;
        z = Math.max(1f, Math.min(100f, z));
        int cw = Math.max(2, Math.round(sensor.width() / z));
        int ch = Math.max(2, Math.round(sensor.height() / z));
        int left = sensor.centerX() - cw / 2;
        int top = sensor.centerY() - ch / 2;
        Rect r = new Rect(left, top, left + cw, top + ch);
        r.intersect(sensor);
        return r;
    }

    private void applyPreview() {
        try {
            if (session == null || preview.getSurfaceTexture() == null) return;
            CaptureRequest.Builder b = request(CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(new Surface(preview.getSurfaceTexture()));
            session.setRepeatingRequest(b.build(), null, cameraHandler);
            transform();
            status = mode == Mode.NIGHT ? "NIGHT • PRÉ-VISUALIZAÇÃO" : "PRONTO • " + zoomString();
            invalidate();
        } catch (Exception e) {
            status = "ERRO AO APLICAR ZOOM";
            invalidate();
        }
    }

    private void transform() {
        if (preview == null || getWidth() <= 0 || getHeight() <= 0 || previewSize == null) return;
        try {
            int rotation = getContext().getDisplay().getRotation();
            Integer so = deviceChars == null ? null : deviceChars.get(CameraCharacteristics.SENSOR_ORIENTATION);
            int sensorOrientation = so == null ? 90 : so;
            int displayDegrees = rotation == Surface.ROTATION_90 ? 90 : rotation == Surface.ROTATION_180 ? 180 : rotation == Surface.ROTATION_270 ? 270 : 0;
            int relative = (sensorOrientation - displayDegrees + 360) % 360;
            if (relative != 0 && relative != 90 && relative != 180 && relative != 270) relative = 0;
            orientationDiagnostics = "display=" + displayDegrees + "° • sensor=" + sensorOrientation + "° • relative=" + relative + "° • buffer=" + sizeString(previewSize);

            // Reference-style Camera2 transform: first map the view rectangle to the
            // correctly oriented buffer rectangle (swapping width/height for 90/270),
            // then apply one uniform scale and finally rotate. This avoids the classic
            // TextureView non-uniform stretch that made circles/doors look oval.
            RectF viewRect = new RectF(0, 0, getWidth(), getHeight());
            boolean swap = relative == 90 || relative == 270;
            float bufferW = swap ? previewSize.getHeight() : previewSize.getWidth();
            float bufferH = swap ? previewSize.getWidth() : previewSize.getHeight();
            RectF bufferRect = new RectF(0, 0, bufferW, bufferH);
            bufferRect.offset(viewRect.centerX() - bufferRect.centerX(), viewRect.centerY() - bufferRect.centerY());

            Matrix matrix = new Matrix();
            matrix.setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL);
            float uniform = Math.max(getWidth() / Math.max(1f, bufferW), getHeight() / Math.max(1f, bufferH));
            matrix.postScale(uniform, uniform, viewRect.centerX(), viewRect.centerY());
            if (relative != 0) matrix.postRotate(relative, viewRect.centerX(), viewRect.centerY());

            float softwareZoom = zoom > maxHardware && zoom >= 1f ? zoom / Math.max(1f, maxHardware) : 1f;
            if (softwareZoom > 1.001f) matrix.postScale(softwareZoom, softwareZoom, viewRect.centerX(), viewRect.centerY());
            preview.setTransform(matrix);
        } catch (Exception ignored) { }
    }

    private void beginTransition() {
        transitionUntil = System.currentTimeMillis() + 180;
        transitionAlpha = 0.72f;
        postInvalidate();
    }

    private void selectWide() {
        if (!wideSupported || wideCameraId == null) {
            status = "0,5× INDISPONÍVEL NESTE APARELHO";
            invalidate();
            return;
        }
        zoom = .5f;
        beginTransition();
        cameraId = wideCameraId;
        close();
        open();
        status = "0,5× • ULTRAWIDE REAL";
        invalidate();
    }

    private void selectMain(float z) {
        if (mainCameraId == null) {
            status = "CÂMERA PRINCIPAL INDISPONÍVEL";
            invalidate();
            return;
        }
        zoom = Math.max(1f, Math.min(100f, z));
        boolean needLensReopen = !mainCameraId.equals(cameraId) || activePhysicalId != null;
        cameraId = mainCameraId;
        beginTransition();
        if (needLensReopen) { close(); open(); } else { applyPreview(); }
        status = zoom > maxHardware ? "CROP DIGITAL REAL • " + zoomString() : "HARDWARE • " + zoomString();
        invalidate();
    }

    private void capture() {
        if (busy || session == null || device == null || reader == null) return;
        busy = true;
        frames.clear();
        finalizeScheduled = false;
        if (mode == Mode.NIGHT) targetFrames = 4;
        else if (mode == Mode.MAX || mode == Mode.ULTRA) targetFrames = 3;
        else targetFrames = 1;
        completedCaptures = 0;
        status = mode == Mode.NIGHT ? "NIGHT • CAPTURANDO 4 FRAMES" : "CAPTURANDO • " + zoomString();
        issueCapture();
        invalidate();
    }

    private void issueCapture() {
        if (!busy) return;
        try {
            CaptureRequest.Builder b = request(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(reader.getSurface());
            b.set(CaptureRequest.JPEG_ORIENTATION, rotation());
            session.capture(b.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest r, TotalCaptureResult result) {
                    completedCaptures++;
                    if (completedCaptures < targetFrames) workHandler.postDelayed(() -> issueCapture(), mode == Mode.NIGHT ? 180 : 90);
                    else {
                        workHandler.post(() -> maybeFinalizeAfterCapture());
                    }
                }
            }, cameraHandler);
        } catch (Exception e) {
            busy = false;
            status = "FALHA AO FOTOGRAFAR";
            invalidate();
        }
    }

    private Bitmap applySoftwareZoomToPhoto(Bitmap src) {
        if (src == null || zoom <= maxHardware + 0.01f || zoom < 1f) return src;
        float factor = zoom / Math.max(1f, maxHardware);
        factor = Math.max(1f, Math.min(100f, factor));
        int cropW = Math.max(8, Math.round(src.getWidth() / factor));
        int cropH = Math.max(8, Math.round(src.getHeight() / factor));
        cropW = Math.min(src.getWidth(), cropW);
        cropH = Math.min(src.getHeight(), cropH);
        int left = Math.max(0, (src.getWidth() - cropW) / 2);
        int top = Math.max(0, (src.getHeight() - cropH) / 2);
        Bitmap cropped = Bitmap.createBitmap(src, left, top, cropW, cropH);
        Bitmap out = Bitmap.createScaledBitmap(cropped, src.getWidth(), src.getHeight(), true);
        if (cropped != out) cropped.recycle();
        return out;
    }

    private void finishPhoto(Bitmap bm) {
        if (!busy || bm == null) {
            if (bm != null) bm.recycle();
            return;
        }
        Bitmap processed = applySoftwareZoomToPhoto(bm);
        if (processed != bm) bm.recycle();
        frames.add(processed);
        maybeFinalizeAfterCapture();
    }

    private void maybeFinalizeAfterCapture() {
        if (!busy) return;
        if (completedCaptures >= targetFrames && frames.size() >= targetFrames) {
            finalizeCapture();
        } else if (completedCaptures >= targetFrames && !finalizeScheduled) {
            finalizeScheduled = true;
            workHandler.postDelayed(() -> {
                if (busy && !frames.isEmpty()) finalizeCapture();
                else finalizeScheduled = false;
            }, 1500);
        }
    }

    private void finalizeCapture() {
        if (!busy) return;
        Bitmap best = null;
        synchronized (frames) {
            if (!frames.isEmpty()) {
                best = frames.get(0);
                for (Bitmap b : frames) if (b != null && sharpnessScore(b) > sharpnessScore(best)) best = b;
            }
        }
        if (best != null) {
            Bitmap output = best;
            if (mode == Mode.NIGHT) output = liftNight(best);
            boolean saved = save(output, mode == Mode.NIGHT ? "NIGHT" : MODES[mode.ordinal()]);
            if (output != best) output.recycle();
            if (!saved) status = "ERRO AO SALVAR FOTO";
            else status = "FOTO SALVA • " + zoomString();
        }
        synchronized (frames) {
            for (Bitmap b : frames) if (b != null) b.recycle();
            frames.clear();
        }
        busy = false;
        finalizeScheduled = false;
        if (best == null) status = "NÃO FOI POSSÍVEL FOTOGRAFAR";
        invalidate();
        postDelayed(() -> { if (!busy) { status = MODES[mode.ordinal()] + " • PRONTO"; invalidate(); } }, 1800);
    }

    private double sharpnessScore(Bitmap b) {
        int w = Math.min(180, b.getWidth()), h = Math.min(140, b.getHeight());
        Bitmap s = Bitmap.createScaledBitmap(b, w, h, true);
        int[] px = new int[w * h];
        s.getPixels(px, 0, w, 0, 0, w, h);
        double sum = 0, sum2 = 0; int n = 0;
        for (int y = 1; y < h - 1; y += 2) for (int x = 1; x < w - 1; x += 2) {
            int i = y * w + x;
            int center = Color.red(px[i]) + Color.green(px[i]) + Color.blue(px[i]);
            int l = Color.red(px[i - 1]) + Color.green(px[i - 1]) + Color.blue(px[i - 1]);
            int r = Color.red(px[i + 1]) + Color.green(px[i + 1]) + Color.blue(px[i + 1]);
            int u = Color.red(px[i - w]) + Color.green(px[i - w]) + Color.blue(px[i - w]);
            int d = Color.red(px[i + w]) + Color.green(px[i + w]) + Color.blue(px[i + w]);
            double q = center * 4d - l - r - u - d;
            sum += q; sum2 += q * q; n++;
        }
        if (s != b) s.recycle();
        double mean = sum / Math.max(1, n);
        return sum2 / Math.max(1, n) - mean * mean;
    }

    private Bitmap liftNight(Bitmap src) {
        Bitmap out = src.copy(Bitmap.Config.ARGB_8888, true);
        if (out == null) return src;
        int w = out.getWidth(), h = out.getHeight();
        int[] px = new int[w * h];
        out.getPixels(px, 0, w, 0, 0, w, h);
        for (int i = 0; i < px.length; i++) {
            int r = nightTone(Color.red(px[i]));
            int g = nightTone(Color.green(px[i]));
            int b = nightTone(Color.blue(px[i]));
            px[i] = Color.rgb(r, g, b);
        }
        out.setPixels(px, 0, w, 0, 0, w, h);
        return out;
    }

    private int nightTone(int v) {
        double n = v / 255d;
        double lifted = Math.pow(Math.min(1d, n * 1.24d), .80d);
        return Math.max(0, Math.min(255, (int)(lifted * 255d)));
    }

    private int rotation() {
        int r = getContext().getDisplay().getRotation();
        return r == Surface.ROTATION_0 ? 90 : r == Surface.ROTATION_90 ? 0 : r == Surface.ROTATION_180 ? 270 : 180;
    }

    private boolean save(Bitmap b, String tag) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "UltraZoom_" + tag + "_" + System.currentTimeMillis() + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/UltraZoom");
            Uri u = getContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u != null) {
                OutputStream o = getContext().getContentResolver().openOutputStream(u);
                if (o != null) {
                    b.compress(Bitmap.CompressFormat.JPEG, 97, o);
                    o.close();
                }
            }
            return u != null;
        } catch (Exception ignored) {
            return false;
        }
    }

    private void focus(float x, float y) {
        if (session == null || device == null || sensor == null) return;
        focusX = x; focusY = y; focusUntil = System.currentTimeMillis() + 1200;

        float nx = Math.max(0f, Math.min(1f, x / Math.max(1f, getWidth())));
        float ny = Math.max(0f, Math.min(1f, y / Math.max(1f, getHeight())));
        int orientation = deviceChars != null && deviceChars.get(CameraCharacteristics.SENSOR_ORIENTATION) != null
                ? deviceChars.get(CameraCharacteristics.SENSOR_ORIENTATION) : 90;
        int rot = getContext().getDisplay().getRotation();
        int displayDegrees = rot == Surface.ROTATION_90 ? 90 : rot == Surface.ROTATION_180 ? 180 : rot == Surface.ROTATION_270 ? 270 : 0;
        int relative = (orientation - displayDegrees + 360) % 360;
        float sx, sy;
        if (relative == 90) { sx = ny; sy = 1f - nx; }
        else if (relative == 180) { sx = 1f - nx; sy = 1f - ny; }
        else if (relative == 270) { sx = 1f - ny; sy = nx; }
        else { sx = nx; sy = ny; }

        int rw = Math.max(80, sensor.width() / 10);
        int rh = Math.max(80, sensor.height() / 10);
        int cx = sensor.left + Math.round(sx * sensor.width());
        int cy = sensor.top + Math.round(sy * sensor.height());
        Rect r = new Rect(cx - rw / 2, cy - rh / 2, cx + rw / 2, cy + rh / 2);
        r.intersect(sensor);
        focusRegion = r;

        cameraHandler.post(() -> {
            try {
                CaptureRequest.Builder b = request(CameraDevice.TEMPLATE_PREVIEW);
                b.addTarget(new Surface(preview.getSurfaceTexture()));
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
                session.capture(b.build(), null, cameraHandler);
                cameraHandler.postDelayed(() -> {
                    try {
                        if (session != null) {
                            CaptureRequest.Builder repeat = request(CameraDevice.TEMPLATE_PREVIEW);
                            repeat.addTarget(new Surface(preview.getSurfaceTexture()));
                            repeat.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_IDLE);
                            session.setRepeatingRequest(repeat.build(), null, cameraHandler);
                        }
                    } catch (Exception ignored) { }
                }, 700);
            } catch (Exception ignored) { }
        });
        invalidate();
    }

    private void captureMiniIfNeeded() {
        if (miniReader == null || !miniInSession || session == null || busy) return;
        long now = System.currentTimeMillis();
        if (miniCapturePending || now - lastMiniCapture < 1200) return;
        miniCapturePending = true;
        lastMiniCapture = now;
        cameraHandler.post(() -> {
            try {
                CaptureRequest.Builder b = requestAtZoom(CameraDevice.TEMPLATE_STILL_CAPTURE, 1f);
                b.addTarget(miniReader.getSurface());
                if (flashAvailable) {
                    b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                    b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
                }
                session.capture(b.build(), new CameraCaptureSession.CaptureCallback() {
                    @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest r, TotalCaptureResult result) { }
                    @Override public void onCaptureFailed(CameraCaptureSession s, CaptureRequest r, android.hardware.camera2.CaptureFailure f) {
                        miniCapturePending = false;
                    }
                }, cameraHandler);
            } catch (Exception e) {
                miniCapturePending = false;
            }
        });
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent e) { return true; }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int w = getWidth(), h = getHeight();
        float x = e.getX(), y = e.getY();
        ui.compute(w, h);
        validateLayout();

        if (e.getPointerCount() == 2) {
            if (e.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) { pinchDistance = distance(e); pinchStart = zoom; }
            else if (e.getActionMasked() == MotionEvent.ACTION_MOVE && pinchDistance > 0) {
                float nz = Math.max(.5f, Math.min(100f, pinchStart * distance(e) / pinchDistance));
                if (nz < 1f) selectWide(); else selectMain(nz);
            } else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) pinchDistance = 0;
            return true;
        }
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;

        if (showInfo) { showInfo = false; invalidate(); return true; }
        if (showModeMenu) {
            float top = 174 * ui.scale;
            if (y >= top && y <= top + MODES.length * 79 * ui.scale) {
                int i = (int)((y - top) / (79 * ui.scale));
                if (i >= 0 && i < MODES.length) {
                    mode = Mode.values()[i]; showModeMenu = false; status = MODES[i] + " • PRONTO"; applyPreview(); invalidate();
                }
            } else { showModeMenu = false; invalidate(); }
            return true;
        }
        if (ui.info.contains(x, y)) { showInfo = true; invalidate(); return true; }
        if (ui.flash.contains(x, y)) {
            if (!flashAvailable) status = "FLASH INDISPONÍVEL";
            else { flashMode = (flashMode + 1) % 3; applyPreview(); status = flashLabel(); }
            invalidate(); return true;
        }
        if (ui.mode.contains(x, y)) { showModeMenu = true; invalidate(); return true; }
        if (ui.shutter.contains(x, y)) { capture(); return true; }
        for (int i = 0; i < ui.lens.length; i++) {
            if (ui.lens[i].contains(x, y)) {
                if (i == 0) selectWide(); else if (i == 1) selectMain(1f); else if (i == 2) selectMain(2f); else if (i == 3) selectMain(6f); else selectMain(10f);
                return true;
            }
        }
        if (ui.zoomArea.contains(x, y)) {
            float ratio = Math.max(0, Math.min(1, (x - ui.zoomArea.left) / Math.max(1f, ui.zoomArea.width())));
            float nz = (float)Math.exp(Math.log(.5) + ratio * (Math.log(100) - Math.log(.5)));
            if (nz < 1f) selectWide(); else selectMain(nz);
            return true;
        }
        focus(x, y);
        return true;
    }

    private float distance(MotionEvent e) {
        float dx = e.getX(1) - e.getX(0), dy = e.getY(1) - e.getY(0);
        return (float)Math.sqrt(dx * dx + dy * dy);
    }

    void start() {
        startThreads();
        if (preview.isAvailable() && device == null) open();
    }

    void stop() { close(); }

    private void close() {
        try { if (session != null) { session.close(); session = null; } } catch (Exception ignored) { }
        try { if (device != null) { device.close(); device = null; } } catch (Exception ignored) { }
        miniCapturePending = false;
        miniInSession = false;
        if (miniBitmap != null && !miniBitmap.isRecycled()) { miniBitmap.recycle(); miniBitmap = null; }
    }

    void shutdown() {
        close();
        try { if (reader != null) reader.close(); } catch (Exception ignored) { }
        try { if (miniReader != null) miniReader.close(); } catch (Exception ignored) { }
        if (miniBitmap != null && !miniBitmap.isRecycled()) miniBitmap.recycle();
        try { if (cameraThread != null) cameraThread.quitSafely(); } catch (Exception ignored) { }
        try { if (workThread != null) workThread.quitSafely(); } catch (Exception ignored) { }
    }
}
