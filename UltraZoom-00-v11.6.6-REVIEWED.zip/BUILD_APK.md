# UltraZoom 11.6.6

1. Envie `UltraZoom-00-v11.6.6-REVIEWED.zip` para a raiz do repositório.
2. O workflow encontra exatamente um ZIP contendo `UZ-116.6-REVIEWED`.
3. Ele extrai o projeto para uma pasta temporária isolada.
4. Confere os arquivos críticos, versão `11.6.6` e assinaturas das APIs esperadas.
5. Executa `clean assembleDebug` com Java 17, Gradle 9.4.1 e Android 36.
6. Publica o APK `UltraZoom-v11.6.6-debug-apk`.

Importante: não deixe outro ZIP UltraZoom antigo na raiz do repositório, pois o workflow exige correspondência única.
